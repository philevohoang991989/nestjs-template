## NestJS starter

Boilerplate for Nest project

## Features

- Config Module
- Winston logger with configuration
- Swagger with configuration
- Cache with configuration, use `ioredis`. It's ready to switch to cluster mode
- Configured global validation pipe. Custom validation message ready for i18n
- Configurable HTTP logging incoming request and response

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```

## Validation

- Define message here: `src/shared/validation/message.enum.ts`
- Define message function here: `src/shared/validation/message.fn.ts`
- Example using message here: `src/demo/dto/demo.dto.ts`
- Example validation message in response

```javascript
{
  "message": [
    {
      "property": "email",
      "message": {
        "template": ":property is not an valid email"
      }
    },
    {
      "property": "password",
      "message": {
        "template": ":property is not an strong password"
      }
    },
    {
      "property": "age",
      "message": {
        "template": ":property must not less than :min",
        "min": 18
      }
    },
    {
      "property": "bio",
      "message": {
        "template": ":property length should be between :min and :max",
        "min": 3,
        "max": 10
      }
    }
  ],
  "error": "Bad Request",
  "statusCode": 400
}
```

## Cheatsheet

### Generate module/controller/service

```shell
nest g mo <ModuleName>
nest g co <ControllerName> --no-spec # In case controller name is same as module name
nest g co <ControllerName> <path> --flat --no-spec # In case controller name is same not as module name. Example: `nest g co Role user --flat` will create src/user/RoleController.ts
nest g s <ServiceName> --no-spec # In case service name is same as module name
```

### Generate entity/migration

### Generate entity

`npm run typeorm -- entity:create src/user/entity/<EntityName>`

Then rename `EntityName.ts` to `entity_name.entity.ts`

Example: `npm run typeorm -- entity:create src/user/entity/User` then rename `User.ts` to `user.entity.ts`

### Generate migration

`npm run typeorm:migration:generate src/user/migration/<MigrationName>`

Example: `npm run typeorm:migration:generate src/user/migration/User`
