#!/bin/sh

node dist/main
