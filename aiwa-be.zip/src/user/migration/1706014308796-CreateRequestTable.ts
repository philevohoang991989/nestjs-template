import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateRequestTable1706014308796 implements MigrationInterface {
  name = 'CreateRequestTable1706014308796';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "requests" (
                "id" SERIAL NOT NULL,
                "name" character varying NOT NULL DEFAULT '',
                "user_id" integer NOT NULL,
                "status" smallint NOT NULL,
                "is_downloaded" boolean NOT NULL DEFAULT false,
                "input_path" character varying NOT NULL,
                "xml_path" character varying,
                "sekisan_path" character varying,
                "file_type" character varying(50) NOT NULL,
                "file_name" character varying NOT NULL,
                "selected_page" integer NOT NULL DEFAULT '1',
                "total_page" integer NOT NULL DEFAULT '1',
                "unit_size" integer NOT NULL DEFAULT '910',
                "drawing_size" integer NOT NULL DEFAULT '9100',
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                CONSTRAINT "PK_0428f484e96f9e6a55955f29b5f" PRIMARY KEY ("id")
            )
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_59b85be6a3c16cbf27f8bdda1d" ON "requests" ("status")
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            DROP INDEX "public"."IDX_59b85be6a3c16cbf27f8bdda1d"
        `);
    await queryRunner.query(`
            DROP TABLE "requests"
        `);
  }
}
