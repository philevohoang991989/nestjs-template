import { MigrationInterface, QueryRunner } from 'typeorm';

export class Entity1705290278301 implements MigrationInterface {
  name = 'Entity1705290278301';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "users"
            ADD "role_id" integer NOT NULL DEFAULT '2'
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "users" DROP COLUMN "role_id"
        `);
  }
}
