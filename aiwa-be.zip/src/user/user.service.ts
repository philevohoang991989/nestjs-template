import { BadRequestException, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import * as bcrypt from 'bcrypt';
import { I18nContext } from 'nestjs-i18n';
import { AuthPayload } from 'src/auth/interface/auth-payload.interface';
import { MailService } from 'src/mail/mail.service';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { Repository } from 'typeorm';
import { ROLE } from './constants';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserFindQueryDto } from './dto/user-find-query.dto';
import { User } from './entity/user.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
    private readonly mailService: MailService,
    private readonly configService: ConfigService,
  ) {}

  async findById(id: number): Promise<User> {
    return await this.userRepository.findOneOrFail({
      where: {
        id: id,
      },
    });
  }

  async findByEmail(email: string): Promise<User> {
    return this.userRepository.findOne({
      where: {
        email,
      },
    });
  }

  async compareHashedPassword(plain: string, hashed: string) {
    return await bcrypt.compare(plain, hashed);
  }

  async hashPassword(plainPassword: string) {
    return await bcrypt.hash(plainPassword, 10);
  }

  async updatePassword(user: User, newPassword: string) {
    user.password = await this.hashPassword(newPassword);

    return this.userRepository.save(user);
  }

  async create(createUserDto: CreateUserDto): Promise<User> {
    const toCreateUser = { ...createUserDto, roleId: ROLE.USER };
    toCreateUser.password = await this.hashPassword(toCreateUser.password);

    const user = await this.userRepository.save(toCreateUser);

    const loginUrl = `${this.configService.get('APP_URL')}/login`;
    const lang = I18nContext.current().lang ?? 'en';

    this.mailService.sendWelcomeEmail(loginUrl, user.email, createUserDto.password, lang);

    return user;
  }

  async paginate(filter: UserFindQueryDto, authUser: AuthPayload): Promise<Pagination<User>> {
    const qb = this.userRepository.createQueryBuilder('user');

    const search = filter?.search?.trim().toLowerCase();
    if (!!search) {
      qb.andWhere(`( LOWER(user.email) like :search OR LOWER(user.name) like :search  )`, {
        search: `%${search}%`,
      });
    }

    const sortData = getOrderByClause(filter?.sort?.trim() || '-user.id');
    const sortKey = Object.keys(sortData).pop();
    if (['user.email', 'user.name'].includes(sortKey)) {
      qb.addOrderBy(`LOWER(${sortKey})`, Object.values(sortData).pop() == 'DESC' ? 'DESC' : 'ASC');
    } else {
      qb.orderBy(sortData);
    }

    qb.andWhere(`id != :userId`, { userId: authUser.id });
    qb.andWhere(`user.roleId != :roleAdminId`, { roleAdminId: ROLE.ADMIN });

    const results = await qb
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();

    return new Pagination(results);
  }

  async update(id: number, dto: UpdateUserDto): Promise<User> {
    const user = await this.userRepository.findOneByOrFail({ id });

    if (dto?.email?.trim()) {
      user.email = dto.email?.trim();
    }

    if (dto?.name?.trim()) {
      user.name = dto.name.trim();
    }

    if (dto?.password) {
      user.password = await this.hashPassword(dto.password);
    }

    return this.userRepository.save(user);
  }

  async remove(id: number, authUser: AuthPayload): Promise<User> {
    if (id == authUser.id) {
      throw new BadRequestException('Cannot delele current user.');
    }

    const user = await this.userRepository.findOneOrFail({
      where: {
        id,
      },
    });

    this.userRepository.remove(user);

    return user;
  }
}
