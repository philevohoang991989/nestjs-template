import {
  BadRequestException,
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Inject,
  NotFoundException,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Request,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { JwtAuthGuard } from 'src/auth/guard/jwt.guard';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { RolesGuard } from 'src/shared/guard/roles.guard';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { Logger } from 'winston';
import { ROLE } from './constants';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateMeDto, UpdateUserDto } from './dto/update-user.dto';
import { UserFindQueryDto } from './dto/user-find-query.dto';
import { User } from './entity/user.entity';
import { UserService } from './user.service';

@ApiTags('user')
@Controller('user')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@UseInterceptors(ClassSerializerInterceptor)
@RolesDecorator(ROLE.ADMIN)
export class UserController {
  constructor(
    private userSevice: UserService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
  ) {}

  @Get('me')
  async getCurrentUser(@Request() req): Promise<User> {
    return await this.userSevice.findById(req.user?.id);
  }

  @Put('me')
  async updateMe(@Request() req, @Body() dto: UpdateMeDto): Promise<User> {
    try {
      return await this.userSevice.update(req.user?.id, dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Post()
  @UseGuards(RolesGuard)
  async create(@Body() dto: CreateUserDto) {
    try {
      return await this.userSevice.create(dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get()
  @UseGuards(RolesGuard)
  async find(@Query(NormalizeFindQueryPipe) query: UserFindQueryDto, @Request() req): Promise<Pagination<User>> {
    try {
      return await this.userSevice.paginate(query, req.user);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get(':id')
  @UseGuards(RolesGuard)
  @ApiParam({ name: 'id' })
  async findById(@Param('id', ParseIntPipe) id: number): Promise<User> {
    try {
      return await this.userSevice.findById(id);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Put(':id')
  @UseGuards(RolesGuard)
  async update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateUserDto): Promise<User> {
    try {
      return await this.userSevice.update(id, dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Delete(':id')
  @UseGuards(RolesGuard)
  async delete(@Param('id') id: number, @Request() req): Promise<User> {
    try {
      return await this.userSevice.remove(id, req.user);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }
}
