import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Cache } from 'cache-manager';
import { MailService } from 'src/mail/mail.service';
import { User } from 'src/user/entity/user.entity';
import { UserService } from './user.service';

@Injectable()
export class ForgotPasswordService {
  constructor(
    private mailService: MailService,
    private configService: ConfigService,
    private userService: UserService,
    private jwtService: JwtService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) {}

  async getUserFromEmail(email: string) {
    return this.userService.findByEmail(email);
  }

  async sendMailResetPassword(user: User, lang: string) {
    const payload = {
      email: user.email,
      user_id: user.id,
    };
    const token = this.jwtService.sign(payload, {
      secret: this.configService.get('jwt').secret,
      expiresIn: +this.configService.get('jwt').resetPasswordTtl,
    });
    await this.cacheManager.set(token, true, +this.configService.get('jwt').resetPasswordTtl);

    const forgotPasswordUrl = await this.generateForgotPasswordUrl(user, token);

    if (!lang?.charAt(0)) {
      lang = 'en';
    }

    this.mailService.sendForgotPassword(user, forgotPasswordUrl, lang);
  }

  async generateForgotPasswordUrl(user: User, token: string) {
    return `${this.configService.get('APP_URL')}/reset-password?token=${token}`;
  }

  async verifyResetPasswordToken(token: string) {
    const cachedToken = await this.cacheManager.get(token);
    if (!cachedToken) {
      return null;
    }

    const payload = this.jwtService.verify(token, { secret: this.configService.get('jwt').secret });

    if (payload) {
      const user = this.userService.findById(payload.user_id);
      await this.cacheManager.del(token);
      return user;
    }

    return null;
  }

  async updateNewPassword(user: User, newPassword: string) {
    return await this.userService.updatePassword(user, newPassword);
  }
}
