export enum ROLE {
  ADMIN = 1,
  USER = 2,
}
