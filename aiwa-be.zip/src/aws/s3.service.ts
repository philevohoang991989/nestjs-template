import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client, S3ClientConfig } from '@aws-sdk/client-s3';
import { Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class S3Service implements OnModuleInit {
  private s3Client: S3Client;
  private defaultBucket: string;
  private rootFolder: string;
  constructor(private readonly configService: ConfigService) {}

  async onModuleInit() {
    const s3ClientConfig: S3ClientConfig = {
      credentials: {
        accessKeyId: this.configService.get('s3Config').accessKeyId,
        secretAccessKey: this.configService.get('s3Config').secretAccessKey,
      },
      endpoint: this.configService.get('s3Config').endpoint ?? undefined,
      region: this.configService.get('s3Config').region ?? undefined,
    };

    this.defaultBucket = this.configService.get('s3Config').bucket;
    this.rootFolder = this.configService.get('s3Config').rootFolder || '';

    this.s3Client = new S3Client(s3ClientConfig);
  }

  async putObject(file: Express.Multer.File, fileName: string, bucket: string = '', folderPath: string = undefined) {
    const Key = path.join(typeof folderPath !== 'undefined' ? folderPath : this.rootFolder, fileName);
    const command = new PutObjectCommand({
      Bucket: bucket || this.defaultBucket,
      Key,
      Body: file.buffer,
    });

    try {
      const response = await this.s3Client.send(command);
      (response as any).key = Key;

      return response;
    } catch (err) {
      console.error(err);
      throw err;
    }
  }

  async getObject(Key: string, bucket: string = '') {
    const command = new GetObjectCommand({
      Bucket: bucket || this.defaultBucket,
      Key,
    });

    return await this.s3Client.send(command);
  }

  async deleteObject(Key: string, bucket: string = '') {
    const command = new DeleteObjectCommand({
      Bucket: bucket || this.defaultBucket,
      Key,
    });

    return await this.s3Client.send(command);
  }

  /*
   * Upload Request OCR file ( contain bussiness logic)
   */
  async uploadRequest(file: Express.Multer.File) {
    const folderPath = path.join(this.rootFolder, 'raw', this.date2str(new Date()));
    const fileExt = file?.originalname?.split('.').pop();
    const fileName = uuidv4() + '.' + fileExt;

    return await this.putObject(file, fileName, this.defaultBucket, folderPath);
  }

  // return yyyy-mm-dd
  private date2str(d: Date): string {
    return [d.getFullYear(), ('0' + (d.getMonth() + 1)).slice(-2), ('0' + d.getDate()).slice(-2)].join('-');
  }
}
