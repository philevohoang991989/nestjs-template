import { BullModule } from '@nestjs/bull';
import { CacheModule } from '@nestjs/cache-manager';
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { redisStore } from 'cache-manager-ioredis-store';
import { WinstonModule, utilities as nestWinstonModuleUtilities } from 'nest-winston';
import { AcceptLanguageResolver, HeaderResolver, I18nModule, QueryResolver } from 'nestjs-i18n';
import * as winston from 'winston';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { AwsModule } from './aws/aws.module';
import { EventModule } from './event/event.module';
import { MailModule } from './mail/mail.module';
import { RequestModule } from './request/request.module';
import appConfig from './shared/config/app.config';
import cacheConfig from './shared/config/cache.config';
import databaseConfig from './shared/config/database.config';
import i18nConfig from './shared/config/i18n.config';
import jwtConfig from './shared/config/jwt.config';
import loggingConfig from './shared/config/logging.config';
import redisConfig from './shared/config/redis.config';
import swaggerConfig from './shared/config/swagger.config';
import { SharedModule } from './shared/shared.module';
import { UserModule } from './user/user.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig, loggingConfig, swaggerConfig, cacheConfig, redisConfig, databaseConfig, i18nConfig, jwtConfig],
    }),
    WinstonModule.forRootAsync({
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        level: configService.get('log.level'),
        transports: [
          new winston.transports.Console({
            format: winston.format.combine(
              winston.format.timestamp({
                format: 'YYYY-MM-DD hh:mm:ss.SSS',
              }),
              winston.format.ms(),
              nestWinstonModuleUtilities.format.nestLike(configService.get('app.name'), {
                colors: true,
                prettyPrint: true,
              }),
            ),
          }),
        ],
      }),
    }),
    BullModule.forRootAsync({
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        redis: {
          host: configService.get('cache.host'),
          port: configService.get('cache.port'),
          password: configService.get('cache.password'),
        },
      }),
    }),
    CacheModule.registerAsync({
      inject: [ConfigService],
      isGlobal: true,
      useFactory: async (configService: ConfigService) => ({
        store: async () =>
          await redisStore({
            host: configService.get('cache.host'),
            port: configService.get('cache.port'),
            password: configService.get('cache.password'),
            ttl: configService.get('cache.ttl'),
            keyPrefix: configService.get('cache.prefix'),
            username: configService.get('cache.username') ? configService.get('cache.username') : undefined,
          }),
      }),
    }),
    I18nModule.forRootAsync({
      useFactory: (configService: ConfigService) => ({
        ...configService.get('i18n'),
      }),
      resolvers: [new QueryResolver(['lang', 'l']), new HeaderResolver(['x-custom-lang']), AcceptLanguageResolver],
      inject: [ConfigService],
    }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        ...configService.get('database'),
      }),
    }),
    SharedModule,
    UserModule,
    AuthModule,
    MailModule,
    RequestModule,
    AwsModule,
    EventModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
