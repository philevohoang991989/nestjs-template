import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Cache } from 'cache-manager';
import { User } from 'src/user/entity/user.entity';
import { UserService } from 'src/user/user.service';
import { ChangePasswordDto } from './dto/change-password.dto';
import { AuthPayload } from './interface/auth-payload.interface';

@Injectable()
export class AuthService {
  constructor(
    private userService: UserService,
    private jwtService: JwtService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
    private readonly configService: ConfigService,
  ) {}

  async validateUser(email: string, plainPassword: string): Promise<any> {
    const user = await this.userService.findByEmail(email);
    if (user && (await this.userService.compareHashedPassword(plainPassword, user.password))) {
      delete user.password;

      return user;
    }

    return null;
  }

  async login(user: User) {
    const payload: AuthPayload = {
      name: user.name,
      email: user.email,
      id: user.id,
      roleId: user.roleId,
    };

    await this.cacheManager.set(`loginkey_${user.id}`, user.id, this.configService.get('jwt').exp);

    return {
      access_token: await this.jwtService.signAsync(payload),
    };
  }

  async logout(user: any) {
    await this.cacheManager.del(`loginkey_${user.id}`);
    return {
      message: 'logout successfully',
    };
  }

  async changePassword(user, dto: ChangePasswordDto): Promise<any> {
    if (dto.confirmNewPassword != dto.newPassword) {
      throw new BadRequestException('Confirm password does not match');
    }

    const validatedUser = await this.validateUser(user.email, dto.oldPassword);

    if (!validatedUser) {
      throw new NotFoundException('User not found or wrong old password');
    }

    return this.userService.updatePassword(validatedUser, dto.newPassword);
  }

  async verifyToken(token: string) {
    try {
      const user = await this.jwtService.verifyAsync(token);

      return user;
    } catch (e) {
      console.log(e.message);
      throw e;
    }
  }
}
