import { Body, Controller, Post, Request, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiBody, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { ChangePasswordDto } from './dto/change-password.dto';
import { LoginDTO } from './dto/login.dto';
import { JwtAuthGuard } from './guard/jwt.guard';
import { LocalAuthGuard } from './guard/local.guard';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @UseGuards(LocalAuthGuard)
  @Post('login')
  @ApiBody({ type: LoginDTO })
  async login(@Request() req): Promise<any> {
    return this.authService.login(req.user);
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @Post('change_password')
  @ApiResponse({ status: 201, description: 'Password has successfully changed' })
  @ApiResponse({ status: 400, description: 'Confirm password does not match' })
  @ApiResponse({ status: 404, description: 'User not found or wrong old password' })
  async changePassword(@Request() req, @Body() dto: ChangePasswordDto): Promise<any> {
    return this.authService.changePassword(req.user, dto);
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @Post('logout')
  async logout(@Request() req): Promise<any> {
    return this.authService.logout((req as any).user);
  }
}
