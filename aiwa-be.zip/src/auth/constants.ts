export const jwtConstants = {
  secret: 'yz2VmR8YtcbJRQ4PXqhREC6BpK4tE3',
};
