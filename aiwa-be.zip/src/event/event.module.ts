import { Global, Module } from '@nestjs/common';
import { EventGateway } from './event.gateway';
import { EventService } from './event.service';

@Global()
@Module({
  providers: [EventGateway, EventService],
  exports: [EventService],
})
export class EventModule {}
