import { ApiProperty } from '@nestjs/swagger';
import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity({
  name: 'requests',
})
export class Request {
  @ApiProperty()
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty()
  @Column({
    default: '',
  })
  name: string;

  @ApiProperty()
  @Column({
    name: 'user_id',
  })
  userId: number;

  @ApiProperty()
  @Column({
    name: 'status',
    type: 'smallint',
    nullable: false,
  })
  @Index()
  status: number;

  @ApiProperty()
  @Column({
    name: 'is_downloaded',
    default: false,
    nullable: false,
  })
  isDownloaded: boolean;

  @ApiProperty()
  @Column({
    name: 'input_path',
  })
  inputPath?: string;

  @ApiProperty()
  @Column({
    name: 'xml_path',
    nullable: true,
  })
  xmlPath?: string;

  @ApiProperty()
  @Column({
    name: 'sekisan_path',
    nullable: true,
  })
  sekisanPath?: string;

  @ApiProperty()
  @Column({
    name: 'file_type',
    length: 50,
  })
  fileType: string;

  @ApiProperty()
  @Column({
    name: 'file_name',
  })
  fileName: string;

  @ApiProperty()
  @Column({
    name: 'selected_page',
    default: 1,
  })
  selectedPage: number;

  @ApiProperty()
  @Column({
    name: 'total_page',
    default: 1,
  })
  totalPage: number;

  @ApiProperty()
  @Column({
    name: 'unit_size',
    default: 910,
  })
  unitSize: number;

  @ApiProperty()
  @Column({
    name: 'drawing_size',
    default: 9100,
  })
  drawingSize: number;

  @ApiProperty()
  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @ApiProperty()
  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  updatedAt: Date;
}
