import {
  BadRequestException,
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Inject,
  Param,
  ParseFilePipeBuilder,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Request,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { JwtAuthGuard } from 'src/auth/guard/jwt.guard';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { RolesGuard } from 'src/shared/guard/roles.guard';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { ROLE } from 'src/user/constants';
import { Readable } from 'stream';
import { Logger } from 'winston';
import { CreateRequestDto, UpdateDownloadStatusDto } from './dto/create-request.dto';
import { RequestFindQueryDto } from './dto/request-find-query.dto';
import { RequestDto } from './dto/request.dto';
import { RequestService } from './request.service';

@ApiTags('request')
@Controller('request')
@RolesDecorator(ROLE.USER)
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class RequestController {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    private requestService: RequestService,
  ) {}

  @Get()
  @UseInterceptors(ClassSerializerInterceptor)
  async find(
    @Query(NormalizeFindQueryPipe) query: RequestFindQueryDto,
    @Request() req,
  ): Promise<Pagination<RequestDto>> {
    try {
      return await this.requestService.paginate(query, req.user);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Post()
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('file'))
  async create(
    @UploadedFile(
      new ParseFilePipeBuilder()
        .addFileTypeValidator({
          fileType: /(jpg|jpeg|png|webp)$/,
        })
        .addMaxSizeValidator({
          maxSize: 10 * 1000 * 1000,
        })
        .build({
          errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        }),
    )
    file: Express.Multer.File,
    @Body() dto: CreateRequestDto,
    @Request() req,
  ): Promise<any> {
    try {
      return await this.requestService.create(file, dto, req.user);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestService.name);
      throw new BadRequestException(e);
    }
  }

  @Get('export')
  @ApiOperation({
    summary: 'Download request list',
  })
  async exportList(
    @Query(NormalizeFindQueryPipe) query: RequestFindQueryDto,
    @Request() req,
    @Res() res: Response,
  ): Promise<void> {
    try {
      res.setHeader('Content-Type', 'application/vnd.openxmlformats');
      res.setHeader('Content-Disposition', 'attachment; filename=RequestList.xlsx');
      res.send(await this.requestService.exportList(query, req.user));
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get(':id/export')
  async exportResult(@Param('id', ParseIntPipe) id: number, @Request() req, @Res() res: Response): Promise<void> {
    try {
      const r = await this.requestService.exportResult(id);
      res.set('content-type', 'application/octet-stream');
      res.set('content-disposition', `inline; filename=${r[1].fileName.replace(/\.[^/.]+$/, '')}.sekisan`);
      (r[0] as Readable).pipe(res);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestService.name);
      throw new BadRequestException(e);
    }
  }

  @Get(':id/export-xml')
  async exportResultXml(@Param('id', ParseIntPipe) id: number, @Request() req, @Res() res: Response): Promise<void> {
    try {
      const r = await this.requestService.exportResultXml(id);
      res.set('content-type', 'application/octet-stream');
      res.set('content-disposition', `inline; filename=${r[1].fileName.replace(/\.[^/.]+$/, '')}.xml`);
      (r[0] as Readable).pipe(res);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestService.name);
      throw new BadRequestException(e);
    }
  }

  @Put(':id/download-status')
  @ApiParam({ name: 'id' })
  @ApiOperation({ summary: 'Update download status' })
  async updateDownloadStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateDownloadStatusDto: UpdateDownloadStatusDto,
    @Request() req,
  ) {
    try {
      await this.requestService.updateStatusDownload(id, updateDownloadStatusDto, req.user);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Delete(':id')
  @ApiParam({ name: 'id' })
  @ApiOperation({ summary: 'Delete non-processing request' })
  async delete(@Param('id', ParseIntPipe) id: number, @Request() req) {
    try {
      await this.requestService.delete(id, req.user);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }
}
