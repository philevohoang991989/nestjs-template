import { OnQueueCompleted, Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import { RequestService } from './request.service';

@Processor('ocr-queue')
export class RequestProcessor {
  constructor(private requestService: RequestService) {}

  // consumer
  @Process()
  async handleRequest(job: Job) {
    await this.requestService.handleCallAI(job.data);
    return {};
  }

  // listener
  @OnQueueCompleted()
  async onCompleted(job: Job) {
    await job?.remove();
  }
}
