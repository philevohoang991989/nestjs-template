import { HttpService } from '@nestjs/axios';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AxiosError, AxiosRequestConfig } from 'axios';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { catchError, lastValueFrom, map } from 'rxjs';
import { Logger } from 'winston';
import { ConverterEncryptReqDto, OcrRequestDto } from '../dto/ocr-request.dto';

@Injectable()
export class OcrService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    private httpService: HttpService,
    private readonly configService: ConfigService,
  ) {}

  async makeOcrRequest(payload: OcrRequestDto) {
    const requestConfig: AxiosRequestConfig = {
      headers: { 'Content-Type': 'application/json' },
      timeout: this.configService.get('HTTP_TIMEOUT'),
      maxRedirects: this.configService.get('HTTP_MAX_REDIRECTS'),
    };

    const url = new URL('ocr-cad', this.configService.get('OCR_SERVICE_URL'));

    const result = await lastValueFrom(
      this.httpService.post(url.href, payload, requestConfig).pipe(
        map((response) => response?.data),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, OcrService.name);
          throw e;
        }),
      ),
    );

    return result;
  }

  async requestConveterEncrypt(payload: ConverterEncryptReqDto) {
    const requestConfig: AxiosRequestConfig = {
      headers: { 'Content-Type': 'application/json' },
    };

    const url = new URL('/Converter/Encrypt', this.configService.get('CONVERTER_SERVICE_URL'));

    const result = await lastValueFrom(
      this.httpService.post(url.href, payload, requestConfig).pipe(
        map((response) => response?.data),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, OcrService.name);
          throw e;
        }),
      ),
    );

    return result;
  }
}
