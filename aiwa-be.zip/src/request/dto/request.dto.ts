import { PartialType } from '@nestjs/swagger';
import { Request } from '../entity/request.entity';

export class RequestDto extends PartialType(Request) {}
