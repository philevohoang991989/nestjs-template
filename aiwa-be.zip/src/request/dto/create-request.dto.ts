import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateRequestDto {
  @ApiProperty()
  name: string;

  @ApiPropertyOptional({ default: 1 })
  selectedPage?: number;

  @ApiPropertyOptional()
  unitSize?: number;

  @ApiPropertyOptional()
  drawingSize?: number;

  @ApiProperty({ type: 'string', format: 'binary' })
  file: any;
}

export class UpdateDownloadStatusDto {
  @ApiProperty({
    description: 'Download status. true/false',
    example: false,
    default: false,
  })
  downloadStatus: boolean;
}
