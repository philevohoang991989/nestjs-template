import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class OcrRequestDto {
  @ApiProperty()
  request_id: string;

  @ApiProperty()
  raw_path: string;

  @ApiProperty()
  unit_size: string;

  @ApiProperty()
  drawing_size: string;

  @ApiProperty()
  title: string;
}

export class ConverterEncryptReqDto {
  @ApiProperty()
  request_id: string;

  @ApiProperty()
  file_path: string;

  @ApiPropertyOptional()
  file_name?: string;
}
