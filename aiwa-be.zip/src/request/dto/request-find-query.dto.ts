import { ApiPropertyOptional } from '@nestjs/swagger';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';

export class RequestFindQueryDto extends FindQueryDto {
  @ApiPropertyOptional()
  name?: string;

  @ApiPropertyOptional({
    description: `
      Processing = 1,
      Completed = 2,
      Failed = 3,`,
  })
  status?: number;

  @ApiPropertyOptional({
    name: 'fromDate',
    example: '2023-01-01',
  })
  fromDate?: Date;

  @ApiPropertyOptional({
    name: 'toDate',
    example: '2023-10-31',
  })
  toDate?: Date;

  @ApiPropertyOptional({
    name: 'sort',
    example: '-request.name',
    description:
      'Filter [+/-] request.id|request.name|request.status|request.selectedPage|request.totalPage|request.createdAt',
  })
  sort?: string;
}
