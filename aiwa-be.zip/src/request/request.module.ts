import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AwsModule } from 'src/aws/aws.module';
import { Request } from './entity/request.entity';
import { OcrService } from './ocr/ocr.service';
import { RequestController } from './request.controller';
import { RequestService } from './request.service';

import { BullModule } from '@nestjs/bull';
import { RequestProcessor } from './request.processor';

@Module({
  imports: [
    AwsModule,
    TypeOrmModule.forFeature([Request]),
    HttpModule,
    BullModule.registerQueue({
      name: 'ocr-queue',
    }),
  ],
  providers: [RequestService, OcrService, RequestProcessor],
  controllers: [RequestController],
})
export class RequestModule {}
