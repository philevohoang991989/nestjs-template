import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import * as Excel from 'exceljs';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { AuthPayload } from 'src/auth/interface/auth-payload.interface';
import { S3Service } from 'src/aws/s3.service';
import { EventService } from 'src/event/event.service';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { Readable } from 'stream';
import { Not, Repository } from 'typeorm';
import { Logger } from 'winston';
import { DefaultValue, RequestStatus } from './constants';
import { CreateRequestDto, UpdateDownloadStatusDto } from './dto/create-request.dto';
import { ConverterEncryptReqDto } from './dto/ocr-request.dto';
import { RequestFindQueryDto } from './dto/request-find-query.dto';
import { Request } from './entity/request.entity';
import { OcrService } from './ocr/ocr.service';
import { Queue } from 'bull';
import { InjectQueue } from '@nestjs/bull';

@Injectable()
export class RequestService {
  constructor(
    @InjectQueue('ocr-queue') private readonly ocrQueue: Queue,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    @InjectRepository(Request) private requestRepository: Repository<Request>,
    private configService: ConfigService,
    private readonly s3Service: S3Service,
    private readonly ocrService: OcrService,
    private eventService: EventService,
  ) {}

  async create(file: Express.Multer.File, dto: CreateRequestDto, authUser: AuthPayload) {
    // Upload to s3
    const fileUploaded = await this.s3Service.uploadRequest(file);

    // Save DB
    const request = new Request();
    request.name = dto.name || file.originalname;
    request.userId = +authUser.id;
    request.status = RequestStatus.Processing;
    request.fileName = file.originalname;
    request.selectedPage = dto?.selectedPage || 1;
    request.fileType = file.mimetype;
    request.inputPath = (fileUploaded as any)?.key; //path on S3, not incluce bucket
    request.unitSize = dto?.unitSize || DefaultValue.unitSize;
    request.drawingSize = dto?.drawingSize || DefaultValue.drawingSize;

    // TODO: calculate total pdf pages
    request.totalPage = 1;

    const savedRequest = await this.requestRepository.save(request);

    await this.requestRepository.save(savedRequest);

    if (this.configService.get('app').useQueueApiCall == 'true') {
      await this.ocrQueue.add(savedRequest);
    } else {
      this.handleCallAI(savedRequest);
    }

    return savedRequest;
  }

  async handleCallAI(request: Request) {
    try {
      const ocrRes = await this.ocrService.makeOcrRequest({
        request_id: request.id.toString(),
        raw_path: request.inputPath,
        unit_size: request?.unitSize?.toString() || DefaultValue.unitSize.toString(),
        drawing_size: request?.drawingSize?.toString() || DefaultValue.drawingSize.toString(),
        title: request.name,
      });

      if (ocrRes.status == 'fail') {
        request.status = RequestStatus.Failed;
      } else {
        request.xmlPath = ocrRes?.xml_path;
        request.status = RequestStatus.Completed;
      }
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestService.name);
      request.status = RequestStatus.Failed;
    }

    await this.requestRepository.save(request);

    // Publish message to client
    const channelName = `Channel_${request.userId}`;
    this.eventService.socket.to(channelName).emit('updateOcrResult', {
      id: request.id,
      status: request.status,
    });
  }

  async paginate(filter: RequestFindQueryDto, authUser: AuthPayload): Promise<Pagination<Request>> {
    const qb = this.requestRepository.createQueryBuilder('request');
    qb.where('request.userId = :userId', { userId: +authUser.id });

    if (filter?.name?.trim()) {
      qb.andWhere('request.name LIKE :name', { name: `%${filter.name.trim()}%` });
    }

    if (typeof filter.status !== 'undefined') {
      qb.andWhere('request.status = :status', { status: filter.status });
    }

    if (filter.fromDate) {
      qb.andWhere('request.updated_at >= :fromDate', { fromDate: filter.fromDate });
    }

    if (filter.toDate) {
      qb.andWhere('request.updated_at <= :toDate', {
        toDate: new Date(filter.toDate.getFullYear(), filter.toDate.getMonth(), filter.toDate.getDate() + 1),
      });
    }

    if (filter.sort) {
      qb.orderBy(getOrderByClause(filter.sort));
    } else {
      qb.orderBy('request.id', 'DESC');
    }

    const results = await qb
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();

    return new Pagination(results);
  }

  async exportList(filter: RequestFindQueryDto, authUser: AuthPayload) {
    filter.page = 1;
    filter.limit = 0;

    const results = await this.paginate(filter, authUser);

    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet('Sheet1');
    worksheet.addRow([
      'OCR ID',
      'Title',
      // 'Page',
      'Status',
      // 'No of Page',
      'Updated Date',
    ]);

    for (const item of results.items ?? []) {
      worksheet.addRow([
        item.id,
        item.name || item.fileName,
        // item.selectedPage,
        this.requestStatus2String(item.status),
        // item.totalPage ?? 0,
        this.datetime2String(item.updatedAt),
      ]);
    }

    return workbook.xlsx.writeBuffer();
  }

  async exportResult(id: number): Promise<[Readable, Request]> {
    const request = await this.requestRepository.findOneOrFail({
      where: {
        id,
        status: Not(RequestStatus.Failed), //TODO
      },
    });

    if (!request.isDownloaded || !request.sekisanPath) {
      const payload: ConverterEncryptReqDto = {
        request_id: request.id.toString(),
        file_path: request.xmlPath,
        file_name: request.fileName.replace(/\.[^/.]+$/, '') + '.sekisan',
      };

      const converterRes = await this.ocrService.requestConveterEncrypt(payload);

      request.isDownloaded = true;
      request.sekisanPath = converterRes?.file_path;

      await this.requestRepository.save(request);
    }

    const s3Res = await this.s3Service.getObject(request.sekisanPath);

    return [s3Res.Body as Readable, request];
  }

  async exportResultXml(id: number): Promise<[Readable, Request]> {
    const request = await this.requestRepository.findOneOrFail({
      where: {
        id,
        status: Not(RequestStatus.Failed), //TODO
      },
    });

    const s3Res = await this.s3Service.getObject(`${request.xmlPath.replace(/\.[^/.]+$/, '')}_forxmldownload.xml`);

    return [s3Res.Body as Readable, request];
  }

  async updateStatusDownload(id: number, dto: UpdateDownloadStatusDto, authUser: AuthPayload) {
    const request = await this.requestRepository.findOneOrFail({
      where: {
        id,
        status: RequestStatus.Completed, //TODO
        userId: +authUser.id,
      },
    });

    request.isDownloaded = dto.downloadStatus;

    return await this.requestRepository.save(request);
  }

  async delete(id: number, authUser: AuthPayload) {
    const request = await this.requestRepository.findOneOrFail({
      where: {
        id,
        userId: +authUser.id,
      },
    });

    const deleteRes = await this.requestRepository.delete({
      id,
      userId: +authUser.id,
      status: Not(RequestStatus.Processing),
    });

    if (deleteRes && deleteRes.affected) {
      if (request.sekisanPath) {
        await this.s3Service.deleteObject(request.sekisanPath);
      }
      if (request.inputPath) {
        await this.s3Service.deleteObject(request.inputPath);
      }
      if (request.xmlPath) {
        await this.s3Service.deleteObject(request.xmlPath);
      }
    }

    return true;
  }

  // TODO: i18n
  private requestStatus2String(status?: RequestStatus): string {
    switch (status) {
      case RequestStatus.Processing:
        return `Processing`;
      case RequestStatus.Completed:
        return `Completed`;
      case RequestStatus.Failed:
        return `Failed`;
    }

    return '';
  }

  private datetime2String(dt: Date): string {
    return `${dt.getFullYear()}-${
      dt.getMonth() + 1
    }-${dt.getDate()} ${dt.getHours()}:${dt.getMinutes()}:${dt.getSeconds()}`;
  }
}
