export enum RequestStatus {
  Processing = 1,
  Completed = 2,
  Failed = 3,
}

export enum DefaultValue {
  unitSize = 910,
  drawingSize = 9100,
}
