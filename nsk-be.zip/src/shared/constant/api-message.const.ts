export const API_MESSAGE = {
  1000: 'Invalid request quota!',
  1010: 'Invalid tenant code!',
  2100: 'Email address already exists in the system!',
  2001: 'Company Name already exists in the system!',
  2002: 'Current month package must be greater or equal this one!',
  2003: 'Current month block must be greater or equal this one!',
  1015: 'Tenant is expired',
  1020: 'Error! Too many pages detected.',
};
