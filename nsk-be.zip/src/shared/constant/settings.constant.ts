export const BILL_DATE = 'bill_date';
export const LAST_PAYMENT_DATE = 'last_payment_date';
