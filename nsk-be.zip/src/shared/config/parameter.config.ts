import { registerAs } from '@nestjs/config';

export default registerAs('parameter', () => {
  return {
    pagePerBlock: process.env.PAGES_PER_BLOCK,
    blocksPerPackage: process.env.BLOCKS_PER_PACKAGE,
    limitPagesPerRequest: process.env.LIMIT_PAGES_PER_REQUEST,
    expiredTimePassword: process.env.EXPIRED_TIME_PASSWORD,
  };
});
