import { registerAs } from '@nestjs/config';

export default registerAs('cache', () => {
  return {
    // exp: process.env.CACHE_EXP,
    pageCountExpTime: process.env.PAGE_COUNT_CACHES_EXPIRED_TIME,
    host: process.env.REDIS_HOST,
    port: process.env.REDIS_PORT,
    password: process.env.REDIS_PASSWORD,
  };
});
