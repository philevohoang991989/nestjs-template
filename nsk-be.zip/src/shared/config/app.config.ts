import { registerAs } from '@nestjs/config';

export default registerAs('app', () => ({
  useQueueApiCall: process?.env?.USE_QUEUE_API_CALL || false,
}));
