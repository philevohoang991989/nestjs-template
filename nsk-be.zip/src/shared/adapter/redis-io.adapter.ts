import { IoAdapter } from '@nestjs/platform-socket.io';
import { ServerOptions } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { createClient } from 'redis';
import { ConfigService } from '@nestjs/config';
import { INestApplicationContext } from '@nestjs/common';
import { AuthService } from 'src/auth/auth.service';

export class RedisIoAdapter extends IoAdapter {
  private adapterConstructor: ReturnType<typeof createAdapter>;
  private configService: ConfigService;
  private authService: AuthService;

  constructor(private app: INestApplicationContext) {
    super(app);
    this.configService = this.app.get(ConfigService);
    this.authService = this.app.get(AuthService);
  }

  async connectToRedis(): Promise<void> {
    const { host, port, password } = this.configService.get('redis');
    const pubClient = createClient({
      socket: {
        host,
        port,
      },
      password: `${password}`,
    });

    const subClient = pubClient.duplicate();

    await Promise.all([pubClient.connect(), subClient.connect()]);

    this.adapterConstructor = createAdapter(pubClient, subClient);
  }

  createIOServer(port: number, options?: ServerOptions): any {
    const server = super.createIOServer(port, options);
    server.adapter(this.adapterConstructor);

    server.use(async (socket: any, next) => {
      const tokenPayload: string = socket.handshake?.auth?.token;

      if (!tokenPayload) {
        return next(new Error('Token not provided'));
      }

      try {
        socket.user = {};
        const user = await this.authService.verifyToken(tokenPayload);
        socket.user = user;

        return next();
      } catch (error: any) {
        return next(new Error('Authentication error'));
      }
    });

    return server;
  }
}
