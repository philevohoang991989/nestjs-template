import * as moment from 'moment';

export function getFirstDayOfCurrentMonth() {
  return new Date(moment().startOf('month').format('YYYY-MM-DD'));
}

export function formatDate(inputDate: any, format: string, timezone = null) {
  if (!inputDate) return '';

  const date = new Date(inputDate);

  if (timezone) {
    date.setHours(date.getHours() - +timezone / 60);
  }

  const padZero = (value) => (value < 10 ? `0${value}` : `${value}`);
  const parts = {
    yyyy: date.getFullYear(),
    MM: padZero(date.getMonth() + 1),
    dd: padZero(date.getDate()),
    HH: padZero(date.getHours()),
    mm: padZero(date.getMinutes()),
    ss: padZero(date.getSeconds()),
    tt: date.getHours() < 12 ? 'AM' : 'PM',
  };

  return format.replace(/yyyy|MM|dd|HH|mm|ss|tt/g, (match) => parts[match]);
}

export function getLastDayOfMonth(inputStr: string) {
  const parts = inputStr.split('-');
  const y = parseInt(parts[0]);
  const m = parseInt(parts[1]);
  return new Date(y, m, 0);
}

export function stringToDate(date: any, format: string) {
  return new Date(moment(date, format).format('YYYY-MM-DD'));
}

export function getStartDateOfMonth(month) {
  return moment(month).startOf('month').startOf('day');
}
export function getEndDateOfMonth(month) {
  return moment(month).endOf('month').endOf('day');
}

export function getInvoiceStartDate(month: string) {
  return moment(month).startOf('month').format('YYYY-MM-DD');
}

export function getInvoiceEndDate(month: string) {
  return moment(month).endOf('month').format('YYYY-MM-DD');
}

export function getFullInvoiceDateFromDay(month: string, date: number) {
  return moment(month)
    .add(1, 'months')
    .startOf('month')
    .add(date - 1, 'days')
    .format('YYYY-MM-DD');
}

export function addDate(date: Date, days: number) {
  date.setDate(date.getDate() + days);
  return date;
}
