import { HttpException } from '@nestjs/common';
import { API_MESSAGE } from '../constant/api-message.const';

export function throwValidationException(errorCode: number, data?: object, message?: string) {
  if (!message) {
    message = API_MESSAGE[errorCode];
  }

  throw new HttpException({ ...data, message: message }, errorCode);
}
