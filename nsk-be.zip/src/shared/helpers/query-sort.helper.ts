export function getOrderByClause(sortQuery: string, mainTable: string) {
  const fields = sortQuery.split(',');
  const orderBy = {};
  for (let field of fields) {
    let order = 'ASC';

    if (field.startsWith('-')) {
      order = 'DESC';
      field = field.substring(1);
    }

    if (!field.includes('.')) {
      field = mainTable + '.' + field;
    }

    orderBy[field] = order;
  }

  return orderBy;
}
