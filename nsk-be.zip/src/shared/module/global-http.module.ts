import { Global, Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';

@Global()
@Module({
  imports: [
    HttpModule.registerAsync({
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        baseURL: configService.get('HTTP_BASE_URL'),
        headers: {
          'X-API-KEY': configService.get('APIKEY_SECRET'),
          'PARTNER-CODE': configService.get('PARTNER_CODE'),
        },
        timeout: configService.get('HTTP_TIMEOUT'),
        maxRedirects: configService.get('HTTP_MAX_REDIRECTS'),
      }),
    }),
  ],
  exports: [HttpModule],
})
export class GlobalHttpModule {}
