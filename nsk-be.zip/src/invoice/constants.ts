export enum PaymentStatus {
  Pending = 1,
  Paid = 2,
  Overdue = 3,
}
