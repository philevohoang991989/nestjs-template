import {
  Controller,
  Get,
  Body,
  Patch,
  Param,
  UseGuards,
  Query,
  Inject,
  BadRequestException,
  NotFoundException,
  ParseIntPipe,
  Request,
  Req,
  Res,
  Put,
  UseInterceptors,
  ClassSerializerInterceptor,
} from '@nestjs/common';
import { InvoiceService } from './invoice.service';
import { UpdatePaymentStatusDto } from './dto/update-payment-status.dto';
import { RolesGuard } from 'src/shared/guards/roles.guard';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { InvoiceFindQueryDto } from './dto/invoice-find-query.dto';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Logger } from 'winston';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Roles } from 'src/user/constants';
import { InvoiceDetailQueryDto } from './dto/invoice-detail-query.dto';

@Controller('invoice')
@ApiTags('invoice')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
export class InvoiceController {
  constructor(
    private readonly invoiceService: InvoiceService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
  ) {}

  @Get()
  @RolesDecorator(Roles.Partner, Roles.Tenant)
  @UseGuards(RolesGuard)
  @ApiOperation({ summary: 'Get invoice list' })
  @UseInterceptors(ClassSerializerInterceptor)
  async find(@Query(NormalizeFindQueryPipe) query: InvoiceFindQueryDto, @Request() req) {
    try {
      if (req.user?.roleId == Roles.Tenant && req.user?.tenantId) {
        query.tenantId = req.user?.tenantId;
      }

      return await this.invoiceService.paginate(query);
    } catch (e) {
      this.logger.error(e.message, e.stack, InvoiceController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get(':id')
  @RolesDecorator(Roles.Partner, Roles.Tenant)
  @UseGuards(RolesGuard)
  @ApiParam({ name: 'id' })
  @ApiOperation({ summary: 'Get invoice detail' })
  async findOne(
    @Query(NormalizeFindQueryPipe) query: InvoiceDetailQueryDto,
    @Param('id', ParseIntPipe) id: number,
    @Req() req,
  ) {
    try {
      const invoice = await this.invoiceService.getInvoiceWithUsage(id);
      if (req.user.roleId !== Roles.Partner && invoice.usage?.tenantId !== req.user.tenantId) {
        throw new NotFoundException('Not found invoice detail');
      }

      return await this.invoiceService.getRequestList(query, invoice.usage?.tenantId, invoice.usage?.month);
    } catch (e) {
      this.logger.error(e.message, e.stack, InvoiceController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Get(':id/export')
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  @ApiParam({ name: 'id' })
  @ApiOperation({ summary: 'Export invoice' })
  async exportInvoice(@Param('id', ParseIntPipe) id: number, @Res() res) {
    try {
      const invoice = await this.invoiceService.getInvoiceWithTenant(id);
      const fileBuffer = await this.invoiceService.exportExcel(invoice);

      // Set head for downloading
      res.setHeader('Content-Disposition', `attachment; filename=Invoice_Tenant_${invoice.tenant.id}.xlsx`);
      res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

      res.send(fileBuffer);
    } catch (e) {
      this.logger.error(e.message, e.stack, InvoiceController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Patch(':id/payment')
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  @ApiParam({ name: 'id' })
  @ApiOperation({ summary: 'Update invoice payment status' })
  async updatePaymentStatus(@Param('id') id: string, @Body() updateInvoiceDto: UpdatePaymentStatusDto) {
    try {
      return await this.invoiceService.updatePaymentStatus(+id, updateInvoiceDto);
    } catch (e) {
      this.logger.error(e.message, e.stack, InvoiceController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Put('overdue')
  @ApiOperation({ summary: 'Update invoice payment status' })
  async updateOverdueInvoices() {
    try {
      await this.invoiceService.updateOverdueInvoices();
      return [];
    } catch (e) {
      this.logger.error(e.message, e.stack, InvoiceController.name);
      throw new BadRequestException(e.message);
    }
  }
}
