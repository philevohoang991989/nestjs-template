import { ApiProperty } from '@nestjs/swagger';

export class UpdatePaymentStatusDto {
  @ApiProperty({
    description: 'Format: YYYY-MM-DD',
    example: '2023-10-30',
  })
  paymentDate: Date;
}
