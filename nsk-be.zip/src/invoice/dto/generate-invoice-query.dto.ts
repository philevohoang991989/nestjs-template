import { ApiPropertyOptional } from '@nestjs/swagger';

export class GenerateInvoiceQueryDto {
  @ApiPropertyOptional()
  month?: string;
}
