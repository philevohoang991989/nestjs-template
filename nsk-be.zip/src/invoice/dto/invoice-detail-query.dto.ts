import { FindQueryDto } from 'src/shared/dto/find-query.dto';

export class InvoiceDetailQueryDto extends FindQueryDto {}
