import { ApiPropertyOptional } from '@nestjs/swagger';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { PaymentStatus } from '../constants';
import { IsOptional, Matches } from 'class-validator';

export class InvoiceFindQueryDto extends FindQueryDto {
  @ApiPropertyOptional()
  tenantId?: number;

  @ApiPropertyOptional({
    name: 'paymentStatus',
    enum: PaymentStatus,
    description: 'Payment status: 1: Pending, 2: Paid, 3: Overdue',
  })
  paymentStatus?: number;

  @ApiPropertyOptional({
    name: 'billMonth',
    example: '2023-10',
    description: 'Format: yyyy-MM',
  })
  @IsOptional()
  @Matches(/^(?:\d{4}-(0[1-9]|1[0-2]))?$/, { message: 'Invalid billMonth format' })
  billMonth?: string;

  @ApiPropertyOptional({
    name: 'sort',
    example: '-invoice.start_date',
    description:
      'Filter sort by id, tenant.id, tenant.name, startDate, pageCount, currentMonthBlocks, paymentStatus, paidDate. Default is ASC. Minus before is DESC',
  })
  @IsOptional()
  @Matches(/^(?:-)?(?:id|tenant.id|tenant.name|startDate|pageCount|currentMonthBlocks|paymentStatus|paidDate)?$/, {
    message: 'Invalid sort format',
  })
  sort?: string;
}
