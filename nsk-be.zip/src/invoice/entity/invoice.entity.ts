import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Tenant } from 'src/tenant/entity/tenant.entity';
import { Usage } from 'src/usage/entity/usage.entity';
import { Exclude, Transform } from 'class-transformer';
import * as moment from 'moment';

@Entity({
  name: 'invoices',
})
export class Invoice {
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @Column({
    name: 'tenant_id',
    nullable: true,
  })
  tenantId: number;

  @ManyToOne(() => Tenant, { nullable: false })
  @JoinColumn({
    name: 'tenant_id',
  })
  @Index()
  tenant: Tenant;

  @Column({
    name: 'usage_id',
    nullable: true,
  })
  usageId: number;

  @OneToOne(() => Usage)
  @JoinColumn({
    name: 'usage_id',
  })
  @Index()
  usage: Usage;

  @Exclude()
  @Column({
    name: 'current_month_packages',
    default: 1,
  })
  currentMonthPackages: number;

  @Column({
    name: 'current_month_blocks',
    default: 1,
  })
  currentMonthBlocks: number;

  @Column({
    name: 'start_date',
    type: 'date',
    nullable: true,
  })
  @Transform(({ value }) => moment(value).format('yyyy-MM'))
  startDate: Date;

  @Column({
    name: 'end_date',
    type: 'date',
    nullable: true,
  })
  endDate: Date;

  @Column({
    name: 'paid_date',
    type: 'date',
    nullable: true,
  })
  paidDate: Date;

  @Column({
    name: 'due_date',
    type: 'date',
    nullable: true,
  })
  dueDate: Date;

  @Column({
    name: 'page_count',
    default: 0,
  })
  pageCount: number;

  @Column({
    name: 'path',
    length: 512,
    nullable: true,
  })
  path: string;

  @Column({
    name: 'payment_status',
    type: 'smallint',
    default: 1,
  })
  @Index()
  paymentStatus: number;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamptz',
  })
  deletedAt: Date;
}
