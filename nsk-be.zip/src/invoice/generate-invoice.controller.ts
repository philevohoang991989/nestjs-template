import { Controller, UseGuards, Query, Inject, BadRequestException, Post } from '@nestjs/common';
import { RolesGuard } from 'src/shared/guards/roles.guard';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Logger } from 'winston';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Roles } from 'src/user/constants';
import { GenerateInvoiceQueryDto } from './dto/generate-invoice-query.dto';
import { GenerateInvoiceService } from './generate-invoice.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import * as moment from 'moment';

@Controller('generate-invoice')
@ApiTags('generate-invoice')
@ApiBearerAuth()
@RolesDecorator(Roles.Partner)
@UseGuards(JwtAuthGuard, RolesGuard)
export class GenerateInvoiceController {
  constructor(
    private readonly generateInvoiceService: GenerateInvoiceService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Generate invoice for tenants' })
  async create(@Query() query: GenerateInvoiceQueryDto) {
    try {
      if (!query.month) {
        query.month = moment().startOf('month').format('YYYY-MM-DD');
      }
      return await this.generateInvoiceService.create(query.month);
    } catch (e) {
      this.logger.error(e.message, e.stack, GenerateInvoiceController.name);
      throw new BadRequestException(e.message);
    }
  }
}
