import { Injectable } from '@nestjs/common';
import { Invoice } from './entity/invoice.entity';
import { DataSource } from 'typeorm';
import { getFullInvoiceDateFromDay, getInvoiceEndDate, getInvoiceStartDate } from 'src/shared/helpers/date.helper';
import { Usage } from 'src/usage/entity/usage.entity';
import * as moment from 'moment';
import { Setting } from 'src/setting/entity/setting.entity';
import { LAST_PAYMENT_DATE } from 'src/shared/constant/settings.constant';
import { LIMIT } from 'src/shared/constant/common.constant';

@Injectable()
export class GenerateInvoiceService {
  constructor(private dataSource: DataSource) {}

  async create(month?: string): Promise<any> {
    if (!month) {
      // Generate previous month invoice
      month = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD');
    }

    const totalUsage = await this.dataSource.manager
      .getRepository(Usage)
      .createQueryBuilder('usage')
      .where('usage.month =:month', { month: month })
      .getCount();

    let offset = 0;
    while (offset < totalUsage) {
      await this.processGenerateInvoice(month, LIMIT, offset);
      offset = +LIMIT;
    }

    return month;
  }

  async processGenerateInvoice(month: string, limit: number, offset: number): Promise<void> {
    const invoiceData = [];
    const startDate = getInvoiceStartDate(month);
    const endDate = getInvoiceEndDate(month);

    const setting = await this.dataSource.manager.getRepository(Setting).findOne({
      where: { key: LAST_PAYMENT_DATE },
    });

    if (setting) {
      const dueDate = getFullInvoiceDateFromDay(month, +setting.value);

      const qb = this.dataSource.manager
        .getRepository(Usage)
        .createQueryBuilder('usage')
        .where('usage.month =:month', { month: month })
        .orderBy('usage.id', 'DESC');

      const usages = await qb.select('usage.*').offset(offset).limit(limit).getRawMany();

      if (usages.length > 0) {
        usages.forEach((usage) => {
          invoiceData.push({
            tenantId: usage.tenant_id,
            usageId: usage.id,
            startDate: startDate,
            endDate: endDate,
            dueDate: dueDate,
            pageCount: usage.page_count,
            currentMonthBlocks: usage.current_month_blocks,
          });
        });

        await this.dataSource.manager.getRepository(Invoice).upsert(invoiceData, ['usageId']);
      }
    }
  }
}
