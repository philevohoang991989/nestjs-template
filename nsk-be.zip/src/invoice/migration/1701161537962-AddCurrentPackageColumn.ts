import { MigrationInterface, QueryRunner } from 'typeorm';

export class Invoice1701161537962 implements MigrationInterface {
  name = 'User1701161537962';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "usages"
      ADD "current_month_blocks" integer
    `);
    await queryRunner.query(`
      ALTER TABLE "invoices"
      ADD "current_month_packages" integer
    `);
    await queryRunner.query(`
      ALTER TABLE "invoices"
      ADD "current_month_blocks" integer
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "invoices" DROP COLUMN "current_month_blocks"
    `);
    await queryRunner.query(`
      ALTER TABLE "invoices" DROP COLUMN "current_month_packages"
    `);
    await queryRunner.query(`
      ALTER TABLE "usages" DROP COLUMN "current_month_blocks"
    `);
  }
}
