import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateIndexUsageColumn1700034328648 implements MigrationInterface {
  name = 'UpdateIndexUsageColumn1700034328648';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ADD CONSTRAINT "UQ_8d476453cf40d2d8435362d3fc4" UNIQUE ("usage_id")
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_8d476453cf40d2d8435362d3fc" ON "invoices" ("usage_id")
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            DROP INDEX "public"."IDX_8d476453cf40d2d8435362d3fc"
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices" DROP CONSTRAINT "UQ_8d476453cf40d2d8435362d3fc4"
        `);
  }
}
