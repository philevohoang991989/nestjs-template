import { MigrationInterface, QueryRunner } from 'typeorm';

export class Invoice_DefaultValue1702534509649 implements MigrationInterface {
  name = 'Invoice_DefaultValue1702534509649';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "tenant_id" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_packages"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_packages"
            SET DEFAULT '1'
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_blocks"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_blocks"
            SET DEFAULT '1'
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "page_count"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "page_count"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "payment_status"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "payment_status"
            SET DEFAULT '1'
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "payment_status" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "payment_status" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "page_count" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "page_count" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_blocks" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_blocks" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_packages" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "current_month_packages" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "invoices"
            ALTER COLUMN "tenant_id"
            SET NOT NULL
        `);
  }
}
