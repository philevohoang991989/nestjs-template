import { MigrationInterface, QueryRunner } from 'typeorm';

export class Invoice1698834443466 implements MigrationInterface {
  name = 'Invoice1698834443466';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "invoices" (
                "id" BIGSERIAL NOT NULL,
                "tenant_id" bigint NOT NULL,
                "usage_id" bigint,
                "start_date" date,
                "end_date" date,
                "due_date" date,
                "paid_date" date,
                "page_count" integer,
                "path" character varying(512),
                "payment_status" smallint,
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                CONSTRAINT "PK_668cef7c22a427fd822cc1be3ce" PRIMARY KEY ("id")
            )
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_440f531f452dcc4389d201b9d4" ON "invoices" ("tenant_id")
        `);
    await queryRunner.query(`
        CREATE INDEX "IDX_6968235caf5c27e2bb2bba99ad" ON "invoices" ("payment_status")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            DROP INDEX "public"."IDX_440f531f452dcc4389d201b9d4"
        `);
    await queryRunner.query(`
            DROP TABLE "invoices"
        `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_6968235caf5c27e2bb2bba99ad"
    `);
  }
}
