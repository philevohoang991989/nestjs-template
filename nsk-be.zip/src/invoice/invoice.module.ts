import { Module } from '@nestjs/common';
import { InvoiceService } from './invoice.service';
import { InvoiceController } from './invoice.controller';
import { Invoice } from './entity/invoice.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GenerateInvoiceController } from './generate-invoice.controller';
import { GenerateInvoiceService } from './generate-invoice.service';
import { ExcelModule } from 'src/excel/excel.module';

@Module({
  imports: [TypeOrmModule.forFeature([Invoice]), ExcelModule],
  controllers: [InvoiceController, GenerateInvoiceController],
  providers: [InvoiceService, GenerateInvoiceService],
  exports: [GenerateInvoiceService, InvoiceService],
})
export class InvoiceModule {}
