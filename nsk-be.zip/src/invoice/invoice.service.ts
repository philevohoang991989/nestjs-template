import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UpdatePaymentStatusDto } from './dto/update-payment-status.dto';
import { Invoice } from './entity/invoice.entity';
import { Repository, DataSource } from 'typeorm';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { InvoiceFindQueryDto } from './dto/invoice-find-query.dto';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { PaymentStatus } from './constants';
import { getFullInvoiceDateFromDay, getEndDateOfMonth, getStartDateOfMonth } from 'src/shared/helpers/date.helper';
import { Request } from 'src/request/entity/request.entity';
import { InvoiceDetailQueryDto } from './dto/invoice-detail-query.dto';
import { RequestStatus } from 'src/request/constants';
import { ExcelService } from 'src/excel/excel.service';
import { Setting } from 'src/setting/entity/setting.entity';
import { BILL_DATE } from 'src/shared/constant/settings.constant';
import * as moment from 'moment';

@Injectable()
export class InvoiceService {
  constructor(
    @InjectRepository(Invoice) private invoiceRepository: Repository<Invoice>,
    private dataSource: DataSource,
    private excelService: ExcelService,
  ) {}

  async paginate(filter: InvoiceFindQueryDto): Promise<Pagination<Invoice>> {
    const qb = this.invoiceRepository.createQueryBuilder('invoice').withDeleted();
    qb.leftJoin('invoice.tenant', 'tenant');
    qb.where(`invoice.deleted_at IS NULL`);

    if (filter.tenantId) {
      qb.andWhere('invoice.tenantId = :tenantId', { tenantId: filter.tenantId });
    }

    if (filter.paymentStatus) {
      qb.andWhere('invoice.paymentStatus = :paymentStatus', { paymentStatus: filter.paymentStatus });
    }

    if (filter.billMonth) {
      qb.andWhere('invoice.startDate <= :billMonth AND invoice.endDate >= :billMonth', {
        billMonth: filter.billMonth + '-01',
      });
    }

    if (filter.sort) {
      qb.orderBy(getOrderByClause(filter.sort, 'invoice'));
    } else {
      qb.orderBy('invoice.startDate', 'DESC');
    }

    const results = await qb
      .select('invoice')
      .addSelect(['tenant.id', 'tenant.name'])
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();

    return new Pagination(results);
  }

  async findById(id: number): Promise<Invoice> {
    return this.invoiceRepository.findOneOrFail({
      where: {
        id: id,
      },
    });
  }

  async getInvoiceWithUsage(invoiceId: number): Promise<Invoice> {
    return await this.invoiceRepository
      .createQueryBuilder('invoice')
      .leftJoinAndSelect('invoice.usage', 'usage')
      .where('invoice.id = :invoiceId', { invoiceId: invoiceId })
      .getOneOrFail();
  }

  async getInvoiceWithTenant(invoiceId: number): Promise<Invoice> {
    return await this.invoiceRepository
      .createQueryBuilder('invoice')
      .withDeleted()
      .leftJoinAndSelect('invoice.tenant', 'tenant')
      .leftJoinAndSelect('invoice.usage', 'usage')
      .where('invoice.id = :invoiceId', { invoiceId: invoiceId })
      .andWhere('invoice.deletedAt IS NULL')
      .getOneOrFail();
  }

  async getRequestList(filter: InvoiceDetailQueryDto, tenantId: number, month: Date): Promise<Pagination<Request>> {
    const fromDate = getStartDateOfMonth(month);
    const toDate = getEndDateOfMonth(month);

    const qb = this.dataSource.manager
      .getRepository(Request)
      .createQueryBuilder('request')
      .leftJoinAndSelect('request.documents', 'documents')
      .leftJoinAndSelect('request.results', 'results')
      .where('request.tenant_id = :tenantId', { tenantId: tenantId })
      .andWhere('request.created_at >= :fromDate', { fromDate: fromDate })
      .andWhere('request.created_at <= :toDate', { toDate: toDate })
      .andWhere('request.status =:status', { status: RequestStatus.Completed })
      .groupBy('request.id')
      .orderBy('request.id', 'DESC');

    const results = await qb
      .select('request.*')
      .addSelect(`AVG(results.confidence)::numeric(3,0)`, 'confidence')
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getRawMany();

    const newQb = this.dataSource.manager
      .getRepository(Request)
      .createQueryBuilder('request')
      .where('request.tenant_id = :tenantId', { tenantId: tenantId })
      .andWhere('request.created_at >= :fromDate', { fromDate: fromDate })
      .andWhere('request.created_at <= :toDate', { toDate: toDate })
      .andWhere('request.status =:status', { status: RequestStatus.Completed });

    const total = await newQb.select('COUNT(request.*)', 'totalRequest').getRawOne();

    return new Pagination([results, total.totalRequest]);
  }

  async updatePaymentStatus(id: number, dto: UpdatePaymentStatusDto): Promise<Invoice> {
    const invoice = await this.invoiceRepository.findOneOrFail({
      where: {
        id: id,
      },
    });

    if (dto.paymentDate) {
      invoice.paidDate = dto.paymentDate;
    } else {
      invoice.paidDate = null;
    }

    invoice.paymentStatus = PaymentStatus.Overdue;
    const today = new Date();
    const dueDate = new Date(invoice.dueDate);

    if (invoice.paidDate && invoice.paidDate <= invoice.dueDate) {
      invoice.paymentStatus = PaymentStatus.Paid;
    } else if (!invoice.paidDate && today <= dueDate) {
      invoice.paymentStatus = PaymentStatus.Pending;
    }

    return this.invoiceRepository.save(invoice);
  }

  async exportExcel(invoice: Invoice): Promise<any> {
    const setting = await this.dataSource.manager.getRepository(Setting).findOne({
      where: { key: BILL_DATE },
    });

    if (setting) {
      const billDate = getFullInvoiceDateFromDay(moment(invoice.usage.month).format('YYYY-MM-DD'), +setting.value);

      return await this.excelService.exportInvoice(invoice, billDate);
    }
  }

  async updateOverdueInvoices() {
    const today = new Date();
    const firstDay = getStartDateOfMonth(today);
    await this.invoiceRepository
      .createQueryBuilder()
      .update(Invoice)
      .set({
        paymentStatus: PaymentStatus.Overdue,
      })
      .where('payment_status = :pendingStatus', { pendingStatus: PaymentStatus.Pending })
      .andWhere('due_date >= :fromDate', { fromDate: firstDay })
      .andWhere('due_date <= :toDate', { toDate: today })
      .execute();
  }
}
