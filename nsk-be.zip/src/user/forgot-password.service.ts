import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { MailService } from 'src/mail/mail.service';
import { User } from 'src/user/entity/user.entity';
import { UserService } from './user.service';
import { JwtService } from '@nestjs/jwt';
import { jwtConstants } from 'src/auth/constants';

@Injectable()
export class ForgotPasswordService {
  constructor(
    private mailService: MailService,
    private configService: ConfigService,
    private userService: UserService,
    private jwtService: JwtService,
  ) {}

  async getUserFromEmail(email: string) {
    return await this.userService.findByEmail(email);
  }

  async sendMailResetPassword(user: User, lang: string) {
    const payload = {
      email: user.email,
      user_id: user.id,
    };
    const expiredTime = this.configService.get('parameter').expiredTimePassword;
    const token = this.jwtService.sign(payload, { secret: jwtConstants.secret, expiresIn: expiredTime });

    const forgotPasswordUrl = await this.generateForgotPasswordUrl(user, token);

    if (!lang?.charAt(0)) {
      lang = 'en';
    }

    this.mailService.sendForgotPassword(user, forgotPasswordUrl, lang);
  }

  async generateForgotPasswordUrl(user: User, token: string) {
    return `${this.configService.get('APP_URL')}/reset-password?token=${token}`;
  }

  async verifyResetPasswordToken(token: string) {
    const payload = this.jwtService.verify(token, { secret: jwtConstants.secret });

    if (payload) {
      const user = this.userService.findById(payload.user_id);

      return user;
    }

    return null;
  }

  async updateNewPassword(user: User, newPassword: string) {
    return await this.userService.updatePassword(user, newPassword);
  }
}
