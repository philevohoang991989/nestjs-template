import { Tenant } from 'src/tenant/entity/tenant.entity';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  name: 'users',
})
export class User {
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @Column({
    name: 'email',
    length: 255,
    nullable: false,
  })
  @Index({
    unique: true,
  })
  email: string;

  @Column({
    name: 'password',
    nullable: false,
    select: false,
  })
  password: string;

  @Column({
    name: 'name',
    length: 255,
    nullable: false,
  })
  name: string;

  @Column({
    name: 'tenant_id',
    nullable: true,
  })
  tenantId: number;

  @ManyToOne(() => Tenant, { nullable: true, createForeignKeyConstraints: false })
  @JoinColumn({
    name: 'tenant_id',
  })
  @Index()
  tenant: Tenant;

  @Column({
    name: 'role_id',
    nullable: false,
  })
  roleId: number;

  @Column({
    name: 'is_active',
    default: true,
  })
  isActive: boolean;

  @CreateDateColumn({
    name: 'created_at',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
  })
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
  })
  deletedAt: Date;
}
