import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Headers,
  Inject,
  NotFoundException,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Request,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserFindQueryDto } from './dto/user-find-query.dto';
import { User } from './entity/user.entity';
import { UserService } from './user.service';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Roles } from 'src/user/constants';
import { RolesGuard } from 'src/shared/guards/roles.guard';

@ApiTags('user')
@Controller('user')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
@RolesDecorator(Roles.Partner)
export class UserController {
  constructor(private userSevice: UserService, @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger) {}

  @Get()
  @UseGuards(RolesGuard)
  async find(@Query(NormalizeFindQueryPipe) query: UserFindQueryDto): Promise<Pagination<User>> {
    try {
      return await this.userSevice.paginate(query);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get('me')
  async getCurrentUser(@Request() req): Promise<User> {
    const currentUserId = req.user.userId;
    const result = await this.userSevice.getExpiredDateOfUser(currentUserId);

    return {
      id: result.id,
      email: result.email,
      name: result.name,
      tenantId: result.tenantId,
      roleId: result.roleId,
      tenant: { expiredDate: result?.tenant?.expiredDate },
    } as User;
  }

  @Post()
  @UseGuards(RolesGuard)
  async create(@Body() dto: CreateUserDto, @Headers() headers) {
    try {
      dto.lang = headers?.lang;
      return await this.userSevice.create(dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get(':id')
  @UseGuards(RolesGuard)
  @ApiParam({ name: 'id' })
  async findById(@Param('id', ParseIntPipe) id: number): Promise<User> {
    try {
      return await this.userSevice.findById(id);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Put(':id')
  @UseGuards(RolesGuard)
  async update(@Param('id') id: number, @Body() dto: UpdateUserDto): Promise<User> {
    try {
      return await this.userSevice.update(id, dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Delete(':id')
  @UseGuards(RolesGuard)
  async delete(@Param('id') id: number): Promise<User> {
    try {
      return await this.userSevice.remove(id);
    } catch (e) {
      this.logger.error(e.message, e.stack, UserController.name);
      throw new BadRequestException(e.message);
    }
  }
}
