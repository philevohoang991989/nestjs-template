import { BadRequestException, NotFoundException, Body, Controller, Post, HttpCode, Headers } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { ForgotPasswordService } from './forgot-password.service';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { ForgotPasswordDto } from './dto/forgot-password.dto';

@ApiTags('forgot-password')
@Controller('forgot-password')
export class ForgotPasswordController {
  constructor(private forgotPasswordService: ForgotPasswordService) {}

  @Post()
  @HttpCode(200)
  async sendMailForgottPassword(@Body() dto: ForgotPasswordDto, @Headers() headers) {
    try {
      const user = await this.forgotPasswordService.getUserFromEmail(dto.email);
      await this.forgotPasswordService.sendMailResetPassword(user, headers.lang);

      return;
    } catch (error) {
      throw new NotFoundException(error.message);
    }
  }

  @Post('/reset')
  @HttpCode(200)
  async updateNewPassword(@Body() dto: ResetPasswordDto) {
    try {
      const user = await this.forgotPasswordService.verifyResetPasswordToken(dto.token);

      if (!user) {
        throw new BadRequestException();
      }

      await this.forgotPasswordService.updateNewPassword(user, dto.new_password);

      return;
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }
}
