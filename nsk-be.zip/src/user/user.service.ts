import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { EntityManager, Repository } from 'typeorm';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserFindQueryDto } from './dto/user-find-query.dto';
import { User } from './entity/user.entity';
import { MailService } from 'src/mail/mail.service';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
    private mailService: MailService,
    private configService: ConfigService,
  ) {}

  async paginate(filter: UserFindQueryDto): Promise<Pagination<User>> {
    const qb = this.userRepository.createQueryBuilder('user');

    if (filter.email) {
      qb.andWhere('user.email = :email', { email: filter.email });
    }

    if (filter.isActive) {
      qb.andWhere('user.is_active = :isActive', { isActive: filter.isActive });
    }

    const results = await qb
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();

    return new Pagination(results);
  }

  async findById(id: number): Promise<User> {
    return await this.userRepository.findOneOrFail({
      where: {
        id: id,
      },
    });
  }

  async findByEmail(email: string): Promise<any> {
    const qb = this.userRepository.createQueryBuilder('user');
    qb.addSelect('user.password');
    qb.where('LOWER(user.email) = LOWER(:email)', { email });

    return await qb.getOne();
  }

  async create(dto: CreateUserDto, manager?: EntityManager): Promise<User> {
    let plainPassword = dto.password;
    if (!plainPassword) {
      plainPassword = this.generateRandomPassword();
    }
    dto.password = await this.hashPassword(plainPassword);

    const userRepository = manager ? manager.getRepository(User) : this.userRepository;

    const user = await userRepository.save(dto);

    // Send email to user
    const loginUrl = `${this.configService.get('APP_URL')}/login`;

    if (!dto.lang?.charAt(0)) {
      dto.lang = 'en';
    }

    this.mailService.sendWelcomeEmail(loginUrl, user.email, plainPassword, dto.lang);

    return user;
  }

  async update(id: number, dto: UpdateUserDto): Promise<User> {
    const user = await this.userRepository.findOneOrFail({
      where: {
        id: id,
      },
    });

    if (dto.email) {
      user.email = dto.email;
    }

    if (dto.password) {
      user.password = await this.hashPassword(dto.password);
    }

    if (dto.isActive != null) {
      user.isActive = dto.isActive;
    }

    if (dto.name != null) {
      user.name = dto.name;
    }

    if (dto.roleId != null) {
      user.roleId = dto.roleId;
    }

    return this.userRepository.save(user);
  }

  async remove(id: number): Promise<User> {
    const user = await this.userRepository.findOneOrFail({
      where: {
        id: id,
      },
    });

    if (user) {
      this.userRepository.softRemove(user);
    }

    return user;
  }

  async updatePassword(user, newPassword) {
    user.password = await this.hashPassword(newPassword);

    const userUpdated = await this.userRepository.save(user);
    delete userUpdated.password;

    return userUpdated;
  }

  async hashPassword(plainPassword: string) {
    return bcrypt.hash(plainPassword, 10);
  }

  async compareHashedPassword(plain: string, hashed: string) {
    return bcrypt.compare(plain, hashed);
  }

  getRandomElement(arr: string[]) {
    const rand = Math.floor(Math.random() * arr.length);

    return arr[rand];
  }

  generateRandomPassword(length = 8) {
    /* eslint-disable */
    const uppercases = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    const lowercases = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    const specials = ['~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '-', '=', '{', '}', '[', ']', ':', ';', '?', ', ', '.', '|', '\\'];
    const numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    /* eslint-enable */

    const nonSpecials = [...uppercases, ...lowercases, ...numbers];

    let password = '';

    for (let i = 0; i < length; i++) {
      // Previous character is a special character
      if (i !== 0 && specials.includes(password[i - 1])) {
        password += this.getRandomElement(nonSpecials);
      } else password += this.getRandomElement([...nonSpecials, ...specials]);
    }

    return password;
  }

  findUserByTenant(tenantId: number) {
    return this.userRepository.findOneOrFail({
      where: {
        tenantId: tenantId,
      },
    });
  }

  async validateUserEmail(email: string, tenantId = null): Promise<boolean> {
    const qb = this.userRepository.createQueryBuilder('user').withDeleted();
    qb.leftJoinAndSelect('user.tenant', 'tenant');
    qb.where('email = :email', { email: email });
    if (tenantId) {
      qb.andWhere('tenant.id != :tenantId', { tenantId: tenantId });
    }

    return !(await qb.getOne());
  }

  async getExpiredDateOfUser(userId: number) {
    const qb = this.userRepository.createQueryBuilder('user');
    qb.leftJoin('user.tenant', 'tenant');
    qb.where('user.id = :id', { id: userId });
    qb.select('user').addSelect('tenant.expiredDate');

    return await qb.getOne();
  }
}
