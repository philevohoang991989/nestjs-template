export enum Roles {
  Partner = 1,
  Tenant = 2,
}
