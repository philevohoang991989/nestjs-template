import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Roles } from '../constants';
import { IsOptional, IsStrongPassword, Matches } from 'class-validator';

export class CreateUserDto {
  @ApiProperty()
  email: string;

  @ApiProperty()
  @IsStrongPassword({
    minLength: 8,
    minLowercase: 1,
    minUppercase: 1,
    minNumbers: 1,
    minSymbols: 1,
  })
  password: string;

  @ApiProperty()
  name: string;

  @ApiPropertyOptional()
  tenantId?: number;

  @ApiProperty({
    enum: Roles,
  })
  roleId: number;

  @ApiPropertyOptional({
    description: 'Select language: en or jp',
  })
  @IsOptional()
  @Matches(/^(?:en|jp)?$/, { message: 'Invalid lang param format' })
  lang?: string;
}
