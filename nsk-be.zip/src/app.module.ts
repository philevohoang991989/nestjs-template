import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { AuthModule } from './auth/auth.module';
import databaseConfig from './shared/config/database.config';
import { utilities as nestWinstonModuleUtilities, WinstonModule } from 'nest-winston';
import { MailModule } from './mail/mail.module';
import { TenantModule } from './tenant/tenant.module';
import { TemplateModule } from './template/template.module';
import { SettingModule } from './setting/setting.module';
import { RequestModule } from './request/request.module';
import * as winston from 'winston';
import { CacheModule, CacheStore } from '@nestjs/cache-manager';
import { redisStore } from 'cache-manager-redis-yet';
import redisConfig from './shared/config/redis.config';
import jwtConfig from './shared/config/jwt.config';
import { InvoiceModule } from './invoice/invoice.module';
import { UsageModule } from './usage/usage.module';
import { GlobalHttpModule } from './shared/module/global-http.module';
import { ScheduleModule } from '@nestjs/schedule';
import { CronModule } from './cron/cron.module';
import { ExcelModule } from './excel/excel.module';
import { I18nModule, AcceptLanguageResolver, QueryResolver, HeaderResolver } from 'nestjs-i18n';
import i18nConfig from './shared/config/i18n.config';
import { EventModule } from './event/event.module';
import parameterConfig from './shared/config/parameter.config';
import cacheConfig from './shared/config/cache.config';

import { BullModule } from '@nestjs/bull';
import appConfig from './shared/config/app.config';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig, databaseConfig, redisConfig, jwtConfig, i18nConfig, parameterConfig, cacheConfig],
    }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        ...configService.get('database'),
      }),
    }),
    BullModule.forRootAsync({
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        redis: {
          host: configService.get('cache.host'),
          port: configService.get('cache.port'),
          password: configService.get('cache.password'),
        },
      }),
    }),
    CacheModule.registerAsync({
      isGlobal: true,
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => {
        const store = await redisStore({
          socket: {
            ...configService.get('redis'),
          },
          password: configService.get('redis').password,
        });
        return {
          store: store as unknown as CacheStore,
        };
      },
    }),
    I18nModule.forRootAsync({
      useFactory: (configService: ConfigService) => ({
        ...configService.get('i18n'),
      }),
      resolvers: [new QueryResolver(['lang', 'l']), new HeaderResolver(['x-custom-lang']), AcceptLanguageResolver],
      inject: [ConfigService],
    }),
    WinstonModule.forRoot({
      level: 'debug',
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.timestamp(),
            winston.format.ms(),
            nestWinstonModuleUtilities.format.nestLike('Nest', { colors: true, prettyPrint: true }),
          ),
        }),
        // Un-comment below transport to log into file
        // new winston.transports.File({
        //   filename: 'app.log',
        //   format: winston.format.combine(
        //     winston.format.timestamp(),
        //     winston.format.prettyPrint(),
        //   ),
        // })
      ],
    }),
    ScheduleModule.forRoot(),
    GlobalHttpModule,
    CronModule,
    UserModule,
    AuthModule,
    MailModule,
    TenantModule,
    TemplateModule,
    SettingModule,
    InvoiceModule,
    UsageModule,
    RequestModule,
    ExcelModule,
    EventModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
