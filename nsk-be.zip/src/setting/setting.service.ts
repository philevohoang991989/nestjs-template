import { Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Setting } from './entity/setting.entity';
import { Repository } from 'typeorm';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { UpdateSettingDto } from './dto/update-setting.dto';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class SettingService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    @InjectRepository(Setting) private settingRepository: Repository<Setting>,
    private configService: ConfigService,
  ) {}

  async findAll() {
    const settings = await this.settingRepository.find();

    const result = Object.fromEntries(settings.map((setting) => [setting.key, setting.value]));
    result.pages_per_block = this.configService.get('parameter').pagePerBlock;
    result.blocks_per_package = this.configService.get('parameter').blocksPerPackage;

    return result;
  }

  async update(dto: UpdateSettingDto) {
    const updateData = [];
    for (const index in dto) {
      updateData.push({ key: index, value: dto[index] });
    }

    return this.settingRepository.upsert(updateData, ['key']);
  }
}
