import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, Matches } from 'class-validator';

export class UpdateSettingDto {
  @ApiPropertyOptional()
  company_name?: string;

  @ApiPropertyOptional()
  description?: string;

  @ApiPropertyOptional()
  address?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Matches(/^(?:[^\s@]+@[^\s@]+\.[^\s@]+|)$/, { message: 'Invalid contact_email format' })
  contact_email?: string;

  @ApiPropertyOptional()
  contact_name?: string;

  @ApiPropertyOptional()
  phone_number?: string;

  @ApiPropertyOptional()
  bill_date?: string;

  @ApiPropertyOptional()
  last_payment_date?: string;
}
