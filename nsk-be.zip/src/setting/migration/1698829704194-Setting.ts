import { MigrationInterface, QueryRunner } from 'typeorm';

export class Setting1698829704194 implements MigrationInterface {
  name = 'Setting1698829704194';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "settings" (
                "id" BIGSERIAL NOT NULL,
                "key" character varying(255) NOT NULL,
                "value" character varying(255) NOT NULL,
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                CONSTRAINT "UQ_c8639b7626fa94ba8265628f214" UNIQUE ("key"),
                CONSTRAINT "PK_0669fe20e252eb692bf4d344975" PRIMARY KEY ("id")
            )
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            DROP TABLE "settings"
        `);
  }
}
