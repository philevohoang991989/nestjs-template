import { BadRequestException, Body, Controller, Get, Inject, NotFoundException, Put, UseGuards } from '@nestjs/common';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { SettingService } from './setting.service';
import { Logger } from 'winston';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { UpdateSettingDto } from './dto/update-setting.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';

@ApiTags('setting')
@Controller('settings')
@UseGuards(new JwtAuthGuard())
@ApiBearerAuth()
export class SettingController {
  constructor(
    private settingService: SettingService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
  ) {}

  @Get()
  @ApiOperation({
    summary: 'Get all settings',
  })
  async find() {
    try {
      return await this.settingService.findAll();
    } catch (e) {
      this.logger.error(e.message, e.stack, SettingController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Put()
  @ApiOperation({
    summary: 'Update settings',
  })
  async update(@Body() dto: UpdateSettingDto) {
    try {
      return await this.settingService.update(dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, SettingController.name);
      throw new BadRequestException(e.message);
    }
  }
}
