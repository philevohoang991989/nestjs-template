import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Result } from './entity/result.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ResultService {
  constructor(@InjectRepository(Result) private resultRepository: Repository<Result>) {}

  async findByRequest(requestId: number) {
    return await this.resultRepository.findOneOrFail({
      where: {
        requestId: requestId,
      },
    });
  }
}
