import { OnQueueCompleted, Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import { OcrService } from './ocr.service';

@Processor('ocr-shiba-queue')
export class RequestProcessor {
  constructor(private ocrService: OcrService) {}

  // consumer
  @Process()
  async handleRequest(job: Job) {
    await this.ocrService.sendFileToOCR(job.data);
    return {};
  }

  // listener
  @OnQueueCompleted()
  async onCompleted(job: Job) {
    await job?.remove();
  }
}
