import { MigrationInterface, QueryRunner } from 'typeorm';

export class Document1699436547601 implements MigrationInterface {
  name = 'Document1699436547601';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "documents"
            ADD "description" character varying(512)
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "documents" DROP COLUMN "description"
        `);
  }
}
