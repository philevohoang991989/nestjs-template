import { MigrationInterface, QueryRunner } from 'typeorm';

export class Request1698674930190 implements MigrationInterface {
  name = 'Request1698674930190';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "requests" (
                "id" BIGSERIAL NOT NULL,
                "tenant_id" bigint NOT NULL,
                "name" character varying(255) NOT NULL,
                "user_id" bigint NOT NULL,
                "template_id" bigint NOT NULL,
                "status" smallint NOT NULL,
                "is_downloaded" smallint NOT NULL DEFAULT 0,
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                CONSTRAINT "PK_0428f484e96f9e6a55955f29b5f" PRIMARY KEY ("id")
            )
        `);
    await queryRunner.query(`
        CREATE INDEX "IDX_f404bc4cead28da5372fc34c9c" ON "requests" ("tenant_id")
    `);
    await queryRunner.query(`
        ALTER TABLE "requests"
        ADD CONSTRAINT "FK_f404bc4cead28da5372fc34c9c7" FOREIGN KEY ("tenant_id") REFERENCES "tenants"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    await queryRunner.query(`
        CREATE INDEX "IDX_59b85be6a3c16cbf27f8bdda1d" ON "requests" ("status")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        ALTER TABLE "requests" DROP CONSTRAINT "FK_f404bc4cead28da5372fc34c9c7"
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_f404bc4cead28da5372fc34c9c"
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_59b85be6a3c16cbf27f8bdda1d"
    `);
    await queryRunner.query(`
        DROP TABLE "requests"
    `);
  }
}
