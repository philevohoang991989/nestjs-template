import { MigrationInterface, QueryRunner } from 'typeorm';

export class Document_DefaultValue1702534509655 implements MigrationInterface {
  name = 'Document_DefaultValue1702534509655';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "documents"
            ALTER COLUMN "page_count"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "documents"
            ALTER COLUMN "page_count"
            SET DEFAULT '0'
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "documents"
            ALTER COLUMN "page_count" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "documents"
            ALTER COLUMN "page_count" DROP NOT NULL
        `);
  }
}
