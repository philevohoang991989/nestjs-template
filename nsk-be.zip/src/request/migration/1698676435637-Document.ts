import { MigrationInterface, QueryRunner } from 'typeorm';

export class Document1698676435637 implements MigrationInterface {
  name = 'Document1698676435637';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "documents" (
                "id" BIGSERIAL NOT NULL,
                "request_id" bigint NOT NULL,
                "name" character varying(255) NOT NULL,
                "path" character varying(512) NOT NULL,
                "page_count" integer,
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                CONSTRAINT "PK_ac51aa5181ee2036f5ca482857c" PRIMARY KEY ("id")
            )
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_640ed9849e6eb66177436f91f5" ON "documents" ("request_id")
        `);
    await queryRunner.query(`
            ALTER TABLE "documents"
            ADD CONSTRAINT "FK_640ed9849e6eb66177436f91f50" FOREIGN KEY ("request_id") REFERENCES "requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "documents" DROP CONSTRAINT "FK_640ed9849e6eb66177436f91f50"
        `);
    await queryRunner.query(`
            DROP INDEX "public"."IDX_640ed9849e6eb66177436f91f5"
        `);
    await queryRunner.query(`
            DROP TABLE "documents"
        `);
  }
}
