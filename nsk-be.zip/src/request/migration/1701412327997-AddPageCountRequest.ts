import { MigrationInterface, QueryRunner } from 'typeorm';

export class Request1701412327997 implements MigrationInterface {
  name = 'Request1701412327997';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "requests"
      ADD "page_count" integer
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "requests" DROP COLUMN "page_count"
    `);
  }
}
