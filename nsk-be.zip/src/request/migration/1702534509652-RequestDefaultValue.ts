import { MigrationInterface, QueryRunner } from 'typeorm';

export class Request_DefaultValue1702534509652 implements MigrationInterface {
  name = 'Request_DefaultValue1702534509652';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "requests"
            ALTER COLUMN "status"
            SET DEFAULT '1'
        `);
    await queryRunner.query(`
            ALTER TABLE "requests" DROP COLUMN "is_downloaded"
        `);
    await queryRunner.query(`
            ALTER TABLE "requests"
            ADD "is_downloaded" boolean NOT NULL DEFAULT false
        `);
    await queryRunner.query(`
            ALTER TABLE "requests"
            ALTER COLUMN "page_count"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "requests"
            ALTER COLUMN "page_count"
            SET DEFAULT '0'
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "requests"
            ALTER COLUMN "page_count" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "requests"
            ALTER COLUMN "page_count" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "requests" DROP COLUMN "is_downloaded"
        `);
    await queryRunner.query(`
            ALTER TABLE "requests"
            ADD "is_downloaded" smallint NOT NULL DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "requests"
            ALTER COLUMN "status" DROP DEFAULT
        `);
  }
}
