import { MigrationInterface, QueryRunner } from 'typeorm';

export class Result_DefaultValue1702534509656 implements MigrationInterface {
  name = 'Result_DefaultValue1702534509656';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "results"
            ALTER COLUMN "confidence"
            SET DEFAULT '0'
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "results"
            ALTER COLUMN "confidence" DROP DEFAULT
        `);
  }
}
