import { MigrationInterface, QueryRunner } from 'typeorm';

export class Result1699428271969 implements MigrationInterface {
  name = 'Result1699428271969';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "results" (
                "id" BIGSERIAL NOT NULL,
                "request_id" bigint NOT NULL,
                "confidence" smallint NOT NULL,
                "result" jsonb NOT NULL,
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                CONSTRAINT "PK_e8f2a9191c61c15b627c117a678" PRIMARY KEY ("id")
            )
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_b692fbc96d9ffe4ee3115d1f75" ON "results" ("request_id")
        `);
    await queryRunner.query(`
            ALTER TABLE "results"
            ADD CONSTRAINT "FK_b692fbc96d9ffe4ee3115d1f757" FOREIGN KEY ("request_id") REFERENCES "requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "results" DROP CONSTRAINT "FK_b692fbc96d9ffe4ee3115d1f757"
        `);
    await queryRunner.query(`
            DROP INDEX "public"."IDX_b692fbc96d9ffe4ee3115d1f75"
        `);
    await queryRunner.query(`
            DROP TABLE "results"
        `);
  }
}
