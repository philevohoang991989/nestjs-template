import { Inject, Injectable } from '@nestjs/common';
import { PDFDocument } from 'pdf-lib';
import { CreateRequestDto } from './dto/create-request.dto';
import { Request } from './entity/request.entity';
import { RequestStatus } from './constants';
import { Document } from './entity/document.entity';
import { DataSource, Repository } from 'typeorm';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { TenantService } from 'src/tenant/tenant.service';
import { Usage } from 'src/usage/entity/usage.entity';
import { addDate, formatDate, getFirstDayOfCurrentMonth } from 'src/shared/helpers/date.helper';
import { ConfigService } from '@nestjs/config';
import { OcrService } from './ocr.service';
import { TemplateService } from 'src/template/template.service';
import { InjectRepository } from '@nestjs/typeorm';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { RequestFindQueryDto } from './dto/request-find-query.dto';
import { UpdateDownloadStatusDto } from './dto/update-download-status.dto';
import { I18nContext, I18nService } from 'nestjs-i18n';
import { throwValidationException } from 'src/shared/helpers/validation.helper';
import { API_CODE } from 'src/shared/constant/api-code.constant';
import { RequestFindExportQueryDto } from './dto/request-find-export-query.dto';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { ResultService } from './result.service';

import { Queue } from 'bull';
import { InjectQueue } from '@nestjs/bull';

/* eslint-disable */
const fs = require('fs');

@Injectable()
export class RequestService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    @InjectRepository(Request) private requestRepository: Repository<Request>,
    private dataSource: DataSource,
    private tenantService: TenantService,
    private configService: ConfigService,
    private ocrService: OcrService,
    private templateService: TemplateService,
    private readonly i18n: I18nService,
    private resultService: ResultService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
    @InjectQueue('ocr-shiba-queue') private readonly ocrQueue: Queue,
  ) {}

  async create(
    file: Express.Multer.File,
    dto: CreateRequestDto, userId: number,
    tenantId: number,
    pageCount: number
    ): Promise<any> {
    // Prepare request and document
    const request = new Request();
    request.tenantId = tenantId;
    request.name = dto.name || file.originalname;
    request.userId = userId;
    request.templateId = dto.templateId;
    request.status = RequestStatus.Processing;
    request.pageCount = pageCount;

    const document = new Document();
    document.name = file.originalname;
    document.path = file.path;
    document.pageCount = pageCount;

    // Insert request and document
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const createdRequest = await queryRunner.manager.save(request);

      const month = getFirstDayOfCurrentMonth();
      const pageUsed = await this.cacheManager.get(`PageCount_${tenantId}_${month}`);
      await this.cacheManager.set(`PageCount_${tenantId}_${month}`, pageCount + +pageUsed, this.configService.get('cache').pageCountExpTime);
      document.requestId = createdRequest.id;
      await queryRunner.manager.save(document);

      await queryRunner.commitTransaction();

      // Log request id
      this.logger.log(`===== REQUEST ID: ${createdRequest.id} =====`, RequestService.name);
      this.logger.log(`Create request into database successfully!`, RequestService.name);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestService.name);
      await queryRunner.rollbackTransaction();

      throw e;
    } finally {
      await queryRunner.release();
    }

    const template = await this.templateService.findById(dto.templateId, tenantId);

    // Call ocr api async
    // this.ocrService.sendFileToOCR(file, tenantId, request.id, document.pageCount, template);
    const payload = {
      filePath: file.path, 
      tenantId, 
      requestId: request.id, 
      pageCount: document.pageCount, 
      template
    }
    const templateName = template.name || '';
    const isShibaTemplate = templateName.includes('shiba');
    if (isShibaTemplate && this.configService.get('app').useQueueApiCall == 'true') {
      await this.ocrQueue.add(payload);
    } else {
      this.ocrService.sendFileToOCR(payload);
    }
    
    // this.ocrService.sendFileToOCR(payload);

    return {
      pageCount,
      requestId: +request.id,
    };
  }

  async countPage(file: Express.Multer.File): Promise<number> {
    const uint8Array = fs.readFileSync(file.path);
    const pdf = await PDFDocument.load(uint8Array, { ignoreEncryption: true  });

    return pdf.getPageCount();
  }

  async getCurrentPageCount(tenantId: number, month?: Date): Promise<number> {
    if (!month) month = getFirstDayOfCurrentMonth();

    let pageCount = await this.cacheManager.get(`PageCount_${tenantId}_${month}`);

    if (!pageCount) {
      const usage = await this.dataSource.manager.findOne(Usage, {
        select: {
          id: true,
          pageCount: true,
        },
        where: {
          tenantId: tenantId,
          month: month,
        },
      });
  
      pageCount = usage ? usage.pageCount : 0;
      await this.cacheManager.set(`PageCount_${tenantId}_${month}`, pageCount, this.configService.get('cache').pageCountExpTime);
    }

    return +pageCount;
  }

  async validateQuota(tenantId: number, file?: Express.Multer.File, pageCount?: number): Promise<any> {
    if (!pageCount) {
      if (file.mimetype.match(/\/(pdf)$/)) {
        pageCount = await this.countPage(file);
      } else {
        // Image page count always equal 1
        pageCount = 1;
      }
    }

    const limitPagePerRequest = parseInt(this.configService.get('parameter').limitPagesPerRequest);

    if (pageCount > limitPagePerRequest) {
      throwValidationException(API_CODE.OVER_LIMIT_PAGE_PER_REQUEST,  {
        maxPagesPerRequest: limitPagePerRequest,
        currentPages: pageCount
      });
    }

    const tenant = await this.tenantService.findById(tenantId);
    const today = new Date();

    if (tenant.expiredDate && new Date(tenant.expiredDate) < today) {
      throwValidationException(API_CODE.TENANT_EXPIRED_CODE);
    }

    const pagesPerBlock = this.configService.get('parameter').pagePerBlock;
    const totalPage = tenant.currentMonthBlocks * pagesPerBlock;

    // Get current month page count of tenant
    const currentPageCount = await this.getCurrentPageCount(tenantId);
    const remainPageCount = totalPage - currentPageCount;
    const validQuota = (remainPageCount >= pageCount);

    return {
      validQuota,
      remainPageCount,
      pageCount,
    };
  }

  async paginate(filter: RequestFindQueryDto, tenantId: number): Promise<Pagination<any>> {
    const qb = this.requestRepository.createQueryBuilder('request');
    qb.leftJoin('request.results', 'results');
    qb.where('request.tenantId = :tenantId', { tenantId: tenantId });

    if (filter.name) {
      const name = filter.name.trim();

      if (parseInt(name).toString() == name) {
        qb.andWhere('(request.name ILIKE :name OR request.id = :number)', { name: `%${name}%`, number: parseInt(name) });
      } else {
        qb.andWhere('request.name ILIKE :name', { name: `%${name}%` });
      }
    }

    if (filter.status) {
      qb.andWhere('request.status = :status', { status: filter.status });
    }

    if (filter.fromDate) {
      qb.andWhere('request.createdAt >= :fromDate', { fromDate: filter.fromDate });
    }

    if (filter.toDate) {
      qb.andWhere('request.createdAt <= :toDate', { toDate: addDate(new Date(filter.toDate), 1) });
    }

    if (filter.sort) {
      qb.orderBy(getOrderByClause(filter.sort, 'request'));
    } else {
      qb.orderBy('request.id', 'DESC');
    }

    const results = await qb
      .select('request')
      .addSelect('results.confidence')
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();

    const resultItem = results[0].map((element: Request) => {
      return {
        ...element,
        results: element?.results[0] || {}
      };
    });

    return new Pagination([resultItem, results[1]]);
  }

  async decorateRequestListForExport(requestData: Pagination<any>, offset = null) {
    let row = 2;
    let data = [];

    requestData.items.forEach(element => {
      data.push(
        { cell: 'A' + row, value: element.id },
        { cell: 'B' + row, value: element.templateId },
        { cell: 'C' + row, value: element.name },
        { cell: 'D' + row, value: this.i18n.t('requests.Status.' + element.status, { lang: I18nContext.current().lang }) },
        { cell: 'E' + row, value: element?.results?.confidence },
        { cell: 'F' + row, value: element.pageCount },
        { cell: 'G' + row, value: formatDate(element.createdAt, 'yyyy-MM-dd HH:mm:ss', offset) },
        { cell: 'H' + row, value: element.isDownloaded ? this.i18n.t('requests.Yes', { lang: I18nContext.current().lang }) : '' },
      );
      row++;
    });

    return data;
  }

  async findById(id: number) {
    return await this.requestRepository.findOneOrFail({
      where: {
        id: id,
      },
    });
  }

  async changeStatusDownload(request: Request, status: boolean) {
    request.isDownloaded = status;
    return await this.requestRepository.save(request);
  }

  async updateStatusDownload(id: number, updateDownloadStatusDto: UpdateDownloadStatusDto, tenantId: number) {
    const request = await this.findById(id);

    if (request.tenantId != tenantId || request.status != RequestStatus.Completed) {
      throwValidationException(API_CODE.INVADLID_TENANT_CODE);
    }

    return this.changeStatusDownload(request, updateDownloadStatusDto.downloadStatus);
  }

  async exportRequestList(query: RequestFindExportQueryDto, tenantId: number) {
    query.limit = 0;
    query.page = 1;
    const requestData = await this.paginate(query, tenantId);
    const data = await this.decorateRequestListForExport(requestData, query.offset);

    return {
      data,
      fileName: `./src/excel/template/Request_List_Export_${I18nContext.current().lang}.xlsx`
    }
  }

  async exportRequest(id: number, tenantId: number) {
    const request = await this.findById(id);
    this.changeStatusDownload(request, true);

    if (request.tenantId != tenantId) {
      throwValidationException(API_CODE.INVADLID_TENANT_CODE);
    }

    const result = await this.resultService.findByRequest(id);
    const resultData = JSON.parse(JSON.stringify(result.result));

    if (!resultData?.results) {
      return [];
    }
    if (resultData && resultData.results && resultData.results.length && resultData.results[0].requestType == 'shiba') {
      return [{requestType:'shiba', ...resultData}]
    }

    return this.getRequestDataForExport(resultData);
  }

  getRequestDataForExport(resultData: any) {
    const dataField = [],
      dataTable = [];
    const dataFieldCheck = {};

    resultData.results.forEach(
      (resultItem: { hasOwnProperty: (arg0: string) => any; fields: { k: any; v: any }[]; table: any[] }) => {
        if (resultItem.hasOwnProperty('fields')) {
          resultItem.fields.forEach((element: { k: any; v: any }) => {
            if (!dataFieldCheck.hasOwnProperty(element.k)) {
              dataField.push([element.k, element.v]);
              dataFieldCheck[element.k] = element.v;
            }
          });
        }

        if (resultItem.hasOwnProperty('table')) {
          resultItem.table.forEach((element, index: any) => {
            if (index || !dataTable.length) {
              dataTable.push(element);
            }
          });
        }
      },
    );

    return dataField.concat([], dataTable);
  }
}
