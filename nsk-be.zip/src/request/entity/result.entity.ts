import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Request } from './request.entity';
import { ApiProperty } from '@nestjs/swagger';

@Entity({
  name: 'results',
})
export class Result {
  @ApiProperty()
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @ApiProperty()
  @Column({
    name: 'request_id',
    nullable: false,
  })
  requestId: number;

  @ManyToOne(() => Request, { nullable: false })
  @JoinColumn({
    name: 'request_id',
  })
  @Index()
  request: Request;

  @ApiProperty()
  @Column({
    name: 'confidence',
    type: 'smallint',
    default: 0,
  })
  confidence: number;

  @ApiProperty()
  @Column({
    name: 'result',
    type: 'jsonb',
    nullable: false,
  })
  result: object;

  @ApiProperty()
  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @ApiProperty()
  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamptz',
  })
  deletedAt: Date;
}
