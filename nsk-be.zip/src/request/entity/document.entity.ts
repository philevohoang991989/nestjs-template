import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Request } from './request.entity';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

@Entity({
  name: 'documents',
})
export class Document {
  @ApiProperty()
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @Column({
    name: 'request_id',
    nullable: false,
  })
  requestId: number;

  @ManyToOne(() => Request, { nullable: false })
  @JoinColumn({
    name: 'request_id',
  })
  @Index()
  request: Request;

  @ApiProperty()
  @Column({
    name: 'name',
    length: 255,
    nullable: false,
  })
  name: string;

  @ApiPropertyOptional()
  @Column({
    name: 'description',
    length: 512,
    nullable: true,
  })
  description: string;

  @ApiProperty()
  @Column({
    name: 'path',
    length: 512,
    nullable: false,
  })
  path: string;

  @ApiPropertyOptional()
  @Column({
    name: 'page_count',
    default: 0,
  })
  pageCount: number;

  @ApiProperty()
  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @ApiProperty()
  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamptz',
  })
  deletedAt: Date;
}
