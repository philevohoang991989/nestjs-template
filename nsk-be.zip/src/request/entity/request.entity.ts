import { Tenant } from 'src/tenant/entity/tenant.entity';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Document } from './document.entity';
import { Result } from './result.entity';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { formatDate } from 'src/shared/helpers/date.helper';
@Entity({
  name: 'requests',
})
export class Request {
  @ApiProperty()
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @Column({
    name: 'tenant_id',
    nullable: false,
  })
  tenantId: number;

  @ApiProperty()
  @ManyToOne(() => Tenant, { nullable: false })
  @JoinColumn({
    name: 'tenant_id',
  })
  @Index()
  tenant: Tenant;

  @ApiProperty()
  @Column({
    name: 'name',
    length: 255,
    nullable: false,
  })
  name: string;

  @Column({
    name: 'user_id',
    type: 'bigint',
    nullable: false,
  })
  userId: number;

  @Column({
    name: 'template_id',
    type: 'bigint',
    nullable: false,
  })
  templateId: number;

  @ApiProperty()
  @Column({
    name: 'status',
    type: 'smallint',
    default: 1,
  })
  @Index()
  status: number;

  @ApiProperty()
  @Column({
    name: 'is_downloaded',
    default: false,
  })
  isDownloaded: boolean;

  @ApiPropertyOptional()
  @Column({
    name: 'page_count',
    default: 0,
  })
  pageCount: number;

  @ApiProperty()
  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @ApiProperty()
  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  @Transform(({ value }) => formatDate(value, 'yyyy-MM-dd HH:mm:ss'))
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamptz',
  })
  deletedAt: Date;

  @OneToMany(() => Document, (document) => document.request)
  documents: Document[];

  @OneToMany(() => Result, (result) => result.request)
  results: Result[];
}
