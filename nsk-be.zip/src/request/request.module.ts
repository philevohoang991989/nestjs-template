import { Module } from '@nestjs/common';
import { RequestService } from './request.service';
import { RequestController } from './request.controller';
import { UserModule } from 'src/user/user.module';
import { TenantModule } from 'src/tenant/tenant.module';
import { OcrService } from './ocr.service';
import { TemplateModule } from 'src/template/template.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Request } from './entity/request.entity';
import { ResultService } from './result.service';
import { Result } from './entity/result.entity';
import { ExcelModule } from 'src/excel/excel.module';
import { BullModule } from '@nestjs/bull';
import { RequestProcessor } from './request.processor';

@Module({
  imports: [
    UserModule,
    TenantModule,
    TemplateModule,
    TypeOrmModule.forFeature([Request, Result]),
    ExcelModule,
    BullModule.registerQueue({
      name: 'ocr-shiba-queue',
    }),
  ],
  providers: [RequestService, OcrService, ResultService, RequestProcessor],
  controllers: [RequestController],
  exports: [],
})
export class RequestModule {}
