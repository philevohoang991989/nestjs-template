import { Inject, Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import * as FormData from 'form-data';
import { AxiosError, AxiosRequestConfig } from 'axios';
import { catchError, lastValueFrom, map } from 'rxjs';
import { Request } from './entity/request.entity';
import { RequestStatus } from './constants';
import { DataSource } from 'typeorm';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { Usage } from 'src/usage/entity/usage.entity';
import { getFirstDayOfCurrentMonth } from 'src/shared/helpers/date.helper';
import { Template } from 'src/template/entity/template.entity';
import { Exception } from 'handlebars';
import { Result } from './entity/result.entity';
import { OcrResultDto } from './dto/ocr-result.dto';
import { EventService } from 'src/event/event.service';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { ConfigService } from '@nestjs/config';

/* eslint-disable */
const fs = require('fs');

@Injectable()
export class OcrService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    private dataSource: DataSource,
    private httpService: HttpService,
    private eventService: EventService,
    private configService: ConfigService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) {}

  async sendFileToOCR(
    { filePath, tenantId, requestId, pageCount, template }: { filePath: string, tenantId: number, requestId: number, pageCount: number, template: Template }
    // file: Express.Multer.File,
    // filePath: string,
    // tenantId: number,
    // requestId: number,
    // pageCount: number,
    // template: Template,
  ): Promise<any> {
    // Channel name
    const channelName = `Channel_${tenantId}`;

    try {
      // Perform to ocr a document
      // const ocrResult = await this.callApiToOcrService(file, tenantId, requestId, pageCount, template);
      const ocrResult = await this.callApiToOcrService(filePath, tenantId, requestId, pageCount, template);

      // Log request id
      this.logger.log(`===== REQUEST ID: ${requestId} =====`, OcrService.name);
      this.logger.log(`Receive the OCR result sucessfully!`, OcrService.name);

      if (!ocrResult) {
        // Log request id
        this.logger.log(`===== REQUEST ID: ${requestId} =====`, OcrService.name);
        this.logger.log(`Ocr result is null`, OcrService.name);

        throw new Exception('Ocr a document has failed');
      }

      // Log request id
      this.logger.log(`===== REQUEST ID: ${requestId} =====`, OcrService.name);
      this.logger.log(`Ocr upload success!`, OcrService.name);
      const result = await this.updateOcrResultSuccess(tenantId, requestId, pageCount, ocrResult);

      // log request id
      this.logger.log(`===== REQUEST ID: ${requestId} =====`, OcrService.name);
      this.logger.log(`Call API update status and usage OCR Service `, OcrService.name);
      await this.callApiUpdateStatusOcr(tenantId, requestId, pageCount);

      // Publish message to client
      this.eventService.socket.to(channelName).emit('updateOcrResult', {
        id: requestId,
        status: RequestStatus.Completed,
        results: {
          confidence: result.confidence,
        }
      });

    } catch (e) {
      this.logger.error(e.message, e.stack, OcrService.name);
      // Log request id
      this.logger.log(`===== REQUEST ID: ${requestId} =====`, OcrService.name);
      this.logger.log(`Ocr upload error! ==`, OcrService.name);

      await this.updateOcrResultError(requestId);

      const month = getFirstDayOfCurrentMonth();
      const pageUsed = await this.cacheManager.get(`PageCount_${tenantId}_${month}`);
      await this.cacheManager.set(`PageCount_${tenantId}_${month}`, +pageUsed - pageCount, this.configService.get('cache').pageCountExpTime);

      // Publish message to client
      this.eventService.socket.to(channelName).emit('updateOcrResult', {
        id: requestId,
        status: RequestStatus.Failed,
        results: {
          confidence: 0,
        }
      });
    }
  }

  async callApiToOcrService(
    // file: Express.Multer.File,
    filePath: string,
    tenantId: number,
    requestId: number,
    pageCount: number,
    template: Template,
  ) {
    const shortTemplate = (({ code, name, fields, tableFields }) => ({ code, name, fields, tableFields }))(template);

    // Log request id
    this.logger.log(`===== REQUEST ID: ${requestId} =====`, OcrService.name);
    this.logger.log(`== Start to call the Ocr Service API ==`, OcrService.name);

    // Create form to call API
    const form: FormData = new FormData();
    form.append('refTenantId', tenantId);
    form.append('refRequestId', requestId);
    form.append('refPageCount', pageCount);
    form.append('template', JSON.stringify(shortTemplate));
    // form.append('document', fs.createReadStream(file.path));
    form.append('document', fs.createReadStream(filePath));

    const requestConfig: AxiosRequestConfig = {
      headers: { 'Content-Type': 'multipart/form-data' },
    };

    const result = await lastValueFrom(
      this.httpService.post('/ocr', form, requestConfig).pipe(
        map((response) => response?.data),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, OcrService.name);
          throw e;
        }),
      ),
    );

    return result;
  }

  async callApiUpdateStatusOcr(
    tenantId: number,
    requestId: number,
    pageCount: number
  ) {
    // Create form to call API update status
    const dataStatus = {
      refRequestId: requestId,
      refTenantId: tenantId,
      refPageCount: pageCount
    };

    return await lastValueFrom(
      this.httpService.post('/ocr/update-status', dataStatus).pipe(
        map((response) => response?.data),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, OcrService.name);
          throw e;
        }),
      ),
    );
  }

  async updateOcrResultSuccess(tenantId: number, requestId: number, pageCount: number, ocrResult: OcrResultDto) {
    // Get current usage
    const currentMonth = getFirstDayOfCurrentMonth();

    let confidence = 0;
    let pageNb = ocrResult?.pageCount || 1;
    ocrResult?.results?.forEach(e => {
      if (e.confidence) {
        confidence += e.confidence
      }
    })

    const result = {
      requestId,
      result: ocrResult,
      confidence: Math.ceil(confidence/pageNb),
    };

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Save request and increase usage
      await queryRunner.manager
        .createQueryBuilder()
        .update(Request)
        .andWhere('id=:requestId', { requestId: requestId })
        .set({ status: RequestStatus.Completed })
        .execute();

      // Increase usage
      await queryRunner.manager
        .createQueryBuilder()
        .update(Usage)
        .set({
          pageCount: () => `page_count + ${pageCount}`,
          requestCount: () => 'request_count + 1',
        })
        .where("tenantId = :tenantId", { tenantId })
        .andWhere("month = :month", { month: currentMonth })
        .execute();

      // Save ocr result
      await queryRunner.manager
        .createQueryBuilder()
        .insert()
        .into(Result)
        .values(result)
        .execute();

      await queryRunner.commitTransaction();
    } catch (e) {
      this.logger.error(e.message, e.stack, OcrService.name);

      await queryRunner.rollbackTransaction();
      throw e;
    } finally {
      await queryRunner.release();
    }

    return result;
  }

  async updateOcrResultError(requestId: number) {
    try {
      // Save request error
      await this.dataSource.manager
        .createQueryBuilder()
        .update(Request)
        .andWhere('id=:requestId', { requestId: requestId })
        .set({ status: RequestStatus.Failed })
        .execute();
    } catch (e) {
      this.logger.error(e.message, e.stack, OcrService.name);
      throw e;
    }
  }

  async getCurrentPageCount(tenantId: number, month?: Date): Promise<number> {
    if (!month) month = getFirstDayOfCurrentMonth();

    const usage = await this.dataSource.manager.findOne(Usage, {
      select: {
        id: true,
        pageCount: true,
      },
      where: {
        tenantId: tenantId,
        month: month,
      },
    });

    return usage ? usage.pageCount : 0;
  }

  async downloadFile(filePath: string) {
    return await lastValueFrom(
      this.httpService.post('/ocr/download-file', {filePath: filePath}).pipe(
        map((response) => {
          return response?.data
        }),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, OcrService.name);
          throw e;
        }),
      ),
    );
  }
}
