export enum RequestStatus {
  Processing = 1,
  Completed = 2,
  Failed = 3,
}
