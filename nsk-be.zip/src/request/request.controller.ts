import {
  BadRequestException,
  Body,
  ClassSerializerInterceptor,
  Controller,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Request,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiConsumes, ApiOkResponse, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { CreateRequestDto } from './dto/create-request.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { RequestService } from './request.service';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { multerOptions } from 'src/shared/config/multer.config';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { RequestFindQueryDto } from './dto/request-find-query.dto';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { Request as RequestEntity } from './entity/request.entity';
import { RolesGuard } from 'src/shared/guards/roles.guard';
import { Roles } from 'src/user/constants';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { RequestFindQueryResponseDto } from './dto/request-find-query-response.dto';
import { UpdateDownloadStatusDto } from './dto/update-download-status.dto';
import { ExcelService } from 'src/excel/excel.service';
import { RequestFindExportQueryDto } from './dto/request-find-export-query.dto';
import { throwValidationException } from 'src/shared/helpers/validation.helper';
import { API_CODE } from 'src/shared/constant/api-code.constant';

@ApiTags('request')
@Controller('request')
@RolesDecorator(Roles.Tenant)
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class RequestController {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    private requestService: RequestService,
    private excelService: ExcelService,
  ) {}

  @Get()
  @ApiOkResponse({
    description: 'Response list of request',
    type: RequestFindQueryResponseDto,
  })
  @UseInterceptors(ClassSerializerInterceptor)
  async find(
    @Query(NormalizeFindQueryPipe) query: RequestFindQueryDto,
    @Request() req,
  ): Promise<Pagination<RequestEntity>> {
    try {
      return await this.requestService.paginate(query, req.user?.tenantId);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get('export')
  @ApiOperation({
    summary: 'Download request list',
  })
  async exportList(
    @Query(NormalizeFindQueryPipe) query: RequestFindExportQueryDto,
    @Request() req,
    @Res() res: Response,
  ): Promise<void> {
    try {
      const { data, fileName } = await this.requestService.exportRequestList(query, req.user?.tenantId);
      const fileBuffer = await this.excelService.exportTemplate(fileName, data);

      res.setHeader('Content-Type', 'application/vnd.openxmlformats');
      res.setHeader('Content-Disposition', 'attachment; filename=RequestList.xlsx');
      res.send(fileBuffer);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get(':id/export')
  async exportResult(@Param('id', ParseIntPipe) id: number, @Request() req, @Res() res: Response): Promise<any> {
    try {
      const data = await this.requestService.exportRequest(id, req.user?.tenantId);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats');
      res.setHeader('Access-Control-Expose-Headers', 'Note');
      if (data && data.length && data[0].requestType == 'shiba') {
        res.setHeader('Content-Disposition', 'attachment; filename=ResultOfRequest.xlsm');
        res.setHeader('Note', 'xlsm');
        this.logger.log(`===== request.controller.ts: request set note header =====`, RequestController.name);
        const excelData = data[0].results[0];
        const fileBuffer = await this.excelService.createExcelFileShiba(excelData);
        res.send(fileBuffer);
      } else {
        res.setHeader('Content-Disposition', 'attachment; filename=ResultOfRequest.xlsx');
        res.setHeader('Note', 'xlsx');
        const fileBuffer = await this.excelService.createExcelFile(null, data, 'Request Result');
        res.send(fileBuffer);
      }
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Post()
  @UseInterceptors(FileInterceptor('document', multerOptions))
  @ApiConsumes('multipart/form-data')
  async create(@UploadedFile() file: Express.Multer.File, @Body() dto: CreateRequestDto, @Request() req): Promise<any> {
    try {
      const validation = await this.requestService.validateQuota(req.user.tenantId, file);
      if (!validation.validQuota) {
        throwValidationException(API_CODE.INVADLID_QUOTA_CODE, {
          remainPageCount: validation.remainPageCount,
          pageCount: validation.pageCount,
        });
      }

      return await this.requestService.create(file, dto, req.user.userId, req.user.tenantId, validation.pageCount);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestService.name);
      throw new BadRequestException(e);
    }
  }

  @Put(':id/download-status')
  @ApiParam({ name: 'id' })
  @ApiOperation({ summary: 'Update download status' })
  async updateDownloadStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateDownloadStatusDto: UpdateDownloadStatusDto,
    @Request() req,
  ) {
    try {
      await this.requestService.updateStatusDownload(id, updateDownloadStatusDto, req.user?.tenantId);
    } catch (e) {
      this.logger.error(e.message, e.stack, RequestController.name);
      throw new BadRequestException(e.message);
    }
  }
}
