import { ApiPropertyOptional, OmitType } from '@nestjs/swagger';
import { RequestFindQueryDto } from './request-find-query.dto';
import { IsOptional, Matches } from 'class-validator';

export class RequestFindExportQueryDto extends OmitType(RequestFindQueryDto, ['sort'] as const) {
  @ApiPropertyOptional({
    description: 'Select language: en or jp',
  })
  @IsOptional()
  @Matches(/^(?:en|jp)?$/, { message: 'Invalid lang param format' })
  lang?: string;

  @ApiPropertyOptional()
  offset?: number;
}
