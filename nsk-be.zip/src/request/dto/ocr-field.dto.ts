import { ApiProperty } from '@nestjs/swagger';

export class OcrFieldDto {
  @ApiProperty()
  fields: string[];

  @ApiProperty()
  table: string[];

  @ApiProperty()
  confidence: number;
}
