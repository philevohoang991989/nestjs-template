import { ApiProperty } from '@nestjs/swagger';

export class UpdateDownloadStatusDto {
  @ApiProperty({
    description: 'Download status. true/false',
    example: false,
  })
  downloadStatus: boolean;
}
