import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, Matches } from 'class-validator';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';

export class RequestFindQueryDto extends FindQueryDto {
  @ApiPropertyOptional()
  name?: string;

  @ApiPropertyOptional()
  status?: number;

  @ApiPropertyOptional({
    name: 'fromDate',
    example: '2023-01-01',
  })
  fromDate?: Date;

  @ApiPropertyOptional({
    name: 'toDate',
    example: '2023-10-31',
  })
  toDate?: Date;

  @ApiPropertyOptional({
    name: 'sort',
    example: '-request.name',
    description:
      'Filter sort by id, templateId, name, status, results.confidence, pageCount, createdAt. Default is ASC. Minus before is DESC',
  })
  @IsOptional()
  @Matches(/^(?:-)?(?:id|templateId|name|status|results.confidence|pageCount|createdAt)?$/, {
    message: 'Invalid input format',
  })
  sort?: string;
}
