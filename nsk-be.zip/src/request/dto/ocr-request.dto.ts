import { ApiProperty } from '@nestjs/swagger';
import { IsNumber } from 'class-validator';

export class OcrRequestDto {
  @ApiProperty()
  @IsNumber()
  refTenantId: number;

  @ApiProperty()
  @IsNumber()
  refRequestId: number;

  @ApiProperty()
  @IsNumber()
  refPageCount: number;

  @ApiProperty()
  template: object;

  @ApiProperty({ type: 'string', format: 'binary' })
  document: any;
}
