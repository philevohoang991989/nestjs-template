import { ApiProperty } from '@nestjs/swagger';
import { IsNumber } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateRequestDto {
  @ApiProperty()
  name: string;

  @ApiProperty()
  @IsNumber()
  @Type(() => Number)
  templateId: number;

  @ApiProperty({ type: 'string', format: 'binary' })
  document: any;
}
