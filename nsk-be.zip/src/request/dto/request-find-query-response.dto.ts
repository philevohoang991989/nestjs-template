import { Request } from '../entity/request.entity';
import { ApiProperty } from '@nestjs/swagger';

export class RequestFindQueryResponseDto {
  @ApiProperty()
  items: Request;

  @ApiProperty()
  totalItems: number;
}
