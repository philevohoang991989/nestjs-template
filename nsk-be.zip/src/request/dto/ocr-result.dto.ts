import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { OcrFieldDto } from './ocr-field.dto';

export class OcrResultDto {
  @ApiProperty()
  requestId: number;

  @ApiProperty()
  pageCount: number;

  @ApiPropertyOptional()
  confidence: number;

  @ApiProperty({ type: [OcrFieldDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => OcrFieldDto)
  results?: OcrFieldDto[];
}
