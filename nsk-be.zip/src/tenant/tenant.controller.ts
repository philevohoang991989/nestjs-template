import {
  BadRequestException,
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Headers,
  Inject,
  NotFoundException,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Request,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { TenantService } from './tenant.service';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { TenantFindQueryDto } from './dto/tenant-find-query.dto';
import { Tenant } from './entity/tenant.entity';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { Logger } from 'winston';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { CreateTenantDto } from './dto/create-tenant.dto';
import { UpdateMyTenantDto, UpdateTenantDto } from './dto/update-tenant.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Roles } from 'src/user/constants';
import { RolesGuard } from 'src/shared/guards/roles.guard';
import { API_CODE } from 'src/shared/constant/api-code.constant';
import { UserService } from 'src/user/user.service';
import { throwValidationException } from 'src/shared/helpers/validation.helper';
import * as moment from 'moment';
import { GetAllTenant } from './dto/get-all-tenant.dto';

@ApiTags('tenant')
@Controller('tenant')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
export class TenantController {
  constructor(
    private tenantService: TenantService,
    private userService: UserService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
  ) {}

  @Get()
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  @UseInterceptors(ClassSerializerInterceptor)
  async find(@Query(NormalizeFindQueryPipe) query: TenantFindQueryDto): Promise<Pagination<Tenant>> {
    try {
      return await this.tenantService.paginate(query);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Post('with-user')
  @ApiOperation({
    summary: 'Create new tenant and new user as well',
  })
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  async create(@Body() dto: CreateTenantDto, @Headers() headers) {
    try {
      const isValidName = await this.tenantService.validateTenantName(dto.name);
      if (!isValidName) {
        throwValidationException(API_CODE.TENANT_NAME_EXIST);
      }

      const isValidEmail = await this.userService.validateUserEmail(dto.userEmail);
      if (!isValidEmail) {
        throwValidationException(API_CODE.USER_EMAIL_EXIST);
      }

      return await this.tenantService.createWithUser(dto, headers?.lang);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new BadRequestException(e);
    }
  }

  @Get('compact')
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  async getCompactList(@Query(NormalizeFindQueryPipe) query: GetAllTenant): Promise<Array<Tenant>> {
    try {
      return await this.tenantService.getCompactList(query.withUsage);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get('my-tenant')
  @RolesDecorator(Roles.Tenant)
  @UseGuards(RolesGuard)
  async getMyTenant(@Request() req): Promise<Tenant> {
    try {
      const myTenantId = req.user.tenantId;
      return await this.tenantService.findById(myTenantId);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Get(':id')
  @ApiParam({ name: 'id' })
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  async findById(@Param('id', ParseIntPipe) id: number): Promise<Tenant> {
    try {
      return await this.tenantService.findById(id);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Put('my-tenant')
  @RolesDecorator(Roles.Tenant)
  @UseGuards(RolesGuard)
  async updateMyTenant(@Request() req, @Body() dto: UpdateMyTenantDto): Promise<Tenant> {
    try {
      const myTenantId = req.user.tenantId;
      return await this.tenantService.updateMyTenant(myTenantId, dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Put('package-monthly')
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  async updateTenantPackageMonthly() {
    try {
      const month = moment().startOf('month').format('YYYY-MM-DD');

      await this.tenantService.upsertUsageBlockFromTenant(month);
      await this.tenantService.callApiTenantOcrService(month);
      await this.tenantService.callApiPartnerOcrService(month);
      return;
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Put(':id')
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  async update(@Param('id') id: number, @Body() dto: UpdateTenantDto): Promise<Tenant> {
    try {
      const tenant = await this.tenantService.findById(id);
      if (dto.currentMonthBlocks && dto.currentMonthBlocks < tenant.currentMonthBlocks) {
        throwValidationException(API_CODE.INVALID_TENANT_CURRENT_MONTH_BLOCK);
      }

      const isValidName = await this.tenantService.validateTenantName(dto.name, id);
      if (!isValidName) {
        throwValidationException(API_CODE.TENANT_NAME_EXIST);
      }

      const isValidEmail = await this.userService.validateUserEmail(dto.userEmail, tenant.id);
      if (!isValidEmail) {
        throwValidationException(API_CODE.USER_EMAIL_EXIST);
      }

      return await this.tenantService.update(tenant, dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new BadRequestException(e);
    }
  }

  @Delete(':id')
  @RolesDecorator(Roles.Partner)
  @UseGuards(RolesGuard)
  async delete(@Param('id') id: number): Promise<Tenant> {
    try {
      return await this.tenantService.remove(id);
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantController.name);
      throw new BadRequestException(e.message);
    }
  }
}
