import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Template } from 'src/template/entity/template.entity';
import { User } from 'src/user/entity/user.entity';
import { Usage } from 'src/usage/entity/usage.entity';
import { Exclude } from 'class-transformer';

@Entity({
  name: 'tenants',
})
export class Tenant {
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @Column({
    name: 'name',
    length: 255,
    nullable: false,
  })
  @Index({
    unique: true,
    where: 'deleted_at IS NULL',
  })
  name: string;

  @Column({
    name: 'description',
    length: 512,
    nullable: true,
  })
  description: string;

  @Column({
    name: 'contact_name',
    length: 255,
    nullable: true,
  })
  contactName: string;

  @Column({
    name: 'contact_email',
    length: 255,
    nullable: true,
  })
  @Index({
    unique: false,
  })
  contactEmail: string;

  @Column({
    name: 'contact_phone',
    length: 255,
    nullable: true,
  })
  contactPhone: string;

  @Exclude()
  @Column({
    name: 'min_blocks',
    default: 0,
  })
  minBlocks: number;

  @Exclude()
  @Column({
    name: 'max_blocks',
    default: 0,
  })
  maxBlocks: number;

  @Column({
    name: 'address',
    nullable: true,
  })
  address: string;

  @Column({
    name: 'start_date',
    type: 'date',
    nullable: true,
  })
  startDate: Date;

  @Column({
    name: 'expired_date',
    type: 'date',
    nullable: true,
  })
  expiredDate?: Date;

  @Column({
    name: 'is_active',
    default: true,
  })
  isActive: boolean;

  @Exclude()
  @Column({
    name: 'current_month_packages',
    default: 0,
  })
  currentMonthPackages: number;

  @Exclude()
  @Column({
    name: 'next_month_packages',
    default: 0,
  })
  nextMonthPackages: number;

  @Column({
    name: 'current_month_blocks',
    default: 0,
  })
  currentMonthBlocks: number;

  @Column({
    name: 'next_month_blocks',
    default: 0,
  })
  nextMonthBlocks: number;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamptz',
  })
  deletedAt: Date;

  @OneToMany(() => Template, (template) => template.tenant)
  templates: Template[];

  @OneToMany(() => User, (user) => user.tenant)
  users: User[];

  @OneToMany(() => Usage, (usage) => usage.tenant)
  usage: Usage[];
}
