import { Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Tenant } from './entity/tenant.entity';
import { DataSource, Repository } from 'typeorm';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { ConfigService } from '@nestjs/config';
import { Usage } from 'src/usage/entity/usage.entity';

@Injectable()
export class TenantMigrationService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    @InjectRepository(Tenant) private tenantRepository: Repository<Tenant>,
    private dataSource: DataSource,
    private configService: ConfigService,
  ) {}

  async migrateTenantPackageToBlock(): Promise<void> {
    const blocksPerPackage = this.configService.get('parameter').blocksPerPackage;

    await this.dataSource
      .createQueryBuilder()
      .update(Tenant)
      .set({
        currentMonthBlocks: () => `currentMonthPackages * ${blocksPerPackage}`,
      })
      .execute();

    await this.dataSource
      .createQueryBuilder()
      .update(Usage)
      .set({
        currentMonthBlocks: () => `currentMonthPackages * ${blocksPerPackage}`,
      })
      .execute();
  }
}
