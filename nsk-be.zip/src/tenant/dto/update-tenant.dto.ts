import { ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { CreateTenantDto } from './create-tenant.dto';
import { IsEmail, IsOptional, Matches } from 'class-validator';

export class UpdateTenantDto extends PartialType(CreateTenantDto) {
  @ApiPropertyOptional()
  @IsOptional()
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*\W).{8,}$|^$/, { message: 'userPassword is not strong enough' })
  userPassword?: string;

  @ApiPropertyOptional()
  @IsEmail()
  userEmail?: string;
}

export class UpdateMyTenantDto {
  @ApiPropertyOptional()
  name: string;

  @ApiPropertyOptional()
  description?: string;

  @ApiPropertyOptional()
  @IsEmail()
  @IsOptional()
  contactEmail?: string;

  @ApiPropertyOptional()
  contactName?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Matches(/^(\d{9,}|)$/, { message: 'Invalid contactPhone format' })
  contactPhone?: string;

  @ApiPropertyOptional()
  address?: string;
}
