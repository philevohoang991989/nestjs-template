import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsStrongPassword, IsEmail, IsOptional, Min, Matches } from 'class-validator';

export class CreateTenantDto {
  @ApiProperty()
  name: string;

  @ApiPropertyOptional()
  description?: string;

  @ApiPropertyOptional()
  contactName?: string;

  @ApiPropertyOptional({
    example: 'tenant07@gmail.com',
  })
  @IsOptional()
  @Matches(/^(?:[^\s@]+@[^\s@]+\.[^\s@]+|)$/, { message: 'Invalid contactEmail format' })
  contactEmail?: string;

  @ApiPropertyOptional()
  address?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Matches(/^(\d{9,}|)$/, { message: 'Invalid contactPhone format' })
  contactPhone?: string;

  @ApiPropertyOptional()
  @Min(1)
  currentMonthBlocks?: number;

  @ApiPropertyOptional()
  @Min(1)
  nextMonthBlocks?: number;

  @ApiPropertyOptional({
    example: '2023-09-25',
  })
  startDate?: Date;

  @ApiPropertyOptional({
    example: '2023-12-25',
  })
  @IsOptional()
  @Matches(/^(?:\d{4}-\d{2}-\d{2})?$/, { message: 'Invalid expiredDate format' })
  expiredDate?: string;

  @ApiPropertyOptional()
  @IsStrongPassword({
    minLength: 8,
    minLowercase: 1,
    minUppercase: 1,
    minNumbers: 1,
    minSymbols: 1,
  })
  userPassword?: string;

  @ApiProperty()
  @IsEmail()
  userEmail: string;

  @ApiPropertyOptional({
    example: 'true',
  })
  isActive: boolean;
}
