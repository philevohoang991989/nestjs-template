import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, Matches } from 'class-validator';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';

export class TenantFindQueryDto extends FindQueryDto {
  @ApiPropertyOptional()
  name?: string;

  @ApiPropertyOptional()
  isActive?: boolean;

  @ApiPropertyOptional({
    name: 'onboardDate',
    example: '2023-01-02',
  })
  onboardDate?: Date;

  @ApiPropertyOptional({
    name: 'sort',
    example: '-name',
    description:
      'Filter sort by id, name, contactEmail, currentMonthBlocks, startDate, updatedAt, isActive. Default is ASC. Minus before is DESC',
  })
  @IsOptional()
  @Matches(/^(?:-)?(?:id|name|contactEmail|currentMonthBlocks|startDate|updatedAt|isActive)?$/, {
    message: 'Invalid sort format',
  })
  sort?: string;
}
