import { ApiPropertyOptional } from '@nestjs/swagger';

export class GetAllTenant {
  @ApiPropertyOptional()
  withUsage?: boolean;
}
