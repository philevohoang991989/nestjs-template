import { Controller, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';

@ApiTags('tenant-migration')
@Controller('tenant-migration')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
export class TenantMigrationController {
  // constructor(
  //   private tenantMigrationService: TenantMigrationService,
  //   @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
  // ) {}
  // @Post()
  // @ApiOperation({
  //   summary: 'Migrate data from package to block',
  // })
  // @RolesDecorator(Roles.Partner)
  // @UseGuards(RolesGuard)
  // async migrate() {
  //   try {
  //     return await this.tenantMigrationService.migrateTenantPackageToBlock();
  //   } catch (e) {
  //     this.logger.error(e.message, e.stack, TenantMigrationController.name);
  //     throw new BadRequestException(e);
  //   }
  // }
}
