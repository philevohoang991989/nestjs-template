import { Module } from '@nestjs/common';
import { TenantService } from './tenant.service';
import { TenantController } from './tenant.controller';
import { Tenant } from './entity/tenant.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserModule } from 'src/user/user.module';
import { TenantMigrationController } from './tenant-migration.controller';
import { TenantMigrationService } from './tenant-migration.service';

@Module({
  imports: [TypeOrmModule.forFeature([Tenant]), UserModule],
  providers: [TenantService, TenantMigrationService],
  controllers: [TenantController, TenantMigrationController],
  exports: [TenantService],
})
export class TenantModule {}
