import { Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Tenant } from './entity/tenant.entity';
import { DataSource, Repository } from 'typeorm';
import { TenantFindQueryDto } from './dto/tenant-find-query.dto';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { CreateTenantDto } from './dto/create-tenant.dto';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { UserService } from 'src/user/user.service';
import { CreateUserDto } from 'src/user/dto/create-user.dto';
import { Roles } from 'src/user/constants';
import { UpdateMyTenantDto, UpdateTenantDto } from './dto/update-tenant.dto';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { UpdateUserDto } from 'src/user/dto/update-user.dto';
import { addDate, getFirstDayOfCurrentMonth, stringToDate } from 'src/shared/helpers/date.helper';
import { LIMIT } from 'src/shared/constant/common.constant';
import { catchError, lastValueFrom, map } from 'rxjs';
import { HttpService } from '@nestjs/axios';
import { AxiosError } from 'axios';
import * as moment from 'moment';
import { Usage } from 'src/usage/entity/usage.entity';
import { Template } from 'src/template/entity/template.entity';
import { Invoice } from 'src/invoice/entity/invoice.entity';
import { User } from 'src/user/entity/user.entity';

@Injectable()
export class TenantService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    @InjectRepository(Tenant) private tenantRepository: Repository<Tenant>,
    private dataSource: DataSource,
    private userSevice: UserService,
    private httpService: HttpService,
  ) {}

  async paginate(filter: TenantFindQueryDto): Promise<Pagination<Tenant>> {
    const qb = this.tenantRepository.createQueryBuilder('tenant');

    if (filter.name) {
      qb.andWhere('(tenant.name ILIKE :name OR tenant.contactEmail ILIKE :name)', { name: `%${filter.name.trim()}%` });
    }

    if (filter.isActive) {
      qb.andWhere('tenant.isActive = :isActive', { isActive: filter.isActive });
    }

    if (filter.onboardDate) {
      qb.andWhere('tenant.startDate = :onboardDate', { onboardDate: filter.onboardDate });
    }

    if (filter.sort) {
      qb.orderBy(getOrderByClause(filter.sort, 'tenant'));
    } else {
      qb.orderBy('id', 'DESC');
    }

    const results = await qb
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();

    return new Pagination(results);
  }

  async getCompactList(withUsage = false): Promise<Array<Tenant>> {
    const qb = this.tenantRepository.createQueryBuilder('tenant');

    if (withUsage) {
      qb.withDeleted().innerJoin('tenant.usage', 'usage').where('usage.deletedAt IS NULL');
    }

    qb.select(['tenant.id', 'tenant.name']);
    const results = await qb.getMany();

    return results;
  }

  async createWithUser(dto: CreateTenantDto, lang: string): Promise<Tenant> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const tenant = new Tenant();
      tenant.name = dto.name;
      tenant.description = dto.description;
      tenant.contactName = dto.contactName;
      tenant.contactEmail = dto.contactEmail;
      tenant.contactPhone = dto.contactPhone;
      tenant.currentMonthBlocks = dto.currentMonthBlocks;
      tenant.nextMonthBlocks = dto.nextMonthBlocks;
      tenant.startDate = dto.startDate;
      tenant.isActive = dto.isActive;
      tenant.address = dto.address;

      if (dto.expiredDate) {
        tenant.expiredDate = stringToDate(dto.expiredDate, 'YYYY-MM-DD');
      }

      const createdTenant = await queryRunner.manager.save(tenant);

      const createUserDto = new CreateUserDto();
      createUserDto.email = dto.userEmail;
      if (dto.userPassword) {
        createUserDto.password = dto.userPassword;
      }
      createUserDto.name = dto.contactName || tenant.name;
      createUserDto.tenantId = createdTenant.id;
      createUserDto.roleId = Roles.Tenant;
      createUserDto.lang = lang ?? 'en';

      await this.userSevice.create(createUserDto, queryRunner.manager);

      // Call api update OCR tenant
      await this.processUpdateTenantOcr(createdTenant);

      // Update usage
      const usage = new Usage();
      usage.tenantId = createdTenant.id;
      usage.month = getFirstDayOfCurrentMonth();
      usage.pageCount = 0;
      usage.requestCount = 0;
      usage.currentMonthBlocks = tenant.currentMonthBlocks;

      await queryRunner.manager.getRepository(Usage).save(usage);

      await queryRunner.commitTransaction();

      return createdTenant;
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantService.name);
      await queryRunner.rollbackTransaction();

      throw e;
    } finally {
      await queryRunner.release();
    }
  }

  async findById(id: number) {
    const tenant = await this.tenantRepository.findOneOrFail({
      where: {
        id: id,
      },
    });
    const userTenant = await this.userSevice.findUserByTenant(tenant.id);

    return {
      ...tenant,
      ...{
        userEmail: userTenant.email,
      },
    };
  }

  async update(tenant: Tenant, dto: UpdateTenantDto): Promise<Tenant> {
    let isUpdateTenantOCR = false;
    let reActivateTenant = false;
    const updateUserDto = new UpdateUserDto();

    if (dto.name) {
      tenant.name = dto.name;
    }

    if (dto.address) {
      tenant.address = dto.address;
    }

    if (dto.description) {
      tenant.description = dto.description;
    }

    if (dto.contactName) {
      tenant.contactName = dto.contactName;
      updateUserDto.name = tenant.contactName;
    }

    if (dto.contactEmail) {
      tenant.contactEmail = dto.contactEmail;
    }

    if (dto.contactPhone) {
      tenant.contactPhone = dto.contactPhone;
    }

    if (dto.currentMonthBlocks) {
      if (tenant.currentMonthBlocks != dto.currentMonthBlocks && tenant.isActive) {
        isUpdateTenantOCR = true;
      }

      tenant.currentMonthBlocks = dto.currentMonthBlocks;
    }

    if (dto.isActive != null) {
      if (dto.isActive && !tenant.isActive) {
        reActivateTenant = true;
      }

      tenant.isActive = dto.isActive;
      updateUserDto.isActive = dto.isActive;
    }

    if (dto.nextMonthBlocks) {
      tenant.nextMonthBlocks = dto.nextMonthBlocks;
    }

    if (dto.expiredDate) {
      tenant.expiredDate = stringToDate(dto.expiredDate, 'YYYY-MM-DD');
    }

    if (dto.userEmail) {
      updateUserDto.email = dto.userEmail;
    }

    if (dto.userPassword) {
      updateUserDto.password = dto.userPassword;
    }

    const userTenant = await this.userSevice.findUserByTenant(tenant.id);
    await this.userSevice.update(userTenant.id, updateUserDto);

    const updatedTenant = await this.tenantRepository.save(tenant);

    if (isUpdateTenantOCR || reActivateTenant) {
      await this.processUpdateTenantOcr(updatedTenant);
      // Update current month block
      await this.updateCurrentMonthUsageBlock(updatedTenant);
    }

    return updatedTenant;
  }

  async updateCurrentMonthUsageBlock(tenant: Tenant) {
    const month = getFirstDayOfCurrentMonth();
    const usageData = {
      month,
      tenantId: tenant.id,
      currentMonthBlocks: tenant.currentMonthBlocks,
    };

    await this.dataSource.manager.getRepository(Usage).upsert([usageData], ['tenantId', 'month']);
  }

  async updateMyTenant(id: number, dto: UpdateMyTenantDto): Promise<Tenant> {
    const tenant = await this.tenantRepository.findOneOrFail({
      where: {
        id: id,
      },
    });

    if (dto.name) {
      tenant.name = dto.name;
    }

    if (dto.description) {
      tenant.description = dto.description;
    }

    if (dto.contactName) {
      tenant.contactName = dto.contactName;
    }

    if (dto.contactEmail) {
      tenant.contactEmail = dto.contactEmail;
    }

    if (dto.contactPhone) {
      tenant.contactPhone = dto.contactPhone;
    }

    if (dto.address) {
      tenant.address = dto.address;
    }

    return this.tenantRepository.save(tenant);
  }

  async remove(id: number): Promise<Tenant> {
    const tenant = await this.tenantRepository.findOneOrFail({
      where: {
        id: id,
      },
    });
    const now = new Date();
    const limitTimeDeleted = addDate(tenant.createdAt, 1);

    if (now < limitTimeDeleted) {
      const { totalPageCount, totalUsage } = await this.dataSource
        .getRepository(Usage)
        .createQueryBuilder()
        .select('SUM(page_count)', 'totalPageCount')
        .addSelect('COUNT(id)', 'totalUsage')
        .where('tenant_id = :tenantId', { tenantId: id })
        .getRawOne();

      if (!(totalPageCount && parseInt(totalPageCount) > 0)) {
        const months = [moment().startOf('month').format('YYYY-MM-DD')];
        const lastMonth = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD');

        if (parseInt(totalUsage) > 1) {
          months.push(lastMonth);
        }

        await this.processUpdateTenantOcr(tenant, true, months);

        if (months.length > 1) {
          //remove last month invoice
          await this.callApiUpdateInvoice(lastMonth);
        }

        await this.hardRemove(id);
        return tenant;
      }
    }

    await this.softRemove(tenant);
    return tenant;
  }

  async softRemove(tenant: Tenant) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.softRemove(tenant);
      // Delete user
      await queryRunner.manager.softDelete(User, { tenantId: tenant.id });

      await queryRunner.commitTransaction();
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantService.name);
      queryRunner.rollbackTransaction();

      throw e;
    } finally {
      await queryRunner.release();
    }
  }

  async hardRemove(tenantId: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.delete(Template, { tenantId });
      await queryRunner.manager.delete(Invoice, { tenantId });
      await queryRunner.manager.delete(Usage, { tenantId });
      await queryRunner.manager.delete(User, { tenantId });
      await queryRunner.manager.delete(Tenant, { id: tenantId });

      await queryRunner.commitTransaction();
    } catch (e) {
      this.logger.error(e.message, e.stack, TenantService.name);
      queryRunner.rollbackTransaction();

      throw e;
    } finally {
      await queryRunner.release();
    }
  }

  async processUpdateTenantOcr(tenant: Tenant, isDeleted = false, months = null) {
    // Call api update OCR tenant
    if (!months) {
      months = [moment().startOf('month').format('YYYY-MMM-DD')];
    }

    const tenantsOcrDto = months.map((month) => {
      const tenantPackage = {
        month,
        refTenantId: tenant.id,
      };

      if (isDeleted) {
        Object.assign(tenantPackage, { deletedAt: new Date() });
      } else {
        Object.assign(tenantPackage, { currentMonthBlocks: tenant.currentMonthBlocks });
      }

      return tenantPackage;
    });

    await this.callApiUpdateTenantOcrService(tenantsOcrDto);

    for (let i = 0; i < months.length; i++) {
      await this.callApiPartnerOcrService(months[i]);
    }
  }

  async updateCurrentBlockMonthly(): Promise<void> {
    const now = new Date();
    const totalTenant = await this.tenantRepository
      .createQueryBuilder('tenant')
      .where('tenant.next_month_blocks != tenant.current_month_blocks')
      .andWhere('tenant.is_active = :isActive', { isActive: true })
      .andWhere('(tenant.expired_date IS NULL OR tenant.expired_date > :now)', { now })
      .getCount();

    if (totalTenant > 0) {
      let count = 0;
      while (count < totalTenant) {
        await this.updateBlock(LIMIT);
        count = +LIMIT;
      }
    }
  }

  async updateBlock(limit: number): Promise<void> {
    const now = new Date();
    const tenants = await this.tenantRepository
      .createQueryBuilder('tenant')
      .where('tenant.next_month_blocks != tenant.current_month_blocks')
      .andWhere('tenant.is_active = :isActive', { isActive: true })
      .andWhere('(tenant.expired_date IS NULL OR tenant.expired_date > :now)', { now })
      .orderBy('id', 'ASC')
      .take(limit)
      .getMany();

    if (tenants.length > 0) {
      // update current month block
      const tenantIds = tenants.map((tenant) => tenant.id);

      await this.tenantRepository
        .createQueryBuilder('tenant')
        .update(Tenant)
        .set({ currentMonthBlocks: () => 'next_month_blocks' })
        .whereInIds(tenantIds)
        .execute();
    }
  }

  async callApiTenantOcrService(month: string) {
    const now = new Date();
    const totalTenant = await this.tenantRepository
      .createQueryBuilder('tenant')
      .where('tenant.isActive = :isActive', { isActive: true })
      .andWhere('(tenant.expiredDate IS NULL OR tenant.expiredDate > :now)', { now })
      .getCount();

    if (totalTenant > 0) {
      let offset = 0;
      while (offset < totalTenant) {
        await this.updateTenantOcrService(LIMIT, offset, month);
        offset += LIMIT;
      }
    }
  }

  async updateTenantOcrService(limit: number, offset: number, month: string) {
    const now = new Date();
    const tenants = await this.tenantRepository
      .createQueryBuilder('tenant')
      .where('tenant.isActive = :isActive', { isActive: true })
      .andWhere('(tenant.expiredDate IS NULL OR tenant.expiredDate > :now)', { now })
      .orderBy('id', 'ASC')
      .take(limit)
      .skip(+offset)
      .getMany();

    const tenantPackages = tenants.map((tenant) => {
      return {
        month,
        refTenantId: tenant.id,
        currentMonthBlocks: tenant.currentMonthBlocks,
      };
    });
    await this.callApiUpdateTenantOcrService(tenantPackages);
  }

  async callApiUpdateTenantOcrService(tenantPackages: object) {
    await lastValueFrom(
      this.httpService.post('/tenant/update-package', { tenants: tenantPackages }).pipe(
        map((response) => response?.data),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, TenantService.name);
          throw e;
        }),
      ),
    );
  }

  async callApiPartnerOcrService(month: string) {
    await lastValueFrom(
      this.httpService.post('/partner/update-package', { month }).pipe(
        map((response) => response?.data),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, TenantService.name);
          throw e;
        }),
      ),
    );
  }

  async callApiUpdateInvoice(month: string) {
    await lastValueFrom(
      this.httpService.post('/generate-invoice?month=' + month).pipe(
        map((response) => response?.data),
        catchError((e: AxiosError) => {
          this.logger.error(e.message, e.stack, TenantService.name);
          throw e;
        }),
      ),
    );
  }

  async validateTenantName(name: string, tenantId = null): Promise<boolean> {
    const qb = this.tenantRepository.createQueryBuilder('tenant').withDeleted();
    qb.where('name = :name', { name: name });
    if (tenantId) {
      qb.andWhere('tenant.id != :tenantId', { tenantId: tenantId });
    }

    return !(await qb.getOne());
  }

  async upsertUsageBlockFromTenant(month: string) {
    const now = new Date();
    const qb = this.tenantRepository
      .createQueryBuilder('tenant')
      .leftJoin('tenant.usage', 'usage', 'usage.month = :month', { month })
      .select(['tenant.id', 'tenant.currentMonthBlocks'])
      .andWhere('tenant.isActive = :isActive', { isActive: true })
      .andWhere('(tenant.expiredDate IS NULL OR tenant.expiredDate > :now)', { now });

    const tenants = await qb.getRawMany();

    if (!tenants.length) {
      return;
    }

    const usages = tenants.map((tenant) => {
      return {
        tenantId: parseInt(tenant.tenant_id),
        month: month,
        currentMonthBlocks: tenant.tenant_current_month_blocks,
      };
    });

    await this.dataSource.getRepository(Usage).upsert(usages, ['tenantId', 'month']);

    return tenants;
  }
}
