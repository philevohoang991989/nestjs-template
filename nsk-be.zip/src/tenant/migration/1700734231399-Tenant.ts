import { MigrationInterface, QueryRunner } from 'typeorm';

export class Tenant1700734231399 implements MigrationInterface {
  name = 'Tenant1700734231399';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ADD "current_month_packages" integer
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ADD "next_month_packages" integer
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ADD "current_month_blocks" integer
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants" DROP COLUMN "current_month_blocks"
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants" DROP COLUMN "next_month_packages"
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants" DROP COLUMN "current_month_packages"
        `);
  }
}
