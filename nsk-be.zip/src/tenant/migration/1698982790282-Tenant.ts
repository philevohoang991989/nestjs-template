import { MigrationInterface, QueryRunner } from 'typeorm';

export class Tenant1698982790282 implements MigrationInterface {
  name = 'Tenant1698982790282';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ADD "address" character varying(512)
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants" DROP COLUMN "address"
        `);
  }
}
