import { MigrationInterface, QueryRunner } from 'typeorm';

export class Tenant1699328262306 implements MigrationInterface {
  name = 'Tenant1699328262306';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "contact_email" DROP NOT NULL
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "contact_email"
            SET NOT NULL
        `);
  }
}
