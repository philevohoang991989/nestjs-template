import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddNextMonthBlocks1701761711148 implements MigrationInterface {
  name = 'AddNextMonthBlocks1701761711148';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "tenants"
      ADD "next_month_blocks" integer
      DEFAULT(1)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "tenants" DROP COLUMN "next_month_blocks"
    `);
  }
}
