import { MigrationInterface, QueryRunner } from 'typeorm';

export class Tenant_DefaultValue1702534509650 implements MigrationInterface {
  name = 'Tenant_DefaultValue1702534509650';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "min_blocks"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "min_blocks"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "max_blocks"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "max_blocks"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_packages"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_packages"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_packages"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_packages"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_blocks"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_blocks"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_blocks"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_blocks"
            SET DEFAULT '0'
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_blocks"
            SET DEFAULT '1'
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_blocks" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_blocks" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_blocks" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_packages" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "next_month_packages" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_packages" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "current_month_packages" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ADD "address" character varying(512)
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "max_blocks" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "max_blocks" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "min_blocks" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "tenants"
            ALTER COLUMN "min_blocks" DROP NOT NULL
        `);
  }
}
