import { MigrationInterface, QueryRunner } from 'typeorm';

export class Tenant1698467702021 implements MigrationInterface {
  name = 'Tenant1698467702021';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        CREATE TABLE "tenants" (
            "id" BIGSERIAL NOT NULL,
            "name" character varying(255) NOT NULL,
            "description" character varying(512),
            "contact_name" character varying(255),
            "contact_email" character varying(255) NOT NULL,
            "contact_phone" character varying(255),
            "min_blocks" integer,
            "max_blocks" integer,
            "start_date" date,
            "expired_date" date,
            "is_active" boolean NOT NULL DEFAULT true,
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            CONSTRAINT "PK_53be67a04681c66b87ee27c9321" PRIMARY KEY ("id")
        )
    `);

    await queryRunner.query(`
        CREATE UNIQUE INDEX "IDX_131aa6229f6e235bb17c596546" ON "tenants" ("name")
        WHERE deleted_at IS NULL
    `);
    await queryRunner.query(`
        CREATE UNIQUE INDEX "IDX_e4f1984f930915e68761e79330" ON "tenants" ("contact_email")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        DROP INDEX "public"."IDX_e4f1984f930915e68761e79330"
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_131aa6229f6e235bb17c596546"
    `);
    await queryRunner.query(`
        DROP TABLE "tenants"
    `);
  }
}
