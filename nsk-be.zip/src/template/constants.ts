export enum TemplateType {
  Standard = 1,
  Custom = 2,
}

export const CUSTOM_TEMPLATE_CODE_PREFIX = 'Custom-T';
