import { ApiPropertyOptional } from '@nestjs/swagger';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { TemplateType } from '../constants';
import { IsOptional, Matches } from 'class-validator';

export class TemplateFindQueryDto extends FindQueryDto {
  @ApiPropertyOptional()
  name?: string;

  @ApiPropertyOptional({
    name: 'type',
    example: '1|2',
    enum: TemplateType,
  })
  type?: number;

  @ApiPropertyOptional({
    name: 'sort',
    example: '-name',
    description:
      'Filter sort by id, name, category, createdAt, updatedAt, tenantId. Default is ASC. Minus before is DESC',
  })
  @IsOptional()
  @Matches(/^(?:-)?(?:id|name|category|createdAt|updatedAt|tenantId)?$/, {
    message: 'Invalid input format',
  })
  sort?: string;
}
