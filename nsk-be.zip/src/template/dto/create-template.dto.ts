import { ApiPropertyOptional } from '@nestjs/swagger';
import { TemplateFieldDto } from './template-field.dto';
import { ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateTemplateDto {
  @ApiPropertyOptional()
  name?: string;

  @ApiPropertyOptional()
  description?: string;

  @ApiPropertyOptional()
  category?: string;

  @ApiPropertyOptional({ type: [TemplateFieldDto] })
  @ValidateNested({ each: true })
  @Type(() => TemplateFieldDto)
  fields?: TemplateFieldDto[];

  @ApiPropertyOptional({ type: [TemplateFieldDto] })
  @ValidateNested({ each: true })
  @Type(() => TemplateFieldDto)
  tableFields?: TemplateFieldDto[];
}
