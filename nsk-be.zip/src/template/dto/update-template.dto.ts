import { CreateTemplateDto } from './create-template.dto';

export class UpdateTemplateDto extends CreateTemplateDto {}
