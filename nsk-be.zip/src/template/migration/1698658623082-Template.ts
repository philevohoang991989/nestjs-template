import { MigrationInterface, QueryRunner } from 'typeorm';

export class Template1698658623082 implements MigrationInterface {
  name = 'Template1698658623082';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "templates" (
        "id" BIGSERIAL NOT NULL, 
        "tenant_id" bigint,
        "name" character varying(255) NOT NULL,
        "description" character varying(512) NOT NULL,
        "category" character varying(255) NOT NULL,
        "fields" jsonb NOT NULL, 
        "table_fields" jsonb NOT NULL,
        "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        "deleted_at" TIMESTAMP WITH TIME ZONE,
        CONSTRAINT "PK_515948649ce0bbbe391de702ae5" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(`CREATE INDEX "IDX_ddd7ea53812fb25d98cc335792" ON "templates" ("tenant_id") `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."IDX_ddd7ea53812fb25d98cc335792"`);
    await queryRunner.query(`DROP TABLE "templates"`);
  }
}
