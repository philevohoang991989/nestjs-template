import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddCodeToTemplate1700646246057 implements MigrationInterface {
  name = 'AddCodeToTemplate1700646246057';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "templates" ADD "code" character varying(255)
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "templates" DROP COLUMN "code"
        `);
  }
}
