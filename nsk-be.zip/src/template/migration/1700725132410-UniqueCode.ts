import { MigrationInterface, QueryRunner } from 'typeorm';

export class UniqueCode1700725132410 implements MigrationInterface {
  name = 'UniqueCode1700725132410';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "templates"
            ALTER COLUMN "code"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "templates"
            ADD CONSTRAINT "UQ_be38737bf339baf63b1daeffb55" UNIQUE ("code")
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "templates" DROP CONSTRAINT "UQ_be38737bf339baf63b1daeffb55"
        `);
    await queryRunner.query(`
            ALTER TABLE "templates"
            ALTER COLUMN "code" DROP NOT NULL
        `);
  }
}
