import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  NotFoundException,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { TemplateService } from './template.service';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { TemplateFindQueryDto } from './dto/template-find-query.dto';
import { Template } from './entity/template.entity';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { Logger } from 'winston';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { CreateTemplateDto } from './dto/create-template.dto';
import { UpdateTemplateDto } from './dto/update-template.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Roles } from 'src/user/constants';
import { RolesGuard } from 'src/shared/guards/roles.guard';

@ApiTags('template')
@Controller('template')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
export class TemplateController {
  constructor(
    private templateService: TemplateService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
  ) {}

  @Get()
  @ApiOperation({
    summary: 'List and filter templates',
  })
  @RolesDecorator(Roles.Tenant)
  async find(@Query(NormalizeFindQueryPipe) query: TemplateFindQueryDto, @Req() req): Promise<Pagination<Template>> {
    try {
      return await this.templateService.paginate(query, req.user.tenantId);
    } catch (e) {
      this.logger.error(e.message, e.stack, TemplateController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Post()
  @ApiOperation({
    summary: 'Create a new template',
  })
  @RolesDecorator(Roles.Tenant)
  async create(@Body() dto: CreateTemplateDto, @Req() req): Promise<Template> {
    const data = { ...dto, tenantId: req.user.tenantId };

    try {
      return await this.templateService.create(data);
    } catch (e) {
      this.logger.error(e.message, e.stack, TemplateController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get('compact')
  @RolesDecorator(Roles.Tenant)
  async getCompactList(@Req() req): Promise<Array<Template>> {
    try {
      return await this.templateService.getCompactList(req.user.tenantId);
    } catch (e) {
      this.logger.error(e.message, e.stack, TemplateController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get(':id')
  @ApiParam({ name: 'id' })
  @ApiOperation({
    summary: 'Get a detail template',
  })
  @RolesDecorator(Roles.Tenant)
  async findById(@Param('id', ParseIntPipe) id: number, @Req() req): Promise<Template> {
    try {
      return await this.templateService.findById(id, req.user.tenantId);
    } catch (e) {
      this.logger.error(e.message, e.stack, TemplateController.name);
      throw new NotFoundException(e.message);
    }
  }

  @Put(':id')
  @ApiOperation({
    summary: 'Update a detail template',
  })
  @RolesDecorator(Roles.Tenant)
  async update(@Param('id') id: number, @Body() dto: UpdateTemplateDto, @Req() req): Promise<Template> {
    try {
      return await this.templateService.update(id, req.user.tenantId, dto);
    } catch (e) {
      this.logger.error(e.message, e.stack, TemplateController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Delete(':id')
  @ApiOperation({
    summary: 'Delete a detail template',
  })
  @RolesDecorator(Roles.Tenant)
  async delete(@Param('id') id: number, @Req() req): Promise<Template> {
    try {
      return await this.templateService.remove(id, req.user.tenantId);
    } catch (e) {
      this.logger.error(e.message, e.stack, TemplateController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Post('generate-standard-template')
  @ApiOperation({
    summary: 'Generate standard templates',
  })
  @RolesDecorator(Roles.Partner)
  async generateStandardTemplate(): Promise<Template[]> {
    try {
      return await this.templateService.generateStandardTemplate();
    } catch (e) {
      this.logger.error(e.message, e.stack, TemplateController.name);
      throw new BadRequestException(e.message);
    }
  }
}
