import { Tenant } from 'src/tenant/entity/tenant.entity';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  name: 'templates',
})
export class Template {
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @Column({
    name: 'tenant_id',
    nullable: true,
  })
  tenantId: number;

  @Column({
    name: 'code',
    length: 255,
    nullable: false,
    unique: true,
  })
  code: string;

  @Column({
    name: 'name',
    length: 255,
    nullable: false,
  })
  name: string;

  @Column({
    name: 'description',
    length: 512,
    nullable: false,
  })
  description: string;

  @Column({
    name: 'category',
    length: 255,
    nullable: false,
  })
  category: string;

  @Column({
    name: 'fields',
    type: 'jsonb',
    nullable: false,
  })
  fields: object[];

  @Column({
    name: 'table_fields',
    type: 'jsonb',
    nullable: false,
  })
  tableFields: object[];

  @ManyToOne(() => Tenant, (tenant) => tenant.templates, { nullable: true, createForeignKeyConstraints: false })
  @JoinColumn({
    name: 'tenant_id',
  })
  @Index()
  tenant: Tenant;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamptz',
  })
  deletedAt: Date;
}
