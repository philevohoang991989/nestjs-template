import { Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Template } from './entity/template.entity';
import { Brackets, Repository } from 'typeorm';
import { TemplateFindQueryDto } from './dto/template-find-query.dto';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { CUSTOM_TEMPLATE_CODE_PREFIX, TemplateType } from './constants';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { Cache } from 'cache-manager';
import { CACHE_MANAGER } from '@nestjs/cache-manager';

@Injectable()
export class TemplateService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
    @InjectRepository(Template) private templateRepository: Repository<Template>,
  ) {}

  async paginate(filter: TemplateFindQueryDto, tenantId: number): Promise<Pagination<Template>> {
    const qb = this.templateRepository.createQueryBuilder('template');

    if (filter.type in TemplateType) {
      if (filter.type == TemplateType.Standard) {
        qb.where('(template.tenantId IS NULL)');
      } else {
        qb.where('(template.tenantId = :tenantId)', { tenantId: tenantId });
      }
    } else {
      qb.where('(template.tenantId = :tenantId OR template.tenantId IS NULL)', { tenantId: tenantId });
    }

    if (filter.name) {
      const name = filter.name.trim();
      qb.andWhere(
        new Brackets((subqb) => {
          subqb
            .where('template.name ILIKE :name ', { name: `%${name}%` })
            .orWhere('template.category ILIKE :name', { name: `%${name}%` });
        }),
      );
    }

    if (filter.sort) {
      qb.orderBy(getOrderByClause(filter.sort, 'template'));
    } else {
      qb.orderBy('template.id', 'DESC');
    }

    const results = await qb
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();

    return new Pagination(results);
  }

  async getCompactList(tenantId: number): Promise<Array<Template>> {
    const qb = this.templateRepository.createQueryBuilder('template');

    qb.where('(template.tenantId = :tenantId OR template.tenantId IS NULL)', { tenantId: tenantId });
    qb.select(['template.id as id', `CONCAT(template.code, ' - ', template.name) as name`]);
    qb.orderBy('template.tenantId', 'DESC');

    const results = await qb.getRawMany();

    return results;
  }

  async create(data): Promise<Template> {
    data.fields = data.fields || [];
    data.tableFields = data.tableFields || [];
    data.code = crypto.randomUUID();

    const template = await this.templateRepository.save(data);
    template.code = CUSTOM_TEMPLATE_CODE_PREFIX + template.id;

    return await this.templateRepository.save(template);
  }

  async findById(id: number, tenantId: number): Promise<Template> {
    const cacheKey = `template_${tenantId}_${id}`;
    const templateCache: Template = await this.cacheManager.get(cacheKey);

    if (templateCache) {
      return templateCache;
    }

    const template = await this.templateRepository
      .createQueryBuilder('template')
      .where('(template.tenantId = :tenantId OR template.tenantId IS NULL)', { tenantId: tenantId })
      .andWhere('id=:id', { id: id })
      .getOneOrFail();

    if (template) {
      await this.cacheManager.set(cacheKey, template, 600000);
    }

    return template;
  }

  async update(id: number, tenantId: number, data): Promise<Template> {
    const cacheKey = `template_${tenantId}_${id}`;
    await this.cacheManager.del(cacheKey);

    const template = await this.templateRepository.findOneOrFail({
      where: {
        id: id,
        tenantId: tenantId,
      },
    });

    if (data.name) {
      template.name = data.name;
    }

    if (data.description) {
      template.description = data.description;
    }

    if (data.category) {
      template.category = data.category;
    }

    if (data.fields) {
      template.fields = data.fields;
    }

    if (data.tableFields) {
      template.tableFields = data.tableFields;
    }

    return this.templateRepository.save(template);
  }

  async remove(id: number, tenantId: number): Promise<Template> {
    const cacheKey = `template_${tenantId}_${id}`;
    await this.cacheManager.del(cacheKey);

    const template = await this.templateRepository.findOneOrFail({
      where: {
        id: id,
        tenantId: tenantId,
      },
    });

    if (template) {
      this.templateRepository.softRemove(template);
    }

    return template;
  }

  async generateStandardTemplate(): Promise<Template[]> {
    const jsonData = fs.readFileSync(path.join(process.cwd(), './master-data/standard-template.json'), {
      encoding: 'utf8',
    });

    const templateData = JSON.parse(jsonData);

    await this.templateRepository.upsert(templateData, ['code']);

    return templateData;
  }
}
