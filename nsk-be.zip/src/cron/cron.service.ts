import { Inject, Injectable } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { GenerateInvoiceService } from 'src/invoice/generate-invoice.service';
import { Logger } from 'winston';
import * as moment from 'moment';
import { InvoiceService } from 'src/invoice/invoice.service';
import { TenantService } from 'src/tenant/tenant.service';

@Injectable()
export class CronService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    private generateInvoiceService: GenerateInvoiceService,
    private invoiceService: InvoiceService,
    private tenantService: TenantService,
  ) {}

  // @Cron(CronExpression.EVERY_HOUR)
  @Cron(CronExpression.EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT)
  async generateInvoiceMonthly(): Promise<void> {
    try {
      const previousMonth = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD');

      return await this.generateInvoiceService.create(previousMonth);
    } catch (e) {
      this.logger.error(e.message, e.stack, CronService.name);
    }
  }

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  async updateOverdueInvoicesDaily(): Promise<void> {
    try {
      await this.invoiceService.updateOverdueInvoices();
      return;
    } catch (e) {
      this.logger.error(e.message, e.stack, CronService.name);
    }
  }

  // @Cron('* * 0 1 * *')
  // @Cron(CronExpression.EVERY_30_SECONDS)
  @Cron(CronExpression.EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT)
  async updateTenantPackageMonthly(): Promise<void> {
    try {
      const month = moment().startOf('month').format('YYYY-MMM-DD');

      await this.tenantService.updateCurrentBlockMonthly();
      await this.tenantService.upsertUsageBlockFromTenant(month);
      await this.tenantService.callApiTenantOcrService(month);
      await this.tenantService.callApiPartnerOcrService(month);
    } catch (e) {
      this.logger.error(e.message, e.stack, CronService.name);
    }
  }
}
