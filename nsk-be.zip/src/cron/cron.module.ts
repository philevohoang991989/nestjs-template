import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Invoice } from 'src/invoice/entity/invoice.entity';
import { CronService } from './cron.service';
import { GenerateInvoiceService } from 'src/invoice/generate-invoice.service';
import { InvoiceModule } from 'src/invoice/invoice.module';
import { TenantModule } from 'src/tenant/tenant.module';

@Module({
  imports: [TypeOrmModule.forFeature([Invoice]), InvoiceModule, TenantModule],
  providers: [CronService, GenerateInvoiceService],
  controllers: [],
  exports: [],
})
export class CronModule {}
