import { Injectable } from '@nestjs/common';
import * as Excel from 'exceljs';
import { Invoice } from 'src/invoice/entity/invoice.entity';
import * as path from 'path';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const XlsxPopulate = require('xlsx-populate');

const SPECIAL_PANEL_NAME = '特殊パネル';
const ONSITE_CONSTRUCTION_NAME = '現場施工';

@Injectable()
export class ExcelService {
  getG3Info(builderName, areaInfo) {
    if (
      builderName.includes('飯田産業') &&
      ['2024年仕様-1', '2024年仕様–1', '2024年仕様-2', '2024年仕様–2', '2023年仕様-3', '2023年仕様–3', '2023年仕様-4', '2023年仕様–4'].includes(areaInfo)
    ) {
      return ['2024年仕様-1', '2024年仕様-2', '2023年仕様-4', '2024年仕様–1', '2024年仕様–2', '2023年仕様–4'].includes(areaInfo)
        ? '等級5仕様QD73㎜'
        : (['2023年仕様–3', '2023年仕様-3'].includes(areaInfo)
        ? 'DF60mm'
        : '');
    }
  }
  checkSpecialCharacterCode(code) {
    return (code.match(/^\d+(M|K|SH)/) || code.match(/^(M|K|SH)/)) &&
      !code.match(/^\d+(MA|MAX|MAL|MNT|MNTW|MNTWH|MAW)$/)
      ? true
      : false;
  }
  checkNotgoodCode(code) {
    return ['中心用', '*', '(*)', 'NG', 'パネル 下端カット'].includes(code);
  }
  checkSpecialPanelCode(code) {
    return code.includes(SPECIAL_PANEL_NAME);
  }
  checkOnsiteConstructionCode(code) {
    return code.includes(ONSITE_CONSTRUCTION_NAME);
  }
  async createExcelFileShiba(data: any) {
    const baseInfoMapping: object = {
      construct_type: ['E3'],
      num_S: ['E4'],
      builder_name: ['B3'],
      anken: ['B4', 'N4', 'AA4'],
      area_info: ['M3'],
    };

    const tableMapping = {
      index: ['B', 'N', 'AA'],
      code: ['C', 'O', 'AB'],
      note: ['D', 'P', 'AC'],
    };

    try {
      return XlsxPopulate.fromFileAsync(path.join(process.cwd(), './dist/excel/template/shiba_output_form.xlsm'))
        .then(async (workbook) => {
          const sheet = workbook.sheet('梁欠表3F');

          // fill base infos
          const baseInfos = data.fields[0];
          Object.keys(baseInfoMapping).forEach((key) => {
            const dataByKey = baseInfos[key];
            const positionListByKey = baseInfoMapping[key];
            for (let i = 0; i < positionListByKey.length; i++) {
              if (dataByKey && positionListByKey[i]) {
                sheet.cell(positionListByKey[i]).value(key === 'area_info' ? '' : dataByKey);
              }
            }
          });

          const textG3 = this.getG3Info(baseInfos.builder_name, baseInfos.area_info);
          const g3Value = textG3 ? textG3 : baseInfos.construct_type;
          sheet.cell('G3').value(g3Value);

          const regexp = /\d{1,}型/g;
          if (baseInfos.construct_type) {
            const selectedText = baseInfos.construct_type.match(regexp);
            if (selectedText && selectedText.length && selectedText[0]) {
              sheet.cell('E3').value(selectedText[0]);
            }
          }

          // fill table
          const tables = data.table;
          const START_ROW = 8;
          for (let i = 0; i < tables.length; i++) {
            const table = tables[i];
            const tableData = table.data;
            const floor = table.floor;
            const codeCol = tableMapping.code[floor - 1];
            const indexCol = tableMapping.index[floor - 1];
            const noteCol = tableMapping.note[floor - 1];
            let currentRow = START_ROW;
            for (let j = 0; j < tableData.length; j++) {
              const index = tableData[j][0] as number;
              const code = tableData[j][1] as string;

              sheet.cell(`${indexCol}${currentRow}`).value(`${floor}F ${index}`);
              sheet.cell(`${codeCol}${currentRow}`).value(code);
              // if (['K', 'M'].includes(code[0]) || code.slice(0, 2) == 'SH') {

              if (this.checkNotgoodCode(code)) {
                sheet.cell(`${codeCol}${currentRow}`).value('NG');
                sheet.cell(`${codeCol}${currentRow}`).style('bold', true);
                sheet.cell(`${codeCol}${currentRow}`).style('fill', 'FF0000');
                sheet.cell(`${noteCol}${currentRow}`).style('fill', 'FF0000');
              } else if (this.checkSpecialCharacterCode(code)) {
                // add 上 and 下 note
                sheet.cell(`${noteCol}${currentRow}`).value('上');
                sheet.cell(`${noteCol}${currentRow + 1}`).value('下');
                currentRow += 1;
              } else if (this.checkSpecialPanelCode(code)) {
                sheet.cell(`${codeCol}${currentRow}`).value(SPECIAL_PANEL_NAME);
              } else if (this.checkOnsiteConstructionCode(code)) {
                sheet.cell(`${codeCol}${currentRow}`).value(ONSITE_CONSTRUCTION_NAME);
              }

              if (j < tableData.length - 1) {
                const nexIndex = tableData[j + 1][0] as number;
                const delta = nexIndex - index;
                if (delta > 1) {
                  for (let d = 1; d < delta; d++) {
                    sheet.cell(`${indexCol}${currentRow + d}`).value(`${floor}F ${index + d}`);
                  }
                }
                currentRow += delta;
              } else {
                currentRow += 1;
              }
            }
          }
          return workbook.outputAsync();
        })
        .then((data) => {
          return data;
        });
    } catch (err) {
      console.log('OOOOOOO this is the error: ' + err);
    }
  }

  async createExcelFile(header: any, data: any, workSheetName: string) {
    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet(workSheetName);

    if (header) {
      worksheet.columns = header;
    }

    data.forEach((item: any) => {
      worksheet.addRow(item);
    });

    return workbook.xlsx.writeBuffer();
  }

  async exportInvoice(invoice: Invoice, billDate: string) {
    const workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path.join(process.cwd(), './dist/excel/template/Invoice_Template.xlsx'));
    const ws = workbook.worksheets[0];

    ws.getCell('A2').value = invoice.tenant.name;
    ws.getCell('H2').value = invoice.id;
    ws.getCell('H3').value = billDate;
    ws.getCell('D15').value = invoice.currentMonthBlocks;

    return await workbook.xlsx.writeBuffer();
  }

  async exportTemplate(fileName: string, data: any, workSheetName = null) {
    const workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path.join(process.cwd(), fileName));
    const ws = workbook.worksheets[0];

    if (workSheetName) {
      ws.name = workSheetName;
    }

    data.forEach((element: any) => {
      ws.getCell(element.cell).value = element.value;
    });

    return await workbook.xlsx.writeBuffer();
  }
}
