import { MailerService } from '@nestjs-modules/mailer';
import { Inject, Injectable } from '@nestjs/common';
import { User } from 'src/user/entity/user.entity';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Logger } from 'winston';
import { I18nService } from 'nestjs-i18n';

@Injectable()
export class MailService {
  constructor(
    private mailerService: MailerService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    private readonly i18n: I18nService,
  ) {}

  sendForgotPassword(user: User, forgotPasswordUrl: string, lang = 'en') {
    this.mailerService
      .sendMail({
        to: user.email,
        subject: this.i18n.t('email.Forgot_Password_Email_Subject', { lang }),
        template: `./user-forgot-password-${lang}`,
        context: {
          url: forgotPasswordUrl,
          email: user.email,
        },
      })
      .then(() => {
        return true;
      })
      .catch((e) => {
        this.logger.error(e.message, e.stack, MailService.name);
      });
  }

  sendWelcomeEmail(loginUrl: string, email: string, password: string, lang = 'en') {
    this.mailerService
      .sendMail({
        to: email,
        subject: this.i18n.t('email.Welcome_Email_Subject', { lang }),
        template: `./welcome-${lang}`,
        context: {
          loginUrl,
          email,
          password,
        },
      })
      .then(() => {
        return true;
      })
      .catch((e) => {
        this.logger.error(e.message, e.stack, MailService.name);
      });
  }
}
