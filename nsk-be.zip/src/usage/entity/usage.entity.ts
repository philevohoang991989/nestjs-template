import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Tenant } from '../../tenant/entity/tenant.entity';

@Entity({
  name: 'usages',
})
@Index(['tenantId', 'month'], { unique: true })
export class Usage {
  @PrimaryGeneratedColumn({
    type: 'bigint',
  })
  id: number;

  @Column({
    name: 'tenant_id',
    nullable: false,
  })
  tenantId: number;

  @ManyToOne(() => Tenant, { nullable: false })
  @JoinColumn({
    name: 'tenant_id',
  })
  @Index()
  tenant: Tenant;

  @Column({
    name: 'month',
    type: 'date',
  })
  month: Date;

  @Column({
    name: 'page_count',
    default: 0,
  })
  pageCount: number;

  @Column({
    name: 'request_count',
    default: 0,
  })
  requestCount: number;

  @Column({
    name: 'current_month_packages',
    default: 0,
  })
  currentMonthPackages: number;

  @Column({
    name: 'current_month_blocks',
    default: 0,
  })
  currentMonthBlocks: number;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
  })
  updatedAt: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamptz',
  })
  deletedAt: Date;
}
