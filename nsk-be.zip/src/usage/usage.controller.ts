import { BadRequestException, Controller, Get, Inject, Query, Request, Res, UseGuards } from '@nestjs/common';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { UsageFindQueryDto } from './dto/usage-find-query.dto';
import { Logger } from 'winston';
import { UsageService } from './usage.service';
import { RolesDecorator } from 'src/shared/decorator/roles.decorator';
import { Roles } from 'src/user/constants';
import { RolesGuard } from 'src/shared/guards/roles.guard';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Response } from 'express';
import { ExcelService } from 'src/excel/excel.service';
import { UsageCurrentQueryDto } from './dto/usage-current-find-query.dto';
import { I18nContext, I18nService } from 'nestjs-i18n';
import { UsageFindExportQueryDto } from './dto/usage-find-export-query.dto';

@Controller('usage')
@ApiTags('usage')
@ApiBearerAuth()
@RolesDecorator(Roles.Partner, Roles.Tenant)
@UseGuards(JwtAuthGuard, RolesGuard)
export class UsageController {
  constructor(
    private usageSevice: UsageService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    private excelService: ExcelService,
    private readonly i18n: I18nService,
  ) {}

  @Get()
  async find(@Query(NormalizeFindQueryPipe) query: UsageFindQueryDto, @Request() req) {
    try {
      if (req.user?.roleId == Roles.Tenant && req.user?.tenantId) {
        query.tenantId = req.user.tenantId;
      }

      return await this.usageSevice.paginate(query);
    } catch (e) {
      this.logger.error(e.message, e.stack, UsageController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get('/current')
  async curreantUsage(@Query(NormalizeFindQueryPipe) query: UsageCurrentQueryDto, @Request() req) {
    try {
      if (req.user?.roleId == Roles.Tenant) {
        query.tenantId = req.user?.tenantId;
      }

      return await this.usageSevice.getCurrentUsage(query, req.user?.roleId);
    } catch (e) {
      this.logger.error(e.message, e.stack, UsageController.name);
      throw new BadRequestException(e.message);
    }
  }

  @Get('export')
  @ApiOperation({
    summary: 'Download usage list',
  })
  async exportList(
    @Query(NormalizeFindQueryPipe) query: UsageFindExportQueryDto,
    @Request() req,
    @Res() res: Response,
  ): Promise<void> {
    try {
      query.limit = 0;
      query.page = 1;

      if (req.user?.roleId == Roles.Tenant && req.user?.tenantId) {
        query.tenantId = req.user.tenantId;
      }

      const usageData = await this.usageSevice.paginate(query);
      const { data, fileName } =
        req.user?.roleId == Roles.Tenant
          ? await this.usageSevice.decorateUsageListForTenantForExport(usageData)
          : await this.usageSevice.decorateUsageListForPartnerForExport(usageData);
      const usageListName = this.i18n.t('usage.Usage List', { lang: I18nContext.current().lang });
      const fileBuffer = await this.excelService.exportTemplate(fileName, data, usageListName);

      res.setHeader('Content-Type', 'application/vnd.openxmlformats');
      res.setHeader('Content-Disposition', `attachment; filename=${usageListName}.xlsx`);
      res.send(fileBuffer);
    } catch (e) {
      this.logger.error(e.message, e.stack, UsageController.name);
      throw new BadRequestException(e.message);
    }
  }
}
