import { Module } from '@nestjs/common';
import { UsageService } from './usage.service';
import { UsageController } from './usage.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Usage } from './entity/usage.entity';
import { RequestModule } from 'src/request/request.module';
import { ExcelModule } from 'src/excel/excel.module';

@Module({
  imports: [TypeOrmModule.forFeature([Usage]), RequestModule, ExcelModule],
  controllers: [UsageController],
  providers: [UsageService],
})
export class UsageModule {}
