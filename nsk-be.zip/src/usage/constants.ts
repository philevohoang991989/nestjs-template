export enum StatusBoundary {
  NormalMax = 0.85,
}

export enum StatusName {
  Normal = 1,
  CloseToLimit = 2,
  FullCapacity = 3,
}
