import { OmitType } from '@nestjs/swagger';
import { UsageFindQueryDto } from './usage-find-query.dto';

export class UsageCurrentQueryDto extends OmitType(UsageFindQueryDto, ['sort'] as const) {}
