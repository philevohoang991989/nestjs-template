import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsOptional, Matches } from 'class-validator';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';

export class UsageFindQueryDto extends FindQueryDto {
  @ApiPropertyOptional({
    example: 6,
  })
  tenantId?: number;

  @ApiPropertyOptional({
    example: 1,
    description: '1: Normal| 2: Close to limit| 3: Full capacity',
  })
  @IsOptional()
  @IsIn(['1', '2', '3', ''])
  status?: number;

  @ApiPropertyOptional({
    example: '2023-09',
    description: 'From month. Format: YYYY-MM',
  })
  fromMonth?: string;

  @ApiPropertyOptional({
    example: '2023-10',
    description: 'To month. Format: YYYY-MM',
  })
  toMonth?: string;

  @ApiPropertyOptional({
    name: 'sort',
    example: '-tenant.name',
    description:
      'Filter sort by tenant.id,tenant.name,tenant.startDate,month,requestCount,pageCount,currentMonthBlocks. Default is ASC. Minus before is DESC',
  })
  @IsOptional()
  @Matches(/^(?:-)?(?:tenant.id|tenant.name|tenant.startDate|month|requestCount|pageCount|currentMonthBlocks)?$/, {
    message: 'Invalid sort field format',
  })
  sort?: string;
}
