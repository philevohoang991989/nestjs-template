import { ApiPropertyOptional, OmitType } from '@nestjs/swagger';
import { UsageFindQueryDto } from './usage-find-query.dto';
import { IsOptional, Matches } from 'class-validator';

export class UsageFindExportQueryDto extends OmitType(UsageFindQueryDto, ['sort'] as const) {
  @ApiPropertyOptional({
    description: 'Select language: en or jp',
  })
  @IsOptional()
  @Matches(/^(?:en|jp)?$/, { message: 'Invalid lang param format' })
  lang?: string;
}
