import { MigrationInterface, QueryRunner } from 'typeorm';

export class Usage_DefaultValue1702534509651 implements MigrationInterface {
  name = 'Usage_DefaultValue1702534509651';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "page_count"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "page_count"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "request_count"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "request_count"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_packages"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_packages"
            SET DEFAULT '0'
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_blocks"
            SET NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_blocks"
            SET DEFAULT '0'
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_blocks" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_blocks" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_packages" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "current_month_packages" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "request_count" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "request_count" DROP NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "page_count" DROP DEFAULT
        `);
    await queryRunner.query(`
            ALTER TABLE "usages"
            ALTER COLUMN "page_count" DROP NOT NULL
        `);
  }
}
