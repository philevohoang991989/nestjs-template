import { MigrationInterface, QueryRunner } from 'typeorm';

export class Usage1701080126958 implements MigrationInterface {
  name = 'Usage1701080126958';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "usages"
      ADD "current_month_packages" integer
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "usages" DROP COLUMN "current_month_packages"
    `);
  }
}
