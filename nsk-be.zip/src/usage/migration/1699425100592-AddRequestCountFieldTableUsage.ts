import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddRequestCountFieldTableUsage1699425100592 implements MigrationInterface {
  name = 'AddRequestCountFieldTableUsage1699425100592';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "usages"
            ADD "request_count" integer
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "usages" DROP COLUMN "request_count"
        `);
  }
}
