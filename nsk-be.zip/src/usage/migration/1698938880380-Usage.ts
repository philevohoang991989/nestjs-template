import { MigrationInterface, QueryRunner } from 'typeorm';

export class Usage1698938880380 implements MigrationInterface {
  name = 'Usage1698938880380';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "usages" (
                "id" BIGSERIAL NOT NULL,
                "tenant_id" bigint NOT NULL,
                "month" date NOT NULL,
                "page_count" integer,
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                CONSTRAINT "PK_75c9a59a186b326ad102170e0a7" PRIMARY KEY ("id")
            )
        `);
    await queryRunner.query(`
        CREATE UNIQUE INDEX "IDX_60c14c60471d39b655b095f866" ON "usages" ("tenant_id", "month")
    `);
    await queryRunner.query(`
        ALTER TABLE "usages"
        ADD CONSTRAINT "FK_e77f4fc40f76f96f80350ffa319" FOREIGN KEY ("tenant_id") REFERENCES "tenants"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        ALTER TABLE "usages" DROP CONSTRAINT "FK_e77f4fc40f76f96f80350ffa319"
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_60c14c60471d39b655b095f866"
    `);
    await queryRunner.query(`
        DROP TABLE "usages"
    `);
  }
}
