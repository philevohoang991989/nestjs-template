import { Injectable } from '@nestjs/common';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { Usage } from './entity/usage.entity';
import { UsageFindQueryDto } from './dto/usage-find-query.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { formatDate, getFirstDayOfCurrentMonth, getLastDayOfMonth, stringToDate } from 'src/shared/helpers/date.helper';
import { StatusBoundary, StatusName } from './constants';
import { Roles } from 'src/user/constants';
import { UsageCurrentQueryDto } from './dto/usage-current-find-query.dto';
import { I18nContext, I18nService } from 'nestjs-i18n';
import * as moment from 'moment';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class UsageService {
  constructor(
    @InjectRepository(Usage) private usageRepository: Repository<Usage>,
    private readonly i18n: I18nService,
    private configService: ConfigService,
  ) {}

  async paginate(filter: UsageFindQueryDto): Promise<Pagination<any>> {
    const qb = this.queryConditions(filter);
    qb.leftJoin('usage.tenant', 'tenant');

    if (filter.sort) {
      qb.orderBy(getOrderByClause(filter.sort, 'usage'));
    } else {
      qb.orderBy('usage.id', 'DESC');
    }

    const results = await qb
      .select('usage')
      .addSelect(['tenant.id', 'tenant.name', 'tenant.startDate'])
      .offset(+filter.limit * (+filter.page - 1))
      .limit(+filter.limit)
      .getManyAndCount();
    const usageItems = await this.decorateUsageResponse(results[0]);

    return new Pagination([usageItems, results[1]]);
  }

  queryConditions(filter: UsageFindQueryDto, withDeleted = true) {
    const qb = this.usageRepository.createQueryBuilder('usage');

    if (withDeleted) {
      qb.withDeleted().andWhere('usage.deleted_at IS NULL');
    }

    if (filter.tenantId) {
      qb.andWhere('usage.tenantId = :tenantId', { tenantId: filter.tenantId });
    }

    if (filter.fromMonth) {
      qb.andWhere('usage.month >= :fromMonth', { fromMonth: filter.fromMonth + '-01' });
    }

    if (filter.toMonth) {
      const toMonth = getLastDayOfMonth(filter.toMonth);
      qb.andWhere('usage.month <= :toMonth', { toMonth: formatDate(toMonth, 'yyyy-MM-dd') });
    }

    if (filter.status) {
      const pagesPerBlock = +this.configService.get('parameter').pagePerBlock;

      if (filter.status == StatusName.Normal) {
        qb.andWhere('usage.pageCount < usage.currentMonthBlocks * CAST(:normalMax AS dec(5,2))', {
          normalMax: pagesPerBlock * StatusBoundary.NormalMax,
        });
      } else if (filter.status == StatusName.CloseToLimit) {
        qb.andWhere('usage.pageCount >= usage.currentMonthBlocks * CAST(:normalMax AS dec(5,2))', {
          normalMax: pagesPerBlock * StatusBoundary.NormalMax,
        });
        qb.andWhere('usage.pageCount < usage.currentMonthBlocks * :closeToLimit', {
          closeToLimit: pagesPerBlock,
        });
      } else if (filter.status == StatusName.FullCapacity) {
        qb.andWhere('usage.pageCount >= usage.currentMonthBlocks * :closeToLimit', {
          closeToLimit: pagesPerBlock,
        });
      }
    }

    return qb;
  }

  async getCurrentUsage(query: UsageCurrentQueryDto, roleId: number) {
    if (roleId == Roles.Tenant) {
      const currentMonth = getFirstDayOfCurrentMonth();
      query.fromMonth = formatDate(currentMonth, 'yyyy-MM');
      query.toMonth = query.fromMonth;
    }

    query.limit = 0;
    const qb = this.queryConditions(query, false);
    const result = await qb
      .select('SUM(usage.currentMonthBlocks)', 'totalBlockRegistered')
      .addSelect('SUM(usage.pageCount)', 'pageUsed')
      .getRawOne();

    return result;
  }

  async decorateUsageResponse(usageItems: Usage[]) {
    return usageItems.map((element: Usage) => {
      const status = this.getStatusOfUsage(element.pageCount, element.currentMonthBlocks);
      delete element.currentMonthPackages;

      return {
        ...element,
        status: status,
        month: moment(element.month).format('yyyy-MM'),
      };
    });
  }

  getStatusOfUsage(pageCount: number, currentBlock: number) {
    const pagesPerBlock = this.configService.get('parameter').pagePerBlock;
    const normalPagePerBlock = pagesPerBlock * StatusBoundary.NormalMax;
    return pageCount < currentBlock * normalPagePerBlock
      ? StatusName.Normal
      : pageCount < currentBlock * pagesPerBlock
      ? StatusName.CloseToLimit
      : StatusName.FullCapacity;
  }

  async decorateUsageListForPartnerForExport(usageData: Pagination<Usage>) {
    const data = [];
    const fileName = `./src/excel/template/Usage_List_Partner_${I18nContext.current().lang}.xlsx`;

    if (!usageData.items.length) {
      return {
        data,
        fileName,
      };
    }

    const lang = I18nContext.current().lang;
    const statusNameMapping = {
      1: this.i18n.t('usages.Normal', { lang }),
      2: this.i18n.t('usages.CloseToLimit', { lang }),
      3: this.i18n.t('usages.FullCapacity', { lang }),
    };
    let row = 2;

    usageData.items.forEach((usage) => {
      const month = stringToDate(usage.month, 'YYYY-MM-DD');
      const status = this.getStatusOfUsage(usage.pageCount, usage.currentMonthBlocks);
      const statusName = statusNameMapping[status] || this.i18n.t('usages.Normal', { lang });

      data.push(
        { cell: 'A' + row, value: usage.tenant?.id },
        { cell: 'B' + row, value: usage.tenant?.name },
        { cell: 'C' + row, value: usage.tenant?.startDate },
        { cell: 'D' + row, value: formatDate(month, 'yyyy-MM') },
        { cell: 'E' + row, value: usage.requestCount },
        { cell: 'F' + row, value: usage.pageCount },
        { cell: 'G' + row, value: usage.currentMonthBlocks },
        { cell: 'H' + row, value: statusName },
      );
      row++;
    });

    return {
      data,
      fileName,
    };
  }

  async decorateUsageListForTenantForExport(usageData: Pagination<Usage>) {
    const data = [];
    const fileName = `./src/excel/template/Usage_List_Tenant_${I18nContext.current().lang}.xlsx`;

    if (!usageData.items.length) {
      return {
        data,
        fileName,
      };
    }

    let row = 2;
    usageData.items.forEach((usage) => {
      const month = stringToDate(usage.month, 'YYYY-MM-DD');

      data.push(
        { cell: 'A' + row, value: formatDate(month, 'yyyy-MM') },
        { cell: 'B' + row, value: usage.requestCount },
        { cell: 'C' + row, value: usage.pageCount },
        { cell: 'D' + row, value: usage.currentMonthBlocks },
      );
      row++;
    });

    return {
      data,
      fileName,
    };
  }
}
