import {
  OnGatewayInit,
  OnGatewayConnection,
  OnGatewayDisconnect,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server } from 'socket.io';
import { EventService } from './event.service';

@WebSocketGateway({
  cors: { origin: '*' },
})
export class EventGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  constructor(private eventService: EventService) {}

  async afterInit(server: Server) {
    this.eventService.socket = server;
  }

  async handleConnection(socket: any) {
    const user = socket.user;
    const channelName = `Channel_${user.tenantId}`;

    // Join channel
    socket.join(channelName);
    this.server.to(channelName).emit('onConnect', `${user.name} joined room`);
  }

  async handleDisconnect(socket: any) {
    const user = socket.user;
    const channelName = `Channel_${user.tenantId}`;
    this.server.to(channelName).emit('onDisconnect', `${user.name} left room`);
  }
}
