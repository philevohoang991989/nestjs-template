import { ConfigModule } from '@nestjs/config';
import { DataSource } from 'typeorm';
import databaseConfig from './src/shared/config/psql.config';

ConfigModule.forRoot({
  isGlobal: true,
  load: [databaseConfig],
});

// TODO: use database config
const datasource = new DataSource({
  type: 'postgres',
  host: process.env.PSQL_HOST,
  port: +process.env.PSQL_PORT,
  username: process.env.PSQL_USER,
  password: process.env.PSQL_PASSWORD,
  database: process.env.PSQL_DATABASE,
  schema: process.env.PSQL_SCHEMA || 'public',
  entities: ['dist/**/*.entity{.ts,.js}'],
  migrationsTableName: 'migrations',
  migrations: ['dist/**/migration/*.js'],
  synchronize: false,
  logging: false,
});

export default datasource;
