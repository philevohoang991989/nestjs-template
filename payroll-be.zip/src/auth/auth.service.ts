import { Inject, Injectable, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { MailService } from 'src/mail/mail.service';
import { ERROR_CODE } from 'src/shared/constants/common.constant';
import { ResponseDTO } from 'src/shared/dto/base.dto';
import { User } from 'src/users/entity/user.entity';
import { UserService } from 'src/users/user.service';
import { ChangePasswordDTO } from './dto/change-password.dto';
import { ResetPasswordDTO } from './dto/reset-password.dto';
import { ConfigService } from '@nestjs/config';
import moment = require('moment-timezone');
import { DEFAULT_TIMEZONE } from 'src/shared/constants';
import { getManager, Repository } from 'typeorm';
import { ActiveAccountDTO } from './dto/active-account';
import { pattern } from './constants';
import { Audit, AuditAction } from 'src/audit/entity/audit.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { UserRoleSingle } from 'src/users/entity/userRoleSingle.entity';
import { Role } from 'src/users/entity/role.entity';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';

@Injectable()
export class AuthService {
    constructor(
        @InjectRepository(Role) private roleRepository: Repository<Role>,
        @InjectRepository(User) private userRepository: Repository<User>,
        @InjectRepository(Audit) private auditRepository: Repository<Audit>,
        @InjectRepository(UserRoleSingle)
        private userRoleSingleRepository: Repository<UserRoleSingle>,
        private userService: UserService,
        private jwtService: JwtService,
        private mailService: MailService,
        private configService: ConfigService,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    ) {
        moment.tz.setDefault(DEFAULT_TIMEZONE);
    }

    async validateUser(username: string, plainPassword: string): Promise<User> {
        const user = await this.userService.findByUsername(username);
        if (user && (await this.userService.compareHashedPassword(plainPassword, user.password))) {
            delete user.password;
            return user;
        }
        return null;
    }

    async login({ username, password }): Promise<ResponseDTO> {
        this.logger.log('Starting process Login', 'PROFILING');
        let retryNumber;
        this.logger.log('Starting query findByUsername', 'PROFILING');
        const user = await this.userService.findByUsername(username.trim());
        this.logger.log('End query findByUsername', 'PROFILING');
        if (!user) {
            const userDeleted = await this.userRepository.find({
                where: { username: username.trim() },
                withDeleted: true,
            });

            if (userDeleted[0]?.deletedAt != null) {
                return {
                    data: userDeleted,
                    msgSts: {
                        message: 'Account Deleted',
                        code: ERROR_CODE.ACCOUNT_DELETED,
                    },
                };
            } else {
                return {
                    data: undefined,
                    msgSts: {
                        message: 'Username or password does not match',
                        code: ERROR_CODE.USERNAME_PASSWORD_NOT_MATCH,
                    },
                };
            }
        }
        if (user.blockAt && user.blockAt.valueOf() - Date.now() > 0) {
            return {
                data: undefined,
                msgSts: {
                    message: 'Account has been locked for 30 minutes',
                    code: ERROR_CODE.BLOCK_ACCOUNT,
                },
            };
        }
        const checkPassword = await this.userService.compareHashedPassword(password.trim(), user.password);
        if (!checkPassword) {
            retryNumber = user.retryNumber + 1;
            if (retryNumber >= 5) {
                const blockAt = moment().add(30, 'm').toDate();
                await this.userService.update(user.id, { blockAt });
            } else {
                await this.userService.update(user.id, { retryNumber });
            }
            return {
                data: undefined,
                msgSts: {
                    message: 'Username or password does not match',
                    code: ERROR_CODE.USERNAME_PASSWORD_NOT_MATCH,
                },
            };
        }
        if (!user.isActive) {
            return {
                data: undefined,
                msgSts: {
                    message: 'Your account has not been activated, please contact the system administrator!',
                    code: ERROR_CODE.ACCOUNT_NOT_ACTIVATED,
                },
            };
        }
        retryNumber = 0;
        await this.userService.update(user.id, { retryNumber });

        const payload = {
            username: user.username,
            userId: user.id,
            role: user.roleId,
        };

        const roleUsers = await this.findRoleSingle(user.id);

        const role = await this.roleRepository.findOne({
            where: { id: user.roleId },
        });
        this.logger.log('End process Login', 'PROFILING');
        return new ResponseDTO({
            data: {
                access_token: this.jwtService.sign(payload),
                name: user.name,
                id: user.id,
                username: user.username,
                role: user.roleId,
                roleName: role.name,
                roleUsers,
            },
            msgSts: {
                message: 'Login success',
                code: ERROR_CODE.SUCCESS,
            },
        });
    }

    async findRoleSingle(id: number) {
        return await this.userRoleSingleRepository
            .createQueryBuilder('user_role_single')
            .andWhere('user_role_single.userId = :userId', {
                userId: id,
            })
            .getMany();
    }

    async requestResetPassword(username: string, language: string): Promise<ResponseDTO> {
        const user = await this.validateUsername(username);
        if (!user) {
            return {
                data: undefined,
                msgSts: {
                    message: 'User not found',
                    code: ERROR_CODE.USER_NOT_FOUND,
                },
            };
        }

        // Generate token: email
        const payload = {
            username: user.username,
            userId: user.id,
        };
        // Send email with reset_token
        const reset_token = this.jwtService.sign(payload, {
            expiresIn: '48h',
        });
        const link = `${this.configService.get('DOMAIN_URL')}/reset-password?token=${reset_token}`;
        const rs = await this.mailService.sendResetPassEmail(link, username, language, user.name);
        if (rs) {
            // Save reset token
            await this.userService.update(user.id, { resetToken: reset_token });
            return {
                data: undefined,
                msgSts: {
                    message: 'Request reset password success',
                    code: ERROR_CODE.SUCCESS,
                },
            };
        } else {
            return {
                data: undefined,
                msgSts: {
                    message: 'Request reset password failed: Email does not work',
                    code: ERROR_CODE.EMAIL_DOES_NOT_WORK,
                },
            };
        }
    }

    async resetPassword(data: ResetPasswordDTO): Promise<ResponseDTO> {
        if (!pattern.test(data.newPassword)) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'Password length must be at least 8 characters, letters, numbers and special characters.',
                },
            };
        }

        if (!data.resetToken) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.TOKEN_NOT_FOUND,
                    message: 'Token not found',
                },
            };
        }

        const decodeToken = this.jwtService.decode(data.resetToken);
        const username = decodeToken['username'];
        const dataSaveAudit = new ChangePasswordDTO();
        dataSaveAudit.username = username;
        dataSaveAudit.newPassword = data.newPassword;
        await this.saveAudit(dataSaveAudit);

        const user = await this.userService.findByUsername(username);
        // User not found
        if (!user) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'User not found',
                },
            };
        }

        // Token invalid
        if (user.resetToken !== data.resetToken) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.TOKEN_INVALID,
                    message: 'Token invalid',
                },
            };
        }

        //Token expired
        if (decodeToken['exp'] * 1000 <= new Date().getTime()) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.TOKEN_EXPIRED,
                    message: 'Token expired',
                },
            };
        }

        data.username = username;
        return await this.userService.resetPassword(data);
    }

    async changePassword(data: ChangePasswordDTO): Promise<ResponseDTO> {
        if (!pattern.test(data.newPassword)) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'Password length must be at least 8 characters, letters, numbers and special characters.',
                },
            };
        }
        await this.saveAudit(data);
        return await this.userService.changePassword(data);
    }

    async saveAudit(data: ChangePasswordDTO): Promise<any> {
        const user = await this.userRepository.findOne({
            where: {
                username: data.username.toLocaleLowerCase(),
            },
        });
        const audit = new Audit();
        audit.entityClass = 'User';
        audit.entityId = user.id.toString();
        audit.action = AuditAction.CHANGE_PASSWORD;
        audit.authorId = user.id;
        audit.oldValues = JSON.stringify(user);
        audit.newValues = data.newPassword;
        return await this.auditRepository.save(audit);
    }

    async changePasswordFirstLogin(dto: ActiveAccountDTO): Promise<ResponseDTO> {
        // Decode token
        const decodeToken = this.jwtService.decode(dto.resetToken);
        const username = decodeToken['username'];
        const user = await this.userService.findByUsername(username);
        // User not found
        if (!user) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'User not found',
                },
            };
        }

        // Check reset token is valid
        if (user.resetToken !== dto.resetToken) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.TOKEN_INVALID,
                    message: 'Reset token is invalid',
                },
            };
        }

        // Check reset token is not expired
        if (decodeToken['exp'] * 1000 <= new Date().getTime()) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.TOKEN_EXPIRED,
                    message: 'Token expired',
                },
            };
        }

        // Check password is valid
        if (user.password !== dto.oldPassword) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.OLD_PASSWORD_NOT_MATCH,
                    message: 'Password not match',
                },
            };
        }

        // Hash password
        user.password = await this.userService.hashPassword(dto.newPassword);
        user.isFirstLogin = false;
        user.blockAt = null;
        user.resetToken = null;
        user.isActive = true;
        user.expiredIn = moment().add(60, 'day').toDate();

        const updateUser = await this.userRepository.save(user);
        delete updateUser.password;
        return {
            data: updateUser,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Reset password success',
            },
        };
    }

    private async validateUsername(username: string): Promise<User> {
        const user = await this.userService.findByUsername(username);
        if (user) {
            delete user.password;
            return user;
        }
        return null;
    }
}
