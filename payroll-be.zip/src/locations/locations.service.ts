import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ERROR_CODE } from 'src/shared/constants/common.constant';
import { ResponseDTO } from 'src/shared/dto/base.dto';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { User } from 'src/users/entity/user.entity';
import { Brackets, Repository } from 'typeorm';
import { FilterLocationDTO } from './dto/filters-location.dto';
import { CreateUpdateLocationDTO } from './dto/location-create-update.dto';
import { Location } from './entity/location.entity';

const seedData = [
    { name: 'Location A', sol: '1001' },
    { name: 'Location B', sol: '1002' },
    { name: 'Location C', sol: '1003' },
    { name: 'Location D', sol: '1004' },
];

@Injectable()
export class LocationsService {
    constructor(
        @InjectRepository(User) private userRepository: Repository<User>,
        @InjectRepository(Location)
        private locationRepository: Repository<Location>,
    ) {}

    async seedData(): Promise<ResponseDTO> {
        const newLocations = await Promise.all(
            seedData.map((item: { name: string; sol: string }) => {
                const newLocation = new Location();
                newLocation.name = item.name;
                newLocation.sol = item.sol;
                return newLocation;
            }),
        );
        const payload = await this.locationRepository.save(newLocations);
        return {
            data: payload,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Seed data success',
            },
        };
    }

    async paginationIds(
        filters: FilterLocationDTO,
        query?: FindQueryDto,
    ): Promise<ResponseDTO> {
        const qb = this.locationRepository.createQueryBuilder('location');

        if (filters.keywords) {
            qb.andWhere(
                new Brackets(sqb => {
                    sqb.where('location.name ILIKE :keyword', {
                        keyword: `%${filters.keywords}%`,
                    }).orWhere('location.sol ILIKE :keyword');
                }),
            );
        }
        if (query.page == 1 && filters.ids && filters.ids.length > 0) {
            qb.andWhere('location.id IN (:...ids)', {
                ids: filters.ids,
            });
        } else {
            if (filters.ids && filters.ids.length > 0) {
                qb.andWhere('location.id NOT IN (:...ids)', {
                    ids: filters.ids,
                });
            }
        }

        const result = await qb
            .skip(+query.limit * (+query.page - 1))
            .take(+query.limit)
            .getManyAndCount();
        const results = new Pagination(result);
        if (query.page == 1 && filters.ids && filters.ids.length > 0) {
            const sols = await this.paginationSol(filters, query);
            results.items = results.items.concat(sols.items);

            results.items = results.items.filter(
                (value, index, self) =>
                    index === self.findIndex(t => t.id === value.id),
            );

            results.items = results.items.slice(0, +query.limit);
            results.totalItems = sols.totalItems;
        }
        return {
            data: results,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Get locations success',
            },
        };
    }

    async paginationSol(filters: FilterLocationDTO, query?: FindQueryDto) {
        const qb = this.locationRepository.createQueryBuilder('location');

        if (filters.keywords) {
            qb.andWhere(
                new Brackets(sqb => {
                    sqb.where('location.name ILIKE :keyword', {
                        keyword: `%${filters.keywords}%`,
                    }).orWhere('location.sol ILIKE :keyword');
                }),
            );
        }

        const result = await qb
            .skip(+query.limit * (+query.page - 1))
            .take(+query.limit)
            .getManyAndCount();
        const results = new Pagination(result);
        return results;
    }

    async pagination(
        filters: FilterLocationDTO,
        query?: FindQueryDto,
    ): Promise<ResponseDTO> {
        const qb = this.locationRepository.createQueryBuilder('location');

        if (filters.keywords) {
            qb.andWhere(
                new Brackets(sqb => {
                    sqb.where('location.name ILIKE :keyword', {
                        keyword: `%${filters.keywords}%`,
                    }).orWhere('location.sol ILIKE :keyword');
                }),
            );
        }

        qb.orderBy('location.id', 'DESC');

        const result = await qb
            .skip(+query.limit * (+query.page - 1))
            .take(+query.limit)
            .getManyAndCount();
        const results = new Pagination(result);

        for (let i = 0; i < results.items.length; i++) {
            const location = results.items[i];
            location['totalUser'] = await this.paginationUser(location.id);
        }

        return {
            data: results,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Get locations success',
            },
        };
    }

    async paginationUser(id): Promise<any> {
        const users = await this.userRepository
            .createQueryBuilder('user')
            .andWhere('user.locationId = :locationId', {
                locationId: id,
            })
            .getMany();

        if (users && users.length > 0) {
            return users.length;
        } else {
            return 0;
        }
    }

    async create(dto: CreateUpdateLocationDTO): Promise<ResponseDTO> {
        const location = new Location();
        location.name = dto.name;
        location.sol = dto.sol;

        const payload = await this.locationRepository.save(location);
        return {
            data: payload,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Create location success',
            },
        };
    }

    async update(
        id: number,
        dto: CreateUpdateLocationDTO,
    ): Promise<ResponseDTO> {
        const location = await this.locationRepository.findOne({
            where: { id: id },
        });
        if (!location) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'Location not found',
                },
            };
        }

        location.name = dto.name;
        location.sol = dto.sol;

        const payload = await this.locationRepository.save(location);
        return {
            data: payload,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Update location success',
            },
        };
    }

    async delete(id: number): Promise<ResponseDTO> {
        const location = await this.locationRepository.findOne({
            where: { id: id },
        });
        if (!location) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'Location not found',
                },
            };
        }

        await this.locationRepository.softDelete(id);
        return {
            data: undefined,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Delete location success',
            },
        };
    }
}
