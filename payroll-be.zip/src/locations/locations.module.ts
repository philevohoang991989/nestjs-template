import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/users/entity/user.entity';
import { Location } from './entity/location.entity';
import { LocationsController } from './locations.controller';
import { LocationsService } from './locations.service';

@Module({
    imports: [TypeOrmModule.forFeature([Location , User])],
    providers: [LocationsService],
    exports: [LocationsService],
    controllers: [LocationsController],
})
export class LocationsModule {}
