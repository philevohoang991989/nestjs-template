import { BaseEntity } from 'src/shared/entity/base.entity';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
    name: 'locations',
})
export class Location extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({
        name: 'name',
    })
    name: string;

    @Column({
        name: 'sol',
        nullable: true,
    })
    sol: string;
}
