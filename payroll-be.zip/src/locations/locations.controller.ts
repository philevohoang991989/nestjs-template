import {
    Body,
    Controller,
    Delete,
    Inject,
    Logger,
    Param,
    Post,
    Put,
    Query,
} from '@nestjs/common';
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { ResponseDTO } from 'src/shared/dto/base.dto';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { FilterLocationDTO } from './dto/filters-location.dto';
import { CreateUpdateLocationDTO } from './dto/location-create-update.dto';
import { LocationsService } from './locations.service';

@ApiTags('locations')
@Controller('locations')
// TODO: un-comment below line to enable authentication for user controller
// @UseGuards(new JwtAuthGuard())
@ApiBearerAuth()
export class LocationsController {
    constructor(
        private locationsService: LocationsService,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    ) {}

    @Post('seed')
    async seedData(): Promise<ResponseDTO> {
        return this.locationsService.seedData();
    }

    @Post('pagination')
    async pagination(
        @Body() dto: FilterLocationDTO,
        @Query(NormalizeFindQueryPipe) query: FindQueryDto,
    ): Promise<ResponseDTO> {
        return this.locationsService.pagination(dto, query);
    }

    @Post('pagination-ids')
    async paginationIds(
        @Body() dto: FilterLocationDTO,
        @Query(NormalizeFindQueryPipe) query: FindQueryDto,
    ): Promise<ResponseDTO> {
        return this.locationsService.paginationIds(dto, query);
    }

    @Post('create')
    async create(@Body() dto: CreateUpdateLocationDTO): Promise<ResponseDTO> {
        return this.locationsService.create(dto);
    }

    @Put('update/:id')
    @ApiParam({ name: 'id' })
    async update(
        @Param('id') id: number,
        @Body() dto: CreateUpdateLocationDTO,
    ): Promise<ResponseDTO> {
        return this.locationsService.update(id, dto);
    }

    @Delete(':id')
    @ApiParam({ name: 'id' })
    async delete(@Param('id') id: number): Promise<ResponseDTO> {
        return this.locationsService.delete(id);
    }
}
