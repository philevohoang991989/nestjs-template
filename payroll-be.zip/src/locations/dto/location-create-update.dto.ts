import { ApiProperty } from '@nestjs/swagger';

export class CreateUpdateLocationDTO {
    @ApiProperty()
    name: string;

    @ApiProperty()
    sol: string;
}
