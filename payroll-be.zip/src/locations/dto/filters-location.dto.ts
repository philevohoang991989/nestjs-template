import { ApiProperty } from '@nestjs/swagger';

export class FilterLocationDTO {
    @ApiProperty()
    keywords: string;

    @ApiProperty()
    ids: number[];
}
