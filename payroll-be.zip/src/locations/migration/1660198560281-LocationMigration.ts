import {MigrationInterface, QueryRunner} from "typeorm";

export class LocationMigration1660198560281 implements MigrationInterface {
    name = 'LocationMigration1660198560281'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ALTER COLUMN "role" DROP NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ALTER COLUMN "role" DROP DEFAULT
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ALTER COLUMN "role"
            SET DEFAULT '2'
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ALTER COLUMN "role"
            SET NOT NULL
        `);
    }

}
