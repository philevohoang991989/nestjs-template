import {MigrationInterface, QueryRunner} from "typeorm";

export class LocationMigrationAddSol1660277225142 implements MigrationInterface {
    name = 'LocationMigrationAddSol1660277225142'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."locations"
            ADD "sol" character varying
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."locations" DROP COLUMN "sol"
        `);
    }

}
