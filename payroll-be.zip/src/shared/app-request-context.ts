import { RequestContext } from '@medibloc/nestjs-request-context';
import { User } from 'src/users/entity/user.entity';

export class AppRequestContext extends RequestContext {
    user: User;
}
