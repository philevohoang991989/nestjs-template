import {
    BadRequestException,
    CanActivate,
    ExecutionContext,
    Injectable,
    Next,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ERROR_CODE } from 'src/shared/constants/common.constant';
import { UserService } from 'src/users/user.service';

@Injectable()
export class CheckChangePassword implements CanActivate {
    constructor(private readonly userService: UserService) {}
    async canActivate(context: ExecutionContext): Promise<boolean> {
        const request = context.switchToHttp().getRequest();
        const XAMZNOIDIC = 'x-amzn-oidc-identity';
        const userId = request.headers[XAMZNOIDIC];
        if (!userId) {
            return true;
        }
        const result = await this.userService.checkChangePassword(userId);

        if (result) {
            return true;
        }
        throw new BadRequestException({
            data: undefined,
            msgSts: {
                message: 'Please change password',
                code: ERROR_CODE.REQUEST_CHANGE_PASSWORD,
            },
        });
    }
}
