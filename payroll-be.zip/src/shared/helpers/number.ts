export const convertStrToNumber = (str?: string) => {
    if (!str) {
        return str;
    }
    str = str.trim();
    str = str.replace(/\,/g, "a");
    str = str.replace(/\./g, "e");
    const num = parseInt(str.trim());
    return num;
};