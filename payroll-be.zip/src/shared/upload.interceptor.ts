import {
    BadRequestException,
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ERROR_CODE } from './constants/common.constant';

@Injectable()
export class UploadInterceptor implements NestInterceptor {
    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
        return next.handle().pipe(
            catchError(error => {
                throw new BadRequestException({
                    data: undefined,
                    msgSts: {
                        message: error.message,
                        code: ERROR_CODE.UPLOAD_ERROR,
                    },
                });
            }),
        );
    }
}
