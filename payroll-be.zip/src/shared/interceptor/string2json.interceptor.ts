import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';

@Injectable()
export class StringToJsonInterceptor implements NestInterceptor {
  private readonly field: string;
  constructor(field: string) {
    this.field = field;
  }
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const ctx = context.switchToHttp();
    const req = ctx.getRequest();
    try {
      if (req.body) {
        if (!req.body[this.field]) {
          delete req.body[this.field];
        } else if (typeof req.body[this.field] === 'string') {
          req.body[this.field] = JSON.parse(req.body[this.field]);
        }
      }
    } catch (e) {}

    return next.handle();
  }
}
