import { RequestContext } from '@medibloc/nestjs-request-context';
import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';
import { AppRequestContext } from './app-request-context';

@Injectable()
/* eslint-disable */
export class AddToAppContextPipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata) {
    const context: AppRequestContext = RequestContext.get();
    context.user = value;
    return value;
  }
}
