import { ConfigValidate } from './constants';

export const imageFilter = (req: any, file: any, callback: any) => {
    const regex = ConfigValidate.FILE_TYPE;
    const formatFile = String(regex)
        .toUpperCase()
        .slice(4, -3);
    if (!file.originalname.match(regex)) {
        callback(
            new Error(
                `File format not supported, support format ${formatFile}`,
            ),
            false,
        );
    }
    if (+req.headers['content-length'] > ConfigValidate.TOTAL_SIZE) {
        callback(
            new Error(
                `Upload files are over the limit ${ConfigValidate.TOTAL_SIZE /
                    1024 ** 3}GB`,
            ),
            false,
        );
    }
    callback(null, true);
};
