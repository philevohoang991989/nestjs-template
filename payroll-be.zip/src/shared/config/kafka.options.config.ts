import { registerAs } from '@nestjs/config';
import { Transport } from '@nestjs/microservices';

export default registerAs('kafka.options', () => {
    return {
        transport: Transport.KAFKA,
        options: {
            client: {
                brokers: process.env.KAFKA_BROKERS.split(','),
            },
            consumer: {
                groupId: process.env.KAFKA_GROUP_NAME,
                sessionTimeout: 300000,
                heartbeatInterval: 200000,
                maxWaitTimeInMs: 250000,
            },
        },
    };
});
