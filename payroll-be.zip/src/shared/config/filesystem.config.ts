import { registerAs } from '@nestjs/config';
export default registerAs('filesystem', () => ({
  default: 'docs',
  disks: {
    docs: {
      driver: 's3',
      bucket: process.env.AWS_BUCKET,
      key: process.env.AWS_ACCESS_KEY_ID,
      secret: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION,
    },
    payrolls: {
      driver: 'local',
      basePath: process.env.PATH_PDF, // fully qualified path of the folder
      baseUrl: process.env.BASE_URL,
    }
  },
}));
