import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { User } from 'src/users/entity/user.entity';
import { getManager } from 'typeorm';

export const XAMZNOIDIC = 'x-amzn-oidc-identity';
export const CurrentUser = createParamDecorator(
    (data: (keyof User)[], ctx: ExecutionContext) => {
        const request = ctx.switchToHttp().getRequest();
        const userId = request.headers[XAMZNOIDIC];
        if (userId) {
            return getManager().findOne(User, {
                where: {
                    id: userId,
                },
                select: data,
                cache: 300000, // 5 minutes
            });
        }

        return null;
    },
);
