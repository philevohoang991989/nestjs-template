import { ApiProperty } from '@nestjs/swagger';

export class RetrainDTO {
    @ApiProperty()
    imageId: number;

    @ApiProperty()
    documentId: number;

    @ApiProperty()
    docType: number;

    @ApiProperty()
    bbox: object;

    @ApiProperty()
    word: string;

    @ApiProperty()
    label: string;

    @ApiProperty()
    gtrueBbox: object;

    @ApiProperty()
    gtrueWord?: string;

    @ApiProperty()
    gtrueLabel: string;

    @ApiProperty()
    gtrueDocType: number;
}
