import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Retrain } from './entity/retrain.entity';
import { Repository } from 'typeorm';
import { RetrainDTO } from './dto/retrain.dto';
import { Document } from 'src/documents/entity/document.entity';
import { AuditService } from 'src/audit/audit.service';
import { AuditAction } from 'src/audit/entity/audit.entity';

@Injectable()
export class ReTrainsService {
    constructor(
        @InjectRepository(Retrain)
        private retrainRepository: Repository<Retrain>,
        @InjectRepository(Document)
        private documentRepository: Repository<Document>,
        private auditService: AuditService,
    ) {}

    async create(dtos: RetrainDTO[], userId: number) {
        const retrainDatas: Retrain[] = [];
        for (let i = 0; i < dtos.length; i++) {
            const dto = dtos[i];
            const retrainData = new Retrain();
            retrainData.imageId = dto.imageId;
            retrainData.documentId = dto.documentId;
            retrainData.docType = dto.docType;
            retrainData.bbox = dto.bbox;
            retrainData.word = dto.word;
            retrainData.label = dto.label;
            retrainData.gtrueBbox = dto.gtrueBbox;
            retrainData.gtrueWord = dto.gtrueWord;
            retrainData.gtrueLabel = dto.gtrueLabel;
            retrainData.gtrueDocType = dto.gtrueDocType;
            retrainDatas.push(retrainData);
        }

        await this.updateDucument(dtos, userId);

        return await this.retrainRepository.save(retrainDatas);
    }

    async updateDucument(dtos: RetrainDTO[], userId: number) {
        const mapDocumentId = dtos.map((x) => x.documentId);
        const documentIds = Array.from(new Set(mapDocumentId));
        const documents = await this.documentRepository
            .createQueryBuilder('documents')
            .andWhere('documents.id IN (:...Ids)', {
                Ids: documentIds,
            })
            .getMany();
        for (const document of documents) {
            document.reTrain = true;
        }

        const documentsUp = await this.documentRepository.save(documents);

        this.auditService.saveAudit(
            documents,
            documents,
            AuditAction.EDIT_RECORDS,
            userId,
            documents[0].documentSetId,
        );

        return documentsUp;
    }

    async getReTrains(documentId: number) {
        const retrain = await this.retrainRepository
            .createQueryBuilder('retrains')
            .andWhere('retrains.documentId = :documentId', {
                documentId: documentId,
            })
            .getMany();
        return retrain;
    }
}
