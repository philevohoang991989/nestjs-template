import { Test, TestingModule } from '@nestjs/testing';
import { ReTrainsService } from './retrains.service';

describe('ReTrainsService', () => {
  let service: ReTrainsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ReTrainsService],
    }).compile();

    service = module.get<ReTrainsService>(ReTrainsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
