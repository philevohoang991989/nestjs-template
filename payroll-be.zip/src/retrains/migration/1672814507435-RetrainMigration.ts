import { MigrationInterface, QueryRunner } from 'typeorm';

export class RetrainsMigration1672814507435 implements MigrationInterface {
    name = 'RetrainsMigration1672814507435';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "public"."retrains" (
                "id" SERIAL NOT NULL,
                "image_id" integer,
                "document_id" integer,
                "doc_type" integer ,
                "bbox" jsonb,
                "word" character varying ,
                "label" character varying ,
                "gtrue_box" jsonb,
                "gtrue_word" character varying ,
                "gtrue_label" character varying ,
                "gtrue_doc_type" integer ,
                CONSTRAINT "PK_05dec3a41999dafac736105eb35" PRIMARY KEY ("id")
            )
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."retrains"
        `);
    }
}
