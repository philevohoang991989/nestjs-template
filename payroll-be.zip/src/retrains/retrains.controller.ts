import {
    BadRequestException,
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Req,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { ReTrainsService } from './retrains.service';
import { RetrainDTO } from './dto/retrain.dto';

@UseGuards(JwtAuthGuard)
@ApiTags('re-trains')
@Controller('re-trains')
@ApiBearerAuth()
export class ReTrainsController {
    constructor(private reTrainsService: ReTrainsService) {}

    @Post('create')
    async create(@Body() dtos: RetrainDTO[], @Req() req): Promise<any> {
        try {
            return await this.reTrainsService.create(dtos, req.user.userId);
        } catch (e) {
            throw new BadRequestException(e.message);
        }
    }

    @Get(':documentId')
    async getReTrains(@Param('documentId', ParseIntPipe) documentId: number) {
        return await this.reTrainsService.getReTrains(documentId);
    }
}
