import { Document } from 'src/documents/entity/document.entity';
import { DocumentImage } from 'src/documents/entity/documentImage.entity';
import {
    Column,
    Entity,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
} from 'typeorm';

@Entity({
    name: 'retrains',
})
export class Retrain {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({
        name: 'image_id',
    })
    imageId: number;

    @ManyToOne(() => DocumentImage, (set) => set.reTrains)
    @JoinColumn({ name: 'image_id' })
    images: DocumentImage;

    @Column({
        name: 'document_id',
    })
    documentId: number;

    @ManyToOne(() => Document, (set) => set.reTrains)
    @JoinColumn({ name: 'document_id' })
    documents: Document;

    @Column({
        name: 'doc_type',
    })
    docType: number;

    @Column({
        name: 'bbox',
        type: 'jsonb',
        nullable: true,
    })
    bbox?: object;

    @Column({
        name: 'word',
    })
    word: string;

    @Column({
        name: 'label',
    })
    label: string;

    @Column({
        name: 'gtrue_word',
    })
    gtrueWord: string;

    @Column({
        name: 'gtrue_box',
        type: 'jsonb',
        nullable: true,
    })
    gtrueBbox?: object;

    @Column({
        name: 'gtrue_label',
    })
    gtrueLabel: string;

    @Column({
        name: 'gtrue_doc_type',
    })
    gtrueDocType: number;
}
