import { Test, TestingModule } from '@nestjs/testing';
import { ReTrainsController } from './retrains.controller';

describe('ReTrainsController', () => {
  let controller: ReTrainsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ReTrainsController],
    }).compile();

    controller = module.get<ReTrainsController>(ReTrainsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
