import { Module } from '@nestjs/common';
import { ReTrainsService } from './retrains.service';
import { ReTrainsController } from './retrains.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Retrain } from './entity/retrain.entity';
import { Document } from 'src/documents/entity/document.entity';
import { AuditModule } from 'src/audit/audit.module';

@Module({
    imports: [TypeOrmModule.forFeature([Retrain, Document]), AuditModule],
    providers: [ReTrainsService],
    controllers: [ReTrainsController],
    exports: [ReTrainsService],
})
export class ReTrainsModule {}
