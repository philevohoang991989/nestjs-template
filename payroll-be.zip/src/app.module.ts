import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
    utilities as nestWinstonModuleUtilities,
    WinstonModule,
} from 'nest-winston';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import * as winston from 'winston';
import { LocationsModule } from './locations/locations.module';
import { MailModule } from './mail/mail.module';
import { RequestContextModule } from '@medibloc/nestjs-request-context';
import { AppRequestContext } from './shared/app-request-context';
import { AuditModule } from './audit/audit.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import kafkaOptionsConfig from './shared/config/kafka.options.config';
import { DocumentsModule } from './documents/documents.module';
import { DocumentSetModule } from './document-sets/document-set.module';
import { ExcelModule } from './excel/excel.module';
import { ReTrainsModule } from './retrains/retrains.module';
import { FtpsModule } from './ftps/ftps.module';
import filesystemConfig from './shared/config/filesystem.config';
import databaseConfig from './shared/config/psql.config';

@Module({
    imports: [
        ConfigModule.forRoot({
            isGlobal: true,
            load: [kafkaOptionsConfig, filesystemConfig, databaseConfig],
        }),
        EventEmitterModule.forRoot(),
        AuthModule,
        UsersModule,
        TypeOrmModule.forRoot({
            type: 'postgres',
            host: process.env.PSQL_HOST,
            port: +process.env.PSQL_PORT,
            username: process.env.PSQL_USER,
            password: process.env.PSQL_PASSWORD,
            database: process.env.PSQL_DATABASE,
            schema: process.env.PSQL_SCHEMA || 'public',
            entities: ['dist/**/*.entity{.ts,.js}'],
            subscribers: ['dist/**/*.subscriber{.ts,.js}'],
            migrationsTableName: 'migrations',
            migrations: ['dist/**/migration/*.js'],
            synchronize: false,
            logging: 'all',
            logger: 'debug',
            poolSize: 300,
            connectTimeoutMS: 20000,
        }),
        WinstonModule.forRoot({
            level: 'debug',
            transports: [
                new winston.transports.Console({
                    format: winston.format.combine(
                        winston.format.timestamp({
                            format: 'YYYY-MM-DD HH:mm:ss.SSS',
                        }),
                        winston.format.json(),
                        winston.format.ms(),
                        nestWinstonModuleUtilities.format.nestLike('BE-Payroll', {
                            colors: true,
                            prettyPrint: true,
                        }),
                    ),
                }),
                new winston.transports.File({
                    filename: 'app.log',
                    format: winston.format.combine(
                        winston.format.timestamp({
                            format: 'YYYY-MM-DD HH:mm:ss.SSS',
                        }),
                        winston.format.json(),
                        winston.format.prettyPrint(),
                    ),
                }),
            ],
        }),
        RequestContextModule.forRoot({
            contextClass: AppRequestContext,
            isGlobal: true,
        }),
        LocationsModule,
        MailModule,
        AuditModule,
        DocumentsModule,
        DocumentSetModule,
        ExcelModule,
        ReTrainsModule,
        FtpsModule,
    ],
    controllers: [AppController],
    providers: [AppService],
})
export class AppModule {}
