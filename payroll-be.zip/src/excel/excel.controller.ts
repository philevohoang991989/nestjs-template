import { Controller } from '@nestjs/common';

@Controller('excel')
export class ExcelController {}
