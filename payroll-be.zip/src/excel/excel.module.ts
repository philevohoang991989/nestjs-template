import { Module } from '@nestjs/common';
import { ExcelService } from './excel.service';
import { ExcelController } from './excel.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Excel } from './entity/excel.entity';
import { DocumentValidation } from 'src/documents/entity/documentValidation.entity';
import { DocumentSetValidation } from 'src/document-sets/entity/documentSetValidation.entity';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { DocumentToken } from 'src/documents/entity/documentToken.entity';
import { Document } from 'src/documents/entity/document.entity';
import { Audit } from 'src/audit/entity/audit.entity';

@Module({
    imports: [
        TypeOrmModule.forFeature([
            Excel,
            DocumentValidation,
            DocumentSetValidation,
            DocumentSet,
            DocumentToken,
            Document,
            Audit
        ]),
    ],
    providers: [ExcelService],
    exports: [ExcelService],
    controllers: [ExcelController],
})
export class ExcelModule {}
