import { BadRequestException, Inject, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Repository } from 'typeorm';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import {
    EnumColumnPositionsExternals,
    EnumColumnPositionsInternals,
    Excel,
    MAP_EIB_NAME,
    Templates,
    Unknown,
} from './entity/excel.entity';
import * as XLSX from 'xlsx';
import { IMPORT_COLUMN_RANGES, TIMECARD_COLUMN_RANGES } from 'src/shared/constants/common.constant';
import { EnumTypes } from 'src/documents/entity/documentType.entity';
import ExcelJS = require('exceljs');
import { DocumentValidation } from 'src/documents/entity/documentValidation.entity';
import { DocumentSetValidation } from 'src/document-sets/entity/documentSetValidation.entity';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import {
    DocumentToken,
    EnumCheckDocumentOcrs,
    EnumDocumentSetValidationDatas,
    EnumKeyOcrs,
} from 'src/documents/entity/documentToken.entity';
import { accentsTidy } from 'src/shared/helpers/accents-tidy';
import { Document } from 'src/documents/entity/document.entity';
import { FilterDocumentSetDTO } from 'src/document-sets/dto/filte-document-set.dto';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { EnumDocumentStatus } from 'src/documents/entity/documentStatus.entity';
import { EnumDocumentSetStatus, EnumDocumentSetStatusText } from 'src/document-sets/entity/documentSetStatus.entity';
import { Audit, AuditAction } from 'src/audit/entity/audit.entity';

@Injectable()
export class ExcelService {
    constructor(
        @InjectRepository(Excel)
        private excelRepository: Repository<Excel>,
        @InjectRepository(Document)
        private documentRepository: Repository<Document>,
        @InjectRepository(Audit)
        private auditRepository: Repository<Audit>,
        @InjectRepository(DocumentSetValidation)
        private documentSetValidationRepository: Repository<DocumentSetValidation>,
        @InjectRepository(DocumentSet)
        private documentSetRepository: Repository<DocumentSet>,
        @InjectRepository(DocumentToken)
        private documentTokenRepository: Repository<DocumentToken>,
        @InjectRepository(DocumentValidation)
        private documentValidationRepository: Repository<DocumentValidation>,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    ) {}

    async getMapDocuments(documentSetId: number): Promise<any> {
        const documents = await this.documentRepository
            .createQueryBuilder('documents')
            .andWhere('documents.documentSetId = :documentSetId', {
                documentSetId: documentSetId,
            })
            .andWhere('documents.documentTypeId = :documentTypeId', {
                documentTypeId: '1',
            })
            .orderBy('documents.id', 'ASC')
            .getMany();
        const mapDocument = {};
        for (let i = 0; i < documents.length; i++) {
            const element = documents[i];
            mapDocument[element.id] = i + 1;
        }

        return mapDocument;
    }

    async getDocumentValidations(documentSetId: number): Promise<any> {
        return await this.excelRepository
            .createQueryBuilder('excels')
            .leftJoinAndSelect('excels.documentValidation', 'documentValidation')
            .leftJoinAndSelect('documentValidation.documentToken', 'documentToken')
            .andWhere('excels.documentSetId = :documentSetId', {
                documentSetId,
            })
            .orderBy('excels.id', 'ASC')
            .getMany();
    }

    async getDocumentValidationFails(documentSetId: number): Promise<any> {
        return await this.documentValidationRepository
            .createQueryBuilder('documentValidation')
            .where('documentValidation.document_set_id = :documentSetId', {
                documentSetId,
            })
            .andWhere('documentValidation.is_validation = :isValidation', {
                isValidation: 0,
            })
            .getMany();
    }

    async getDocumentSetValidations(documentSetId: number): Promise<any> {
        return await this.documentSetValidationRepository
            .createQueryBuilder('document_set_validations')
            .andWhere('document_set_validations.documentSetId = :documentSetId', {
                documentSetId,
            })
            .orderBy('document_set_validations.id', 'ASC')
            .getMany();
    }

    async readPayrollExcel(file: Express.Multer.File, documentSetId: number, type: number) {
        const workbook = XLSX.read(file.buffer);
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const range = XLSX.utils.decode_range(sheet['!ref']);

        const batchSize = 1000; // Adjust the batch size as needed
        let startRow = range.s.r;
        let excelDatas = [];
        const columnsInternal = EnumColumnPositionsInternals;
        const columnsExternal = EnumColumnPositionsExternals;

        while (startRow <= range.e.r) {
            const endRow = Math.min(startRow + batchSize - 1, range.e.r);
            const currentRange = { s: { r: startRow, c: range.s.c }, e: { r: endRow, c: range.e.c } };

            let excelDatasChunk = XLSX.utils.sheet_to_json(sheet, {
                header: IMPORT_COLUMN_RANGES,
                range: currentRange,
                blankrows: false,
            });

            console.log('Excel Length ' + excelDatasChunk.length);

            if (excelDatasChunk.length > 0) {
                excelDatasChunk = excelDatasChunk.filter(
                    (row) =>
                        row[columnsInternal.AMOUNT] != '' ||
                        row[columnsInternal.ACC_NUM] != '' ||
                        row[columnsInternal.CCY] != '' ||
                        row[columnsInternal.NAME] != '' ||
                        row[columnsExternal.AC_NO] != '' ||
                        row[columnsExternal.AMOUNT] != '' ||
                        row[columnsExternal.CCY] != '' ||
                        row[columnsExternal.BEN_NAME] != '',
                );

                if (excelDatasChunk.length > 0) {
                    excelDatas.push(...excelDatasChunk);
                }
            } else {
                break;
            }

            startRow = endRow + 1;
        }

        let importOrcExcels = [];

        if (type == EnumTypes.INTERNAL) {
            importOrcExcels = await this.formatDataInternal(excelDatas, documentSetId);
        } else if (type == EnumTypes.EXTERNAL) {
            importOrcExcels = await this.formatDataExternal(excelDatas, documentSetId);
        }

        console.log('Excel for Import: ' + importOrcExcels.length);

        return importOrcExcels;
    }

    async formatDataInternal(excelDatas: any, documentSetId: number): Promise<any> {
        const dataInternal = [];
        const dataColumnDRCR = ['C', 'D', 'c', 'd'];

        for (let i = 0; i < excelDatas.length; i++) {
            const rowData = excelDatas[i];
            const columns = EnumColumnPositionsInternals;
            const dtDRCR = rowData[columns.DR_CR] ? (rowData[columns.DR_CR]+'').trim() : '';

            if (dataColumnDRCR.includes(dtDRCR)) {
                const data = {};
                data[EnumKeyOcrs.STT] = rowData[columns.STT] ?? '';
                data[EnumKeyOcrs.NAME] = rowData[columns.NAME] ? (rowData[columns.NAME] + '').trim() : '';
                data[EnumKeyOcrs.ACC_NUM] = rowData[columns.ACC_NUM] ? (rowData[columns.ACC_NUM] + '').trim() : '';
                data[EnumKeyOcrs.CCY] = rowData[columns.CCY] ?? '';
                data[EnumKeyOcrs.AMOUNT] = rowData[columns.AMOUNT] ? (rowData[columns.AMOUNT] + '').includes('.000000') || (rowData[columns.AMOUNT] + '').includes('.999999') ? Math.round(rowData[columns.AMOUNT]).toFixed(0): rowData[columns.AMOUNT] : '';
                //data[EnumKeyOcrs.AMOUNT] = rowData[columns.AMOUNT] ?? '';
                const excel = new Excel();
                excel.documentSetId = documentSetId;
                excel.data = data;
                dataInternal.push(excel);
            }
        }

        return dataInternal;
    }

    async formatDataExternal(excelDatas: any, documentSetId: number): Promise<any> {
        const dataExternal = [];

        for (let i = 0; i < excelDatas.length; i++) {
            const rowData = excelDatas[i];
            const columns = EnumColumnPositionsExternals;

            if (!isNaN(parseFloat(rowData[columns.AMOUNT]))) {
                const data = {};
                data[EnumKeyOcrs.NAME] = rowData[columns.BEN_NAME] ? (rowData[columns.BEN_NAME] + '').trim() : '';
                data[EnumKeyOcrs.ACC_NUM] = rowData[columns.AC_NO] ? (rowData[columns.AC_NO] + '').trim() : '';
                data[EnumKeyOcrs.CCY] = rowData[columns.CCY] ?? '';
                data[EnumKeyOcrs.AMOUNT] = rowData[columns.AMOUNT] ? ((rowData[columns.AMOUNT]+'').trim().includes(".000000") || (rowData[columns.AMOUNT]+'').trim().includes(".999999") ? Math.round(rowData[columns.AMOUNT]).toFixed(0) : rowData[columns.AMOUNT]) : '';
                //data[EnumKeyOcrs.AMOUNT] = rowData[columns.AMOUNT] ?? '';
                data[EnumKeyOcrs.BANK_NAME] = rowData[columns.BEN_BANK] ? (rowData[columns.BEN_BANK] + '').trim() : '';

                const excel = new Excel();
                excel.documentSetId = documentSetId;
                excel.data = data;
                dataExternal.push(excel);
            }
        }

        return dataExternal;
    }

    async paginationSet(filters: FilterDocumentSetDTO, query?: FindQueryDto): Promise<any> {
        const qb = this.documentSetRepository
            .createQueryBuilder('document_sets')
            .leftJoinAndSelect('document_sets.authorUpdated', 'authorUpdated')
            .leftJoinAndSelect('document_sets.authorCreated', 'authorCreated')
            .leftJoinAndSelect('document_sets.documents', 'documents')
            .leftJoinAndSelect('document_sets.documentSetValidation', 'documentSetValidation');
        if (filters.keyword) {
            qb.andWhere(
                new Brackets((sqb) => {
                    sqb.where('authorCreated.name ILIKE :keyword', {
                        keyword: `%${filters.keyword}%`,
                    })
                        .orWhere('authorUpdated.name ILIKE :keyword')
                        .orWhere('document_sets.name ILIKE :keyword')
                        .orWhere('document_sets.id::varchar(20) ILIKE :keyword');
                }),
            );
        }

        if (query.from) {
            const startOfDay = new Date(query.from);
            startOfDay.setHours(0, 0, 0, 0);

            qb.andWhere('document_sets.createdAt >= :from', {
                from: startOfDay,
            });
        }

        if (query.to) {
            const endOfDay = new Date(query.to);
            endOfDay.setHours(23, 59, 59, 999);
            qb.andWhere('document_sets.createdAt <= :to', { to: endOfDay });
        }

        if (filters.type) {
            qb.andWhere('document_sets.type = :type', {
                type: filters.type,
            });
        }

        if (query.status) {
            if (query.status == EnumDocumentStatus.EDIT) {
                qb.andWhere('document_sets.document_set_status_id = :status', {
                    status: EnumDocumentStatus.CLASSIFIED,
                }).andWhere('documents.reTrain = :reTrain', {
                    reTrain: true,
                });
            } else {
                qb.andWhere('document_sets.document_set_status_id = :status', {
                    status: query.status,
                });
            }
        } else {
            qb.andWhere('document_sets.documentSetStatusId >= :statusId', {
                statusId: 3,
            });
        }

        if (query.sort) {
            qb.orderBy(getOrderByClause(query.sort));
        } else {
            qb.orderBy('document_sets.id', 'DESC');
        }
        // qb.withDeleted();

        const results = await qb.getManyAndCount();

        for (const iterator of results[0]) {
            if (iterator.documentSetStatusId == 3) {
                const mapReTrain = iterator.documents.map((x) => x.reTrain);
                if (mapReTrain.includes(true)) {
                    iterator.documentSetStatusId = EnumDocumentStatus.EDIT;
                }
            }
        }

        return new Pagination(results);
    }

    async exportSetExcel(filters: FilterDocumentSetDTO, query: FindQueryDto, response: any): Promise<any> {
        const workbook = new ExcelJS.Workbook();

        const documentSets = await this.paginationSet(filters, query);

        let worksheet = await this.readTemplateExcel(workbook, Templates.REPORT);

        worksheet = await this.setDataWorkSheetReport(worksheet, documentSets);

        return await workbook.xlsx.write(response);
    }

    async exportExcel(documentSetId: number, response: any): Promise<any> {
        const workbook = new ExcelJS.Workbook();
        let worksheet: any = null;

        const documentSet = await this.documentSetRepository.findOne({
            where: { id: documentSetId },
        });

        if (!documentSet) {
            throw new BadRequestException('Document set does not exist');
        }

        const documentSetValidations = await this.getDocumentSetValidations(documentSetId);

        if (documentSet.type == EnumTypes.INTERNAL) {
            worksheet = await this.readTemplateExcel(workbook, Templates.INTERNAL);
        } else {
            worksheet = await this.readTemplateExcel(workbook, Templates.EXTERNAL);
        }
        worksheet = await this.setDataWorksheet(worksheet, documentSetValidations);

        if (documentSetValidations.length != 0) {
            worksheet = await this.setDataexportCheckDocument(worksheet, documentSetValidations);
        }

        return await workbook.xlsx.write(response);
    }

    async setDataWorkSheetReport(worksheet: any, documentSets: any): Promise<any> {
        const comparePayrolls = documentSets.items;

        const documentSetIds = comparePayrolls.map((x) => x.id);

        const audits = await this.findAudit(documentSetIds);

        for (const i in comparePayrolls) {
            const documentSet = comparePayrolls[i];
            const classified = audits.find((classified) => classified.entityId == documentSet.id);

            let timeOcr = 0;

            if (classified.length != 0) {
                timeOcr = classified.createdAt;
            }

            worksheet.worksheet.getRow(2 + parseInt(i)).values = [
                documentSet.name,
                documentSet.extendedData ? documentSet.extendedData.fileExcel ? documentSet.extendedData.fileExcel : '' : '',
                documentSet.type == 2 ? 'Ngoài hệ thống' : 'Trong hệ thống',
                documentSet.createdAt,
                this.formatTime(documentSet.createdAt),
                this.formatTime(timeOcr),
                this.ocrHours(documentSet.createdAt, timeOcr),
                this.report(documentSet.documentSetValidation[0].report),
                documentSet.documentSetValidation[0].data.num_row['chi-luong'],
                documentSet.documents.length,
                documentSet.authorCreated.name,
                this.formatStatus(documentSet.documentSetStatusId),
            ];
        }

        worksheet.worksheet.eachRow({ includeEmpty: true }, function (row) {
            row.eachCell({ includeEmpty: true }, function (cell) {
                cell.border = {
                    top: { style: 'thin' },
                    left: { style: 'thin' },
                    bottom: { style: 'thin' },
                    right: { style: 'thin' },
                };
            });
        });

        return worksheet;
    }

    async findAudit(ids: number[]): Promise<any> {
        return await this.auditRepository
            .createQueryBuilder('audits')
            .where('audits.entityId IN (:...ids)', { ids: ids })
            .andWhere('audits.action =:action', {
                action: AuditAction.CLASSIFIED,
            })
            .getMany();
    }

    formatStatus(data) {
        if (data == EnumDocumentSetStatus.OPEN) {
            return EnumDocumentSetStatusText.OPEN;
        }
        if (data == EnumDocumentSetStatus.DELETED) {
            return EnumDocumentSetStatusText.DELETED;
        }
        if (data == EnumDocumentSetStatus.REQUESTED_CLASSIFY) {
            return EnumDocumentSetStatusText.REQUESTED_CLASSIFY;
        }
        if (data == EnumDocumentSetStatus.CANCEL) {
            return EnumDocumentSetStatusText.CANCEL;
        }
        return EnumDocumentSetStatusText.CLASSIFIED;
    }

    report(data) {
        const total = data.total ? data.total : 0;
        const totalFail = data.totalFail ? data.totalFail : 0;
        if (total == 0) {
            return '00,00';
        }
        const totalPass = data.total - totalFail;

        if (totalPass < 0) {
            return '00,00';
        }
        return ((totalPass / total) * 100).toFixed(2);
    }

    ocrHours(momentStart, momentend) {
        if (momentend == 0) {
            return '00:00:00';
        }
        const startTime = new Date(momentStart).getTime();
        const endTime = new Date(momentend).getTime();

        const timeDifferenceInMilliseconds = Math.abs(endTime - startTime);
        const timeDifferenceInSeconds = Math.floor(timeDifferenceInMilliseconds / 1000);

        const hours = Math.floor(timeDifferenceInSeconds / 3600);
        const remainingSeconds = timeDifferenceInSeconds % 3600;
        const minutes = Math.floor(remainingSeconds / 60);
        const seconds = remainingSeconds % 60;

        return this.formatTime(new Date(0, 0, 0, hours, minutes, seconds));
    }

    formatTime(date) {
        if (date == 0) {
            return '00:00:00';
        }
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');

        return `${hours}:${minutes}:${seconds}`;
    }

    async setDataWorksheet(worksheet: any, documentSetValidations: any): Promise<any> {
        const comparePayrolls = documentSetValidations[0].comparePayroll;
        const coordinatesFales = documentSetValidations[0].coordinates.coordinatesFale;
        const coordinatesTrues = documentSetValidations[0].coordinates.coordinatesTrue;

        for (const i in comparePayrolls) {
            worksheet.worksheet.getRow(3 + parseInt(i)).values = comparePayrolls[i];
        }

        for (const coordinatesFale of coordinatesFales) {
            this.setColorFalse(worksheet, coordinatesFale.column, coordinatesFale.row);
        }
        for (const coordinatesTrue of coordinatesTrues) {
            this.setColorTrue(worksheet, coordinatesTrue.column, coordinatesTrue.row);
        }

        worksheet.worksheet.eachRow({ includeEmpty: true }, function (row) {
            row.eachCell({ includeEmpty: true }, function (cell) {
                cell.border = {
                    top: { style: 'thin' },
                    left: { style: 'thin' },
                    bottom: { style: 'thin' },
                    right: { style: 'thin' },
                };
            });
        });

        return worksheet;
    }

    async dataOcrExcel(documentSetId, columnOcrs, columnsExcels, mapDocument) {
        let valusTokens = [];

        const tokens = await this.documentTokenRepository
            .createQueryBuilder('document_tokens')
            .leftJoinAndSelect('document_tokens.document', 'document')
            .andWhere('document.documentSetId = :documentSetId', {
                documentSetId,
            })
            .andWhere('document.documentTypeId = :documentTypeId', {
                documentTypeId: '1',
            })
            .orderBy('document.id', 'ASC')
            .getMany();

        for (const iterator of tokens) {
            const item = [];
            // export ocr
            for (let i2 in columnOcrs) {
                if (i2 == '0') {
                    const documentId = iterator.documentId;
                    if (documentId !== undefined) {
                        item.push(documentId ? mapDocument[documentId].toString() : '');
                    }
                } else {
                    const value = iterator?.data[columnOcrs[i2]];
                    if (value !== undefined) {
                        item.push(value ? value.toString() : value);
                    }
                }
            }
            item.push('FALSE');
            for (let i2 in columnsExcels) {
                item.push('');
            }
            valusTokens.push(item);
        }

        return valusTokens;
    }

    async setDataexportCheckDocument(worksheet: any, documentSetValidations: any): Promise<any> {
        const dataExports = await this.exportCheckDocument(documentSetValidations);

        const rows = EnumDocumentSetValidationDatas;

        this.setDataRport(worksheet, 2, dataExports[rows.DR_ACCOUNT]);
        this.setDataRport(worksheet, 3, dataExports[rows.CR_ACCOUNT]);
        this.setDataRport(worksheet, 4, dataExports[rows.AMOUNT]);
        this.setDataRport(worksheet, 5, dataExports[rows.FILE_NAME]);
        this.setDataRport(worksheet, 6, dataExports[rows.NUM_ROW]);
        this.setDataRport(worksheet, 7, dataExports[rows.NUM_PAGE]);

        worksheet.worksheet2.eachRow({ includeEmpty: true }, function (row) {
            row.eachCell({ includeEmpty: true }, function (cell) {
                cell.border = {
                    top: { style: 'thin' },
                    left: { style: 'thin' },
                    bottom: { style: 'thin' },
                    right: { style: 'thin' },
                };
            });
        });

        return worksheet;
    }

    async checkBankname(name) {
        for (let i = 0; i < MAP_EIB_NAME.length; i++) {
            const element = MAP_EIB_NAME[i];

            if (name.includes(element)) {
                return true;
            }
        }
        return false;
    }

    async readTemplateExcel(workbook, type) {
        return await workbook.xlsx.readFile(type).then(() => {
            const worksheet = workbook.worksheets[0];
            worksheet.views = [{ showGridLines: false }];
            const worksheet2 = workbook.worksheets[1];

            return { worksheet, worksheet2 };
        });
    }

    setDataRport(worksheet: any, row: number, datas: string) {
        for (let i = 0; i < datas.length; i++) {
            this.setValueRport(worksheet, i + 2, row, datas[i]);
        }
        return worksheet;
    }

    setValueRport(worksheet: any, column: number, row: number, data: string) {
        worksheet.worksheet2.getCell(`${TIMECARD_COLUMN_RANGES[column]}${row}`).value = data;
        return worksheet;
    }

    setColorFalse(worksheet: any, column: number, row: number) {
        worksheet.worksheet.getCell(`${TIMECARD_COLUMN_RANGES[column]}${row}`).fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFF0000' },
        };
        return worksheet;
    }

    setColorTrue(worksheet: any, column: number, row: number) {
        worksheet.worksheet.getCell(`${TIMECARD_COLUMN_RANGES[column]}${row}`).fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFffe699' },
        };
        return worksheet;
    }

    async exportPayrolls(documentValidations, columnOcrs, columnsExcels, mapDocument) {
        const acFails = [];
        const arrExcels = [];
        const dataValidations = [];

        for (let i in documentValidations) {
            const item = [];
            const coordinates = [];
            const coordinatesTrue = [];
            const validations = documentValidations[i].documentValidation[0];
            if (validations) {
                dataValidations.push(validations);
                for (const iterator of validations.keyErrors) {
                    if (iterator == EnumKeyOcrs.ACC_NUM) {
                        acFails.push(iterator);
                    }
                }
            }

            // export ocr
            for (let i2 in columnOcrs) {
                if (validations && validations.data.ocrData) {
                    if (i2 == '0') {
                        const documentId = validations.documentToken.documentId;

                        if (documentId !== undefined && mapDocument[documentId] !== undefined) {
                            item.push(documentId ? mapDocument[documentId].toString() : '');
                        }
                    } else {
                        const value = validations.data.ocrData[columnOcrs[i2]];
                        if (value !== undefined) {
                            item.push(value ? value.toString() : value);
                        }
                    }
                } else {
                    item.push(null);
                }

                if (validations && validations.keyErrors.includes(columnOcrs[i2])) {
                    coordinates.push({
                        colum: parseInt(i2) + 1,
                        row: parseInt(i) + 3,
                    });
                }
            }
            // export result
            if (validations && validations.isValidation) {
                item.push('TRUE');
            } else {
                item.push('FALSE');
            }

            if (!validations || (validations && !validations.isValidation)) {
                coordinates.push({
                    colum: columnOcrs.length + 1,
                    row: parseInt(i) + 3,
                });
            } else {
                coordinatesTrue.push({
                    colum: columnOcrs.length + 1,
                    row: parseInt(i) + 3,
                });
            }

            // export excel
            for (let i2 in columnsExcels) {
                const column = columnsExcels[i2];
                if (column !== undefined) {
                    item.push(
                        documentValidations[i].data[column]
                            ? documentValidations[i].data[column].toString()
                            : documentValidations[i].data[column],
                    );

                    if (validations && validations.keyErrors.includes(column)) {
                        coordinates.push({
                            colum: columnOcrs.length + parseInt(i2) + 2,
                            row: parseInt(i) + 3,
                        });
                    }
                }
            }
            arrExcels.push({ item, coordinates, coordinatesTrue });
        }

        return { arrExcels, dataValidations, acFails };
    }

    async exportCheckDocument(documentValidations) {
        const dataRow = documentValidations[0].data;
        const rows = EnumDocumentSetValidationDatas;

        if (dataRow[rows.DR_ACCOUNT]) {
            dataRow[rows.DR_ACCOUNT] = await this.setDataCheckDocument(dataRow[rows.DR_ACCOUNT], rows.DR_ACCOUNT);
        } else {
            dataRow[rows.DR_ACCOUNT] = [];
        }

        if (dataRow[rows.CR_ACCOUNT]) {
            dataRow[rows.CR_ACCOUNT] = await this.setDataCheckDocument(dataRow[rows.CR_ACCOUNT], rows.CR_ACCOUNT);
        } else {
            dataRow[rows.CR_ACCOUNT] = [];
        }

        if (dataRow[rows.AMOUNT]) {
            dataRow[rows.AMOUNT] = await this.setDataCheckDocument(dataRow[rows.AMOUNT], rows.AMOUNT);
        } else {
            dataRow[rows.AMOUNT] = [];
        }

        if (dataRow[rows.FILE_NAME]) {
            dataRow[rows.FILE_NAME] = await this.setDataCheckDocument(dataRow[rows.FILE_NAME], rows.FILE_NAME);
        } else {
            dataRow[rows.FILE_NAME] = [];
        }

        if (dataRow[rows.NUM_ROW]) {
            dataRow[rows.NUM_ROW] = await this.setDataCheckDocument(dataRow[rows.NUM_ROW], rows.NUM_ROW);
        } else {
            dataRow[rows.NUM_ROW] = [];
        }

        if (dataRow[rows.NUM_PAGE]) {
            dataRow[rows.NUM_PAGE] = await this.setDataCheckDocument(dataRow[rows.NUM_PAGE], rows.NUM_PAGE);
        } else {
            dataRow[rows.NUM_PAGE] = [];
        }

        return dataRow;
    }

    async setDataCheckDocument(property, rowData) {
        const ocrs = EnumCheckDocumentOcrs;
        const rows = EnumDocumentSetValidationDatas;
        const columnCheckDocuments = [
            ocrs.CHI_LUONG,
            ocrs.PHIEU_HACH_TOAN,
            ocrs.PHIEU_DE_NGHI,
            ocrs.UY_NHIEM_CHI,
            ocrs.RESULT,
        ];
        let result = 'TRUE';

        if (rowData == rows.AMOUNT) {
            const dataRows = await this.checkAmount(property, result);
            property = dataRows.property;
            result = dataRows.result;
        }

        if (rowData == rows.DR_ACCOUNT) {
            const dataRows = await this.checkDrAccount(property, result);
            property = dataRows.property;
            result = dataRows.result;
        }

        if (rowData == rows.CR_ACCOUNT) {
            const dataRows = await this.checkCrAccount(property, result);
            property = dataRows.property;
            result = dataRows.result;
        }

        if (rowData == rows.FILE_NAME) {
            const dataRows = await this.checkFileName(property, result);
            property = dataRows.property;
            result = dataRows.result;
        }

        if (rowData == rows.NUM_PAGE || rowData == rows.NUM_ROW) {
            const dataRows = await this.checkBallotProposals(property, result);
            property = dataRows.property;
            result = dataRows.result;
        }

        if (result == 'TRUE') {
            result = await this.checkResult(columnCheckDocuments, property);
        }

        const item = this.setItem(columnCheckDocuments, property, result);

        return item;
    }

    async setItem(columns, property, result) {
        const item = [];

        for (let i2 in columns) {
            if (columns[i2] == EnumCheckDocumentOcrs.RESULT) {
                item.push(result);
            } else {
                const value = property[columns[i2]];
                if (value && value instanceof Array && value.length > 1) {
                    let data = '';
                    for (const iterator of value) {
                        data = data + iterator.toString() + '\r\n';
                    }

                    item.push(data);
                } else if (value) {
                    item.push(value.toString());
                } else {
                    item.push(value);
                }
            }
        }

        return item;
    }

    async checkAmount(property, result) {
        const ocrs = EnumCheckDocumentOcrs;
        let salaries = property[ocrs.CHI_LUONG];
        let accountingSlip = property[ocrs.PHIEU_HACH_TOAN];
        let ballotProposals = property[ocrs.PHIEU_DE_NGHI];
        let accreditative = property[ocrs.UY_NHIEM_CHI];

        if (!salaries || (salaries instanceof Array && (salaries.length == 0 || salaries[0] == ''))) {
            result = 'FALSE';
            property[ocrs.CHI_LUONG] = [];
            property[ocrs.CHI_LUONG].push(Unknown);
        } else if (salaries instanceof Array && salaries.length > 1) {
            result = 'FALSE';
        }

        if (
            !accountingSlip ||
            (accountingSlip instanceof Array && (accountingSlip.length == 0 || accountingSlip[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_HACH_TOAN] = [];
            property[ocrs.PHIEU_HACH_TOAN].push(Unknown);
        } else if (accountingSlip instanceof Array && accountingSlip.length > 1) {
            result = 'FALSE';
        }

        if (
            !ballotProposals ||
            (ballotProposals instanceof Array && (ballotProposals.length == 0 || ballotProposals[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_DE_NGHI] = [];
            property[ocrs.PHIEU_DE_NGHI].push(Unknown);
        } else if (ballotProposals instanceof Array && ballotProposals.length > 1) {
            result = 'FALSE';
        }

        if (
            !accreditative ||
            (accreditative instanceof Array && (accreditative.length == 0 || accreditative[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.UY_NHIEM_CHI] = [];
            property[ocrs.UY_NHIEM_CHI].push(Unknown);
        } else if (accreditative instanceof Array && accreditative.length > 1) {
            result = 'FALSE';
        }

        return { property, result };
    }

    async checkFileName(property, result) {
        const ocrs = EnumCheckDocumentOcrs;
        let ballotProposals = property[ocrs.PHIEU_DE_NGHI];
        let accreditative = property[ocrs.UY_NHIEM_CHI];

        if (
            !ballotProposals ||
            (ballotProposals instanceof Array && (ballotProposals.length == 0 || ballotProposals[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_DE_NGHI] = [];
            property[ocrs.PHIEU_DE_NGHI].push(Unknown);
        } else if (ballotProposals instanceof Array && ballotProposals.length > 1) {
            result = 'FALSE';
        }

        if (
            !accreditative ||
            (accreditative instanceof Array && (accreditative.length == 0 || accreditative[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.UY_NHIEM_CHI] = [];
            property[ocrs.UY_NHIEM_CHI].push(Unknown);
        } else if (accreditative instanceof Array && accreditative.length > 1) {
            result = 'FALSE';
        }

        return { property, result };
    }

    async checkBallotProposals(property, result) {
        const ocrs = EnumCheckDocumentOcrs;
        let ballotProposals = property[ocrs.PHIEU_DE_NGHI];

        if (
            !ballotProposals ||
            (ballotProposals instanceof Array && (ballotProposals.length == 0 || ballotProposals[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_DE_NGHI] = [];
            property[ocrs.PHIEU_DE_NGHI].push(Unknown);
        } else if (ballotProposals instanceof Array && ballotProposals.length > 1) {
            result = 'FALSE';
        }

        return { property, result };
    }

    async checkCrAccount(property, result) {
        const ocrs = EnumCheckDocumentOcrs;

        let accountingSlip = property[ocrs.PHIEU_HACH_TOAN];
        let ballotProposals = property[ocrs.PHIEU_DE_NGHI];
        if (
            !accountingSlip ||
            (accountingSlip instanceof Array && (accountingSlip.length == 0 || accountingSlip[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_HACH_TOAN] = [];
            property[ocrs.PHIEU_HACH_TOAN].push(Unknown);
        } else if (accountingSlip instanceof Array && accountingSlip.length > 1) {
            result = 'FALSE';
        }

        if (
            !ballotProposals ||
            (ballotProposals instanceof Array && (ballotProposals.length == 0 || ballotProposals[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_DE_NGHI] = [];
            property[ocrs.PHIEU_DE_NGHI].push(Unknown);
        } else if (ballotProposals instanceof Array && ballotProposals.length > 1) {
            result = 'FALSE';
        }

        return { property, result };
    }

    async checkDrAccount(property, result) {
        const ocrs = EnumCheckDocumentOcrs;

        let accountingSlip = property[ocrs.PHIEU_HACH_TOAN];
        let ballotProposals = property[ocrs.PHIEU_DE_NGHI];
        let accreditative = property[ocrs.UY_NHIEM_CHI];
        if (
            !accountingSlip ||
            (accountingSlip instanceof Array && (accountingSlip.length == 0 || accountingSlip[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_HACH_TOAN] = [];
            property[ocrs.PHIEU_HACH_TOAN].push(Unknown);
        } else if (accountingSlip instanceof Array && accountingSlip.length > 1) {
            result = 'FALSE';
        }

        if (
            !ballotProposals ||
            (ballotProposals instanceof Array && (ballotProposals.length == 0 || ballotProposals[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.PHIEU_DE_NGHI] = [];
            property[ocrs.PHIEU_DE_NGHI].push(Unknown);
        } else if (ballotProposals instanceof Array && ballotProposals.length > 1) {
            result = 'FALSE';
        }

        if (
            !accreditative ||
            (accreditative instanceof Array && (accreditative.length == 0 || accreditative[0] == ''))
        ) {
            result = 'FALSE';
            property[ocrs.UY_NHIEM_CHI] = [];
            property[ocrs.UY_NHIEM_CHI].push(Unknown);
        } else if (accreditative instanceof Array && accreditative.length > 1) {
            result = 'FALSE';
        }

        return { property, result };
    }

    async checkResult(columns: any, property: any) {
        let result = 'TRUE';
        let dataCheck = [];

        for (let i2 in columns) {
            const value = property[columns[i2]];

            if (value && value != '') {
                dataCheck = dataCheck.concat(value);
            }
        }

        for (let i = 0; i < dataCheck.length; i++) {
            if (dataCheck[i] != '' && accentsTidy(dataCheck[0].toString()) != accentsTidy(dataCheck[i].toString())) {
                result = 'FALSE';
            }
        }

        return result;
    }

    async setDataWorksheetComparePayroll(
        documentValidations: any,
        columnOcrs: any,
        columnsExcels: any,
        documentSetId: number,
        documentValidationFails: any,
        mapDocument: any,
        documentSet: any,
    ): Promise<any> {
        const documentSetValidations = await this.getDocumentSetValidations(documentSetId);
        const comparePayroll = [];
        const coordinates = { coordinatesFale: [], coordinatesTrue: [] };
        const dataExports = await this.exportPayrolls(documentValidations, columnOcrs, columnsExcels, mapDocument);

        let valusTokens = await this.dataOcrExcel(documentSetId, columnOcrs, columnsExcels, mapDocument);

        let tokensOthers = [];

        if (
            dataExports.dataValidations.length == 0 ||
            (dataExports.dataValidations.length == documentValidationFails.length && dataExports.acFails.length != 0)
        ) {
            for (const key in dataExports.arrExcels) {
                for (const i in dataExports.arrExcels[key].item) {
                    for (const key in valusTokens) {
                        const element = valusTokens[key];
                        if (element[i] && dataExports.arrExcels[key]) {
                            dataExports.arrExcels[key].item[i] = element[i];
                        }
                    }
                }
            }
        }

        const valusExports = dataExports.arrExcels.map((x) => x.item);
        for (let key = 0; key < valusTokens.length; key++) {
            let checkRow = valusExports.find(
                (element) =>
                    valusTokens[key][3] &&
                    element[3] &&
                    accentsTidy(valusTokens[key][3].toString()) == accentsTidy(element[3].toString()),
            );

            if (!checkRow) {
                checkRow = valusExports.find(
                    (element) =>
                        valusTokens[key][2] &&
                        element[2] &&
                        accentsTidy(valusTokens[key][2].toString()) == accentsTidy(element[2].toString()),
                );
            }

            if (!checkRow) {
                if (
                    documentSet.type == EnumTypes.INTERNAL &&
                    (await this.checkBankname(accentsTidy(valusTokens[key][6])))
                ) {
                    tokensOthers.push(valusTokens[key]);
                } else {
                    if (
                        documentSet.type == EnumTypes.EXTERNAL &&
                        !(await this.checkBankname(accentsTidy(valusTokens[key][6])))
                    ) {
                        tokensOthers.push(valusTokens[key]);
                    }
                }
                // tokensOthers.push(valusTokens[key]);
            }
        }

        for (const i in dataExports.arrExcels) {
            const item = dataExports.arrExcels[i].item;
            const bankOcr = item[columnOcrs.length - 1];
            const bankExcel = item[item.length - 1];
            if (bankOcr && bankExcel && bankOcr != null && bankExcel != null) {
                if (
                    documentSet.type == EnumTypes.EXTERNAL &&
                    (MAP_EIB_NAME.includes(accentsTidy(bankOcr)) ||
                        accentsTidy(bankOcr) == '' ||
                        (await this.checkBankname(accentsTidy(bankOcr)))) &&
                    (MAP_EIB_NAME.includes(accentsTidy(bankExcel)) ||
                        accentsTidy(bankExcel) == '' ||
                        (await this.checkBankname(accentsTidy(bankExcel))))
                ) {
                    for (const key in columnOcrs) {
                        item[key] = '';
                    }
                }
            }

            comparePayroll.push(item);

            for (const iterator of dataExports.arrExcels[i].coordinates) {
                if (bankOcr && bankExcel && bankOcr != null && bankExcel != null) {
                    if (
                        documentSet.type == EnumTypes.EXTERNAL &&
                        (MAP_EIB_NAME.includes(accentsTidy(bankOcr)) ||
                            (await this.checkBankname(accentsTidy(bankOcr)))) &&
                        (MAP_EIB_NAME.includes(accentsTidy(bankExcel)) ||
                            (await this.checkBankname(accentsTidy(bankExcel)))) &&
                        iterator.colum != columnOcrs.length + 1
                    ) {
                    } else {
                        coordinates.coordinatesFale.push({
                            column: iterator.colum,
                            row: iterator.row,
                        });
                    }
                } else {
                    coordinates.coordinatesFale.push({
                        column: iterator.colum,
                        row: iterator.row,
                    });
                }
            }

            for (const iterator of dataExports.arrExcels[i].coordinatesTrue) {
                coordinates.coordinatesTrue.push({
                    column: iterator.colum,
                    row: iterator.row,
                });
            }
        }

        for (let index = 0; index < tokensOthers.length; index++) {
            const item = tokensOthers[index];
            const bankOcr = item[columnOcrs.length - 1];
            if (
                bankOcr &&
                documentSet.type == EnumTypes.EXTERNAL &&
                (MAP_EIB_NAME.includes(accentsTidy(bankOcr)) ||
                    (bankOcr && accentsTidy(bankOcr) == '') ||
                    (await this.checkBankname(accentsTidy(bankOcr))))
            ) {
            } else {
                const rowIndex = 3 + index;
                comparePayroll.push(tokensOthers[index]);
                coordinates.coordinatesFale.push({
                    column: columnOcrs.length + 1,
                    row: dataExports.arrExcels.length + rowIndex - 1,
                });
            }
        }
        if (documentSetValidations && documentSetValidations[0]) {
            documentSetValidations[0].comparePayroll = comparePayroll;
            documentSetValidations[0].coordinates = coordinates;
            return await this.documentSetValidationRepository.save(documentSetValidations);
        }
    }

    async exportExcelComparePayroll(documentSetId: number): Promise<any> {
        this.logger.log('Start process exportExcelComparePayroll', 'PROFILING');
        let columnOcrs: string[], columnsExcels: string[];

        const documentSet = await this.documentSetRepository.findOne({
            where: { id: documentSetId },
        });

        if (!documentSet) {
            throw new BadRequestException('Document set does not exist');
        }
        const mapDocument = await this.getMapDocuments(documentSetId);

        const documentValidations = await this.getDocumentValidations(documentSetId);

        const documentValidationFails = await this.getDocumentValidationFails(documentSetId);

        if (documentSet.type == EnumTypes.INTERNAL) {
            columnOcrs = [
                EnumKeyOcrs.PAGE_NO,
                EnumKeyOcrs.STT,
                EnumKeyOcrs.NAME,
                EnumKeyOcrs.ACC_NUM,
                EnumKeyOcrs.CCY,
                EnumKeyOcrs.AMOUNT,
            ];
            columnsExcels = [
                EnumKeyOcrs.STT,
                EnumKeyOcrs.NAME,
                EnumKeyOcrs.ACC_NUM,
                EnumKeyOcrs.CCY,
                EnumKeyOcrs.AMOUNT,
            ];
        } else {
            columnOcrs = [
                EnumKeyOcrs.PAGE_NO,
                EnumKeyOcrs.STT,
                EnumKeyOcrs.NAME,
                EnumKeyOcrs.ACC_NUM,
                EnumKeyOcrs.CCY,
                EnumKeyOcrs.AMOUNT,
                EnumKeyOcrs.BANK_NAME,
            ];
            columnsExcels = [
                EnumKeyOcrs.NAME,
                EnumKeyOcrs.ACC_NUM,
                EnumKeyOcrs.CCY,
                EnumKeyOcrs.AMOUNT,
                EnumKeyOcrs.BANK_NAME,
            ];
        }
        await this.setDataWorksheetComparePayroll(
            documentValidations,
            columnOcrs,
            columnsExcels,
            documentSetId,
            documentValidationFails,
            mapDocument,
            documentSet,
        );
        this.logger.log('End process exportExcelComparePayroll', 'PROFILING');
    }
}
