import { Inject, Injectable } from '@nestjs/common';
import { createReadStream } from 'fs';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import * as ftp from 'ftp';
import { DocumentsService } from 'src/documents/documents.service';
const stream = require('stream');

@Injectable()
export class FtpsService {
    constructor(
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
        private documentService: DocumentsService,
    ) { }

    async uploadFrom(filename): Promise<any> {
        const localFilePath = 'src/upload-ftps/' + filename;
        // const remoteFilePath = '/files/' + filename;
        const remoteFilePath = filename;

        const ftpConfig = {
            host: `${process.env.FTP_HOST}`,
            user: `${process.env.FTP_USER}`,
            password: `${process.env.FTP_PASSWORD}`,
            port: `${process.env.FTP_PORT}`,
        };

        const client = await new ftp();

        client.on('ready', () => {
            console.log('Connected to FTP server');

            // Tải lên file từ máy tính cục bộ lên máy chủ FTP
            const readStream = createReadStream(localFilePath);
            client.put(readStream, remoteFilePath, (error) => {
                if (error) {
                    console.error('Error uploading file:', error);
                } else {
                    console.log('File uploaded successfully');
                }
                client.end(); // Đóng kết nối sau khi hoàn thành tác vụ
            });
        });

        client.on('error', (error) => {
            console.error('FTP error:', error);
        });

        client.connect(ftpConfig);
    }

    async downloadImage(filename: string): Promise<ftp.DataSocket> {
        return await new Promise((resolve, reject) => {
            const client = new ftp();

            client.connect({
                host: `${process.env.FTP_HOST}`,
                user: `${process.env.FTP_USER}`,
                password: `${process.env.FTP_PASSWORD}`,
                port: `${process.env.FTP_PORT}`,
            });

            client.on('ready', () => {
                client.get(filename, (error, stream) => {
                    if (error) {
                        client.end();
                        reject(error);
                    } else {
                        resolve(stream);
                    }

                    stream.on('close', () => {
                        client.end();
                    });
                });
                // client.end();
            });
        });
    }

    async downloadResult(filename: string): Promise<ftp.DataSocket> {
        return await new Promise((resolve, reject) => {
            const client = new ftp();

            client.connect({
                host: `${process.env.FTP_HOST}`,
                user: `${process.env.FTP_USER}`,
                password: `${process.env.FTP_PASSWORD}`,
                port: `${process.env.FTP_PORT}`,
            });

            let data = '';

            client.on('ready', () => {
                client.get(filename, (error, stream) => {
                    if (error) {
                        reject(error);
                        return;
                    }

                    stream.on('close', () => {
                        client.end();
                    });

                    stream.on('data', (chunk) => {
                        data += chunk;
                    });

                    stream.on('end', () => {
                        try {
                            const jsonData = JSON.parse(data);
                            resolve(jsonData);
                        } catch (parseError) {
                            reject(parseError);
                        }
                    });

                    stream.on('error', (err) => {
                        reject(err);
                    });
                });
                // client.end();
            });
        });
    }

    async createFolder(folderName): Promise<any> {
        const ftpConfig = {
            host: `${process.env.FTP_HOST}`,
            user: `${process.env.FTP_USER}`,
            password: `${process.env.FTP_PASSWORD}`,
            port: `${process.env.FTP_PORT}`,
        };

        const client = await new ftp();

        client.on('ready', () => {
            console.log('Connected to FTP server created : ' + folderName);

            // Tạo thư mục mới trên máy chủ FTP
            client.mkdir(folderName, true, (error) => {
                if (error) {
                    console.error('Error creating directory:' + folderName, error);
                } else {
                    console.log('Directory created successfully');
                }
                client.end(); // Đóng kết nối sau khi hoàn thành tác vụ
            });
        });

        client.on('error', (error) => {
            console.error('FTP error:', error);
        });

        client.connect(ftpConfig);
    }

    async createSubfolder(parentFolderPath, newSubfolderName) {
        const client = await new ftp();

        client.on('ready', () => {
            // Điều hướng đến thư mục cha
            client.cwd(parentFolderPath, (err) => {
                if (err) {
                    console.error('Error createSubfolder:', err);
                    client.end();
                    return;
                }

                // Tạo thư mục con
                client.mkdir(newSubfolderName, (err) => {
                    if (err) {
                        console.error(`Error create Subfolder ${newSubfolderName}  :`, err);
                    } else {
                        console.log('Directory created successfully.');
                    }

                    client.end();
                });
            });
        });

        client.connect({
            host: `${process.env.FTP_HOST}`,
            user: `${process.env.FTP_USER}`,
            password: `${process.env.FTP_PASSWORD}`,
            port: `${process.env.FTP_PORT}`,
        });
    }

    async uploadFromStream(readStream, filename, folderName): Promise<any> {
        const filePath = folderName + filename;

        const ftpConfig = {
            host: `${process.env.FTP_HOST}`,
            user: `${process.env.FTP_USER}`,
            password: `${process.env.FTP_PASSWORD}`,
            port: `${process.env.FTP_PORT}`,
        };

        const client = await new ftp();

        client.on('ready', () => {
            console.log('Connected to FTP server uploadFrom', filePath);

            client.put(readStream, filePath, (error) => {
                if (error) {
                    console.error('Error uploading file:' + filePath, error);
                } else {
                    console.log('File uploaded successfully');
                }
                client.end(); // Đóng kết nối sau khi hoàn thành tác vụ
            });
        });

        client.on('error', (error) => {
            console.error('FTP error:', error);
        });

        client.connect(ftpConfig);
    }

    async uploadPdfToFolder(pdfStream, remoteFolderPath, remoteFileName, documentSetCreate) {
        const client = await new ftp();

        client.on('ready', () => {
            // Điều hướng đến thư mục trước khi tải lên

            client.cwd(remoteFolderPath, (err) => {
                if (err) {
                    console.error(`Error uploadPdfToFolder ${remoteFileName} :`, err);

                    client.end();

                    return;
                }

                // Tải lên tệp PDF

                const bufferStream = new stream.PassThrough();

                bufferStream.end(pdfStream);

                client.put(bufferStream, remoteFileName, (err) => {
                    if (err) {
                        console.error('Error uploading file:' + remoteFileName);
                    } else {
                        console.log('File uploaded successfully');
                    }

                    client.end();
                });
            });
        });

        client.connect({
            host: `${process.env.FTP_HOST}`,

            user: `${process.env.FTP_USER}`,

            password: `${process.env.FTP_PASSWORD}`,

            port: `${process.env.FTP_PORT}`,
        });
    }

    async uploadPdfToFolderEnd(pdfStream, remoteFolderPath, remoteFileName, documentSetCreate) {
        const client = await new ftp();

        client.on('ready', () => {
            // Điều hướng đến thư mục trước khi tải lên

            client.cwd(remoteFolderPath, (err) => {
                if (err) {
                    console.error(`Error uploadPdfToFolder ${remoteFileName} :`, err);

                    client.end();

                    return;
                }

                // Tải lên tệp PDF

                const bufferStream = new stream.PassThrough();

                bufferStream.end(pdfStream);

                client.put(bufferStream, remoteFileName, (err) => {
                    if (err) {
                        console.error('Error uploading file:' + remoteFileName);
                    } else {
                        console.log('File uploaded successfully uploadPdfToFolderEnd');

                        this.documentService.sendPdfConvert(documentSetCreate.id);
                    }

                    client.end();
                });
            });
        });

        client.connect({
            host: `${process.env.FTP_HOST}`,

            user: `${process.env.FTP_USER}`,

            password: `${process.env.FTP_PASSWORD}`,

            port: `${process.env.FTP_PORT}`,
        });
    }

    async uploadExcelToFolder(pdfStream, remoteFolderPath, remoteFileName) {
        const client = await new ftp();

        client.on('ready', () => {
            // Điều hướng đến thư mục trước khi tải lên
            client.cwd(remoteFolderPath, (err) => {
                if (err) {
                    console.error(`Error uploadPdfToFolder ${remoteFileName} :`, err);
                    client.end();
                    return;
                }

                // Tải lên tệp PDF
                const bufferStream = new stream.PassThrough();
                bufferStream.end(pdfStream);
                client.put(bufferStream, remoteFileName, (err) => {
                    if (err) {
                        console.error('Error uploading file:' + remoteFileName);
                    } else {
                        console.log('File uploaded successfully');
                    }

                    client.end();
                });
            });
        });

        client.connect({
            host: `${process.env.FTP_HOST}`,
            user: `${process.env.FTP_USER}`,
            password: `${process.env.FTP_PASSWORD}`,
            port: `${process.env.FTP_PORT}`,
        });
    }
}
