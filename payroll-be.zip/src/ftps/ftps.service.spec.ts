import { Test, TestingModule } from '@nestjs/testing';
import { FtpsService } from './ftps.service';

describe('FtpsService', () => {
  let service: FtpsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FtpsService],
    }).compile();

    service = module.get<FtpsService>(FtpsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
