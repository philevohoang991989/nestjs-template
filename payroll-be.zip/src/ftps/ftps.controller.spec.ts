import { Test, TestingModule } from '@nestjs/testing';
import { FtpsController } from './ftps.controller';

describe('FtpsController', () => {
  let controller: FtpsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FtpsController],
    }).compile();

    controller = module.get<FtpsController>(FtpsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
