import { Module } from '@nestjs/common';
import { FtpsService } from './ftps.service';
import { FtpsController } from './ftps.controller';
import { DocumentsModule } from 'src/documents/documents.module';

@Module({
  imports:[DocumentsModule],
  providers: [FtpsService],
  controllers: [FtpsController],
  exports: [FtpsService],
})
export class FtpsModule {}
