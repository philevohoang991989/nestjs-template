import { BadRequestException, Controller, Get, Header, Res, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { FtpsService } from './ftps.service';
import path from 'path';
// @UseGuards(JwtAuthGuard)
@ApiTags('ftps')
@Controller('ftps')
export class FtpsController {
    constructor(private ftpService: FtpsService) {}

    @Get('/download-image')
    async downloadImage(@Res() res) {
        const filename = '/files/test-image.png';
        // const filename = '/2023-08-31/1070/files/1 LAI THIEU.CHI LUONG HÆ¯Æ NG PHUC.pdf';

        try {
            const remoteFileStream = await this.ftpService.downloadImage(filename);
            // const remoteFileStream = await this.ftpService.readFile(filename);
            // return remoteFileStream;
            remoteFileStream.pipe(res);
        } catch (error) {
            throw new BadRequestException(error.message);
        }
    }

    @Get('/download-result')
    async downloadResult() {
        const filename = 'response 307.json';

        try {
            const remoteFileStream = await this.ftpService.downloadResult(filename);
            return remoteFileStream;
        } catch (error) {
            throw new BadRequestException(error.message);
        }
    }

    @Get('upload')
    async uploadFrom(): Promise<any> {
        try {
            const filename = 'response 307.json';
            return await this.ftpService.uploadFrom(filename);
        } catch (e) {
            throw new BadRequestException(e.message);
        }
    }

    @Get('create-folder')
    async createFolder(): Promise<any> {
        try {
            const object = ['excels', 'images', 'OCR_result'];

            const date = new Date().toISOString().slice(0, 10);

            const folder = '/' + date + `/${900333}/`;

            await this.ftpService.createFolder(folder + 'files');

            const myTimeout = setTimeout(() => {
                callPause(folder, object);
            }, 6000);

            const callPause = async (folder, object) => {
                await this.CallClassifyType(folder, object);
                clearTimeout(myTimeout);
            };

            return true;
        } catch (e) {
            throw new BadRequestException(e.message);
        }
    }

    async CallClassifyType(folder, object) {
        for (let i = 0; i < object.length; i++) {
            const iterator = object[i];

            await this.ftpService.createSubfolder(folder, iterator);
        }
    }
}
