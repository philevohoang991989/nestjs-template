import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    app.getHttpAdapter().getInstance().disable('x-powered-by');
    app.use((request, response, next) => {
        response.set('X-Content-Type-Options', 'nosniff');
        next();
      });

    const kafkaOptions = app.get(ConfigService).get('kafka.options');
    app.connectMicroservice(kafkaOptions);

    const options = new DocumentBuilder()
        .setTitle('BnK NestJS API')
        .setDescription('The BnK NestJS API description')
        .setVersion('1.0')
        .addBearerAuth()
        .build();
    const document = SwaggerModule.createDocument(app, options);
    SwaggerModule.setup('api', app, document);
    
    await app.startAllMicroservices();
    app.enableCors();
    await app.listen(3001);
}
bootstrap();
