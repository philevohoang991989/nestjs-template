import { ApiProperty } from '@nestjs/swagger';

export class UpdateUserManegementDTO {
   
    @ApiProperty()
    username: string;

    @ApiProperty()
    role: number;

    @ApiProperty()
    locationId: number;
}
