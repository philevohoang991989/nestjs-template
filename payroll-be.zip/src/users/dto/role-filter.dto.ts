import { ApiPropertyOptional } from '@nestjs/swagger';

export class FilterRoleDTO {  
    @ApiPropertyOptional()
    role: string;
}
