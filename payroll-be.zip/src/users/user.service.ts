import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { ChangePasswordDTO } from 'src/auth/dto/change-password.dto';
import { ResetPasswordDTO } from 'src/auth/dto/reset-password.dto';
import { ERROR_CODE, UserRole } from 'src/shared/constants/common.constant';
import { ResponseDTO } from 'src/shared/dto/base.dto';
import { createPassword } from 'src/shared/helpers/generate-password';
import { Brackets, Repository } from 'typeorm';
import { CreateUserDTO } from './dto/create-user.dto';
import { UpdateUserDTO } from './dto/update-user.dto';
import { User } from './entity/user.entity';
/* eslint-disable */
const bcrypt = require('bcrypt');
import { ConfigService } from '@nestjs/config';
import { MailService } from 'src/mail/mail.service';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { FilterUserDTO } from './dto/user-filter.dto';
import { ActiveUserDTO } from './dto/active-user.dto';
import moment = require('moment-timezone');
import { DEFAULT_TIMEZONE } from 'src/shared/constants';
import { UpdateUserManegementDTO } from './dto/update-user-manegement.dto';
import { CreateUserRoleDTO } from './dto/create-user-role.dto';
import { UserRoles } from './entity/userRole.entity';
import { UserRoleSingle } from './entity/userRoleSingle.entity';
import { Role } from './entity/role.entity';

@Injectable()
export class UserService {
    private readonly users: User[];

    constructor(
        @InjectRepository(Role) private roleRepository: Repository<Role>,
        @InjectRepository(User) private userRepository: Repository<User>,
        @InjectRepository(UserRoles)
        private userRoleRepository: Repository<UserRoles>,
        @InjectRepository(UserRoleSingle)
        private userRoleSingleRepository: Repository<UserRoleSingle>,
        private jwtService: JwtService,
        private configService: ConfigService,
        private mailService: MailService,
    ) {
        moment.tz.setDefault(DEFAULT_TIMEZONE);
    }

    async pagination(filters: FilterUserDTO, query?: FindQueryDto): Promise<ResponseDTO> {
        const qb = this.userRepository
            .createQueryBuilder('user')
            .leftJoinAndSelect('user.location', 'location')
            .leftJoinAndSelect('user.role', 'role');

        if (filters.keyword) {
            qb.andWhere(
                new Brackets((sqb) => {
                    sqb.where('user.name ILIKE :keyword', {
                        keyword: `%${filters.keyword}%`,
                    }).orWhere('user.username ILIKE :keyword');
                }),
            );
        }

        if (filters.sol) {
            qb.andWhere('location.id = :id', { id: filters.sol });
        }

        if (filters.role) {
            qb.andWhere('user.role = :role', { role: filters.role });
        }

        if (query.sort) {
            qb.orderBy(getOrderByClause(query.sort));
        } else {
            qb.orderBy('user.id', 'DESC');
        }

        const results = await qb
            .skip(+query.limit * (+query.page - 1))
            .take(+query.limit)
            .getManyAndCount();
        const payload = new Pagination(results);

        for (const user of payload.items) {
            user['roleUsers'] = await this.findRoleUserSingle(user.id);
        }

        return {
            data: payload,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Get user success',
            },
        };
    }

    async register(registerDto: CreateUserDTO): Promise<ResponseDTO> {
        const isExistedUser = await this.userRepository.findOne({
            where: {
                username: registerDto.username.toLocaleLowerCase(),
            },
        });
        if (isExistedUser) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.EMAIL_EXISTED,
                    message: 'Username is existed',
                },
            };
        }

        // Generate password | token (expires in 48hours) and send email
        const reset_token = this.jwtService.sign({
            username: registerDto.username,
        });
        // const temporaryPassword = createPassword();
        const temporaryPassword = 'Exim@123';
        const newUser = new User();
        newUser.name = registerDto.name;
        newUser.retryNumber = 0;
        newUser.username = registerDto.username;
        newUser.password = await this.hashPassword(temporaryPassword);
        newUser.resetToken = reset_token;
        newUser.isFirstLogin = false;
        newUser.locationId = 746;
        newUser.isActive = true;
        newUser.roleId = registerDto.role || UserRole.Uploader;
        const user = await this.userRepository.save(newUser);

        const link = `${this.configService.get('DOMAIN_URL')}/active-account?token=${reset_token}`;

        // Send email
        // this.mailService.sendActiveAccount(
        //     link,
        //     registerDto.username,
        //     temporaryPassword,
        //     registerDto.language,user.name
        // );

        // Remove sensitive data
        delete user.password;
        delete user.resetToken;
        return {
            data: user,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Register success',
            },
        };
    }

    async activeUser(id: number, dto: ActiveUserDTO) {
        const existedUser = await this.userRepository.findOne({
            where: {
                id: id,
            },
        });
        if (!existedUser) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.USER_NOT_FOUND,
                    message: 'Username not found',
                },
            };
        }

        if (!dto.isActive) {
            existedUser.isActive = false;
            await this.userRepository.save(existedUser);
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.SUCCESS,
                    message: 'De-active user success',
                },
            };
        } else {
            existedUser.isActive = true;
        }

        // Update user as first login then send email to user
        // const reset_token = this.jwtService.sign({
        //     username: existedUser.username,
        // });
        // const temporaryPassword = createPassword();

        existedUser.isFirstLogin = true;
        existedUser.retryNumber = 0;
        existedUser.blockAt = null;
        // existedUser.resetToken = reset_token;
        // existedUser.password = temporaryPassword;
        await this.userRepository.save(existedUser);

        // Send email
        // const link = `${this.configService.get(
        //     'DOMAIN_URL',
        // )}/active-account?token=${reset_token}`;
        // this.mailService.sendActiveAccount(
        //     link,
        //     existedUser.username,
        //     temporaryPassword,
        //     dto.language,
        // );

        return {
            data: undefined,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Active user success',
            },
        };
    }

    async updateUserManegement(id: number, dto: UpdateUserManegementDTO) {
        const user = await this.userRepository.findOne({
            where: {
                id: id,
            },
        });
        if (!user) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.USER_NOT_FOUND,
                    message: 'Username not found',
                },
            };
        }

        if (dto.username) {
            user.name = dto.username;
        }
        if (dto.role) {
            user.roleId = dto.role;
        }
        if (dto.locationId) {
            user.locationId = dto.locationId;
        }

        await this.userRepository.save(user);

        return {
            data: user,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Update user success',
            },
        };
    }

    async resetPassword(resetPassword: ResetPasswordDTO): Promise<ResponseDTO> {
        const isExistedUser = await this.userRepository.findOne({
            where: {
                username: resetPassword.username.toLocaleLowerCase(),
            },
        });
        if (!isExistedUser) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'Username is existed',
                },
            };
        }

        isExistedUser.password = await this.hashPassword(resetPassword.newPassword);
        isExistedUser.resetToken = null;
        isExistedUser.retryNumber = 0;
        isExistedUser.blockAt = null;
        isExistedUser.expiredIn = moment().add(60, 'day').toDate();
        const user = await this.userRepository.save(isExistedUser);
        delete user.password;

        return {
            data: user,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Reset password success',
            },
        };
    }

    async changePassword(changePassword: ChangePasswordDTO): Promise<ResponseDTO> {
        const isExistedUser = await this.userRepository.findOne({
            where: {
                username: changePassword.username.toLocaleLowerCase(),
            },
        });
        if (!isExistedUser) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.NOT_FOUND,
                    message: 'User not found',
                },
            };
        }

        // Compare password
        if (!(await this.compareHashedPassword(changePassword.oldPassword, isExistedUser.password))) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.OLD_PASSWORD_NOT_MATCH,
                    message: 'Old password not match',
                },
            };
        }

        // New password same as old password
        if (changePassword.oldPassword === changePassword.newPassword) {
            return {
                data: undefined,
                msgSts: {
                    code: ERROR_CODE.OLD_PASSWORD_SAME_NEW_PASSWORD,
                    message: 'Old password is same as new password',
                },
            };
        }

        isExistedUser.password = await this.hashPassword(changePassword.newPassword);
        isExistedUser.blockAt = null;
        isExistedUser.retryNumber = 0;
        isExistedUser.expiredIn = moment().add(60, 'day').toDate();
        const user = await this.userRepository.save(isExistedUser);
        delete user.password;

        return {
            data: user,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Change password success',
            },
        };
    }

    async reset(id: number): Promise<User> {
        const user = await this.userRepository.findOne({ where: { id: id } });

        user.password = await this.hashPassword('Exim@123');

        return this.userRepository.save(user);
    }

    async update(id: number, updateUserDto: UpdateUserDTO): Promise<User> {
        const user = await this.userRepository.findOne({ where: { id: id } });
        if (updateUserDto.resetToken) {
            user.resetToken = updateUserDto.resetToken;
        }
        if (updateUserDto.retryNumber !== undefined) {
            user.retryNumber = updateUserDto.retryNumber;
        }
        if (updateUserDto.blockAt) {
            user.blockAt = updateUserDto.blockAt;
        }
        if (updateUserDto.password) {
            user.password = await this.hashPassword(updateUserDto.password);
        }

        return this.userRepository.save(user);
    }

    async delete(id: number) {
        this.userRepository.softDelete(id);

        const user = await this.userRepository.findOne({
            where: {
                id: id,
            },
            withDeleted: true,
        });

        return {
            data: user,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Delete user success',
            },
        };
    }

    async find(): Promise<User[]> {
        return this.userRepository.find();
    }

    async findById(id: number): Promise<User> {
        return this.userRepository.findOne({
            where: {
                id: id,
            },
        });
    }

    async findByUsername(username: string): Promise<User> {
        return this.userRepository.findOne({
            where: {
                username: username,
            },
        });
    }

    async hashPassword(plainPassword: string) {
        return bcrypt.hash(plainPassword, 10);
    }

    async compareHashedPassword(plain: string, hashed: string) {
        return bcrypt.compare(plain, hashed);
    }
    async checkChangePassword(id: number) {
        const user = await this.findById(id);
        if (!user) {
            return true;
        }
        const blockAt = user.blockAt;
        const expiredIn = user.expiredIn.valueOf() - Date.now();
        if (blockAt || expiredIn <= 0) {
            return false;
        }
        return true;
    }

    async role(filters: CreateUserRoleDTO) {
        const role = await this.roleRepository
            .createQueryBuilder('role')
            .andWhere('role.name = :name', {
                name: filters.role,
            })
            .getOne();
        if (role) {
            return role;
        } else {
            const roleNew = new Role();
            roleNew.name = filters.role;
            return await this.roleRepository.save(roleNew);
        }
    }

    async createRole(dtos: CreateUserRoleDTO[]): Promise<ResponseDTO> {
        const userRoles = [];
        for (let i = 0; i < dtos.length; i++) {
            const dto = dtos[i];
            const userRole = new UserRoles();
            const role = await this.role(dto);
            const userRoleData = await this.findRole(dto);
            if (userRoleData && userRoleData.id) {
                userRole.id = userRoleData.id;
            }
            userRole.roleId = role.id;
            userRole.screen = dto.screen;
            userRole.manipulation = dto.manipulation;
            userRole.role = dto.role;
            userRole.isActive = dto.isActive;
            userRoles.push(userRole);
        }

        const payload = await this.userRoleRepository.save(userRoles);
        return {
            data: payload,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Create location success',
            },
        };
    }

    async createRoleSingle(id: number, dtos: any): Promise<ResponseDTO> {
        const updateRole = await this.findRoleUserSingle(id);
        const role = await this.roleRepository.findOne({
            where: {
                id: dtos.dataRoleSend[0].role,
            },
        });
        if (updateRole && updateRole.length > 0 && updateRole[0].role != role.name) {
            for (const role of updateRole) {
                console.log(role);

                await this.userRoleSingleRepository.softDelete(role.id);
            }
        }
        const userRoles = [];
        for (let i = 0; i < dtos.dataRoleSend.length; i++) {
            const dto = dtos.dataRoleSend[i];
            dto.role = role.name;
            const userRoleSingle = new UserRoleSingle();
            const userRoleData = await this.findRoleSingle(dto, id);
            if (userRoleData && userRoleData.id) {
                userRoleSingle.id = userRoleData.id;
            }
            userRoleSingle.roleId = role.id;
            userRoleSingle.screen = dto.screen;
            userRoleSingle.manipulation = dto.manipulation;
            userRoleSingle.role = role.name;
            userRoleSingle.isActive = dto.isActive;
            userRoleSingle.userId = id;
            userRoles.push(userRoleSingle);
        }

        const payload = await this.userRoleSingleRepository.save(userRoles);
        return {
            data: payload,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Create location success',
            },
        };
    }

    async findRoleUserSingle(id: number) {
        return await this.userRoleSingleRepository
            .createQueryBuilder('user_role_single')
            .andWhere('user_role_single.userId = :userId', {
                userId: id,
            })
            .getMany();
    }

    async findRoleSingle(filters: CreateUserRoleDTO, id: number) {
        return await this.userRoleSingleRepository
            .createQueryBuilder('user_role_single')
            .andWhere('user_role_single.screen = :screen', {
                screen: filters.screen,
            })
            .andWhere('user_role_single.manipulation = :manipulation', {
                manipulation: filters.manipulation,
            })
            .andWhere('user_role_single.role = :role', {
                role: filters.role,
            })
            .andWhere('user_role_single.userId = :userId', {
                userId: id,
            })
            .getOne();
    }

    async findRole(filters: CreateUserRoleDTO) {
        return await this.userRoleRepository
            .createQueryBuilder('user_role')
            .andWhere('user_role.screen = :screen', {
                screen: filters.screen,
            })
            .andWhere('user_role.manipulation = :manipulation', {
                manipulation: filters.manipulation,
            })
            .andWhere('user_role.role = :role', {
                role: filters.role,
            })
            .getOne();
    }

    async paginationRole(query?: FindQueryDto): Promise<ResponseDTO> {
        const qb = this.userRoleRepository.createQueryBuilder('user_role');
        if (query.sort) {
            qb.orderBy(getOrderByClause(query.sort));
        } else {
            qb.orderBy('user_role.id', 'ASC');
        }

        const results = await qb.getMany();

        const roles = results.filter((value, index, self) => index === self.findIndex((t) => t.role === value.role));

        const listRole = roles.map((currElement, index) => {
            return {
                id: index,
                name: currElement.role,
            };
        });

        const groupByScreen = results.reduce(function (r, a) {
            r[a.screen] = r[a.screen] || [];
            r[a.screen].push(a);
            return r;
        }, Object.create(null));

        return {
            data: { listRole, groupByScreen },
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Get user success',
            },
        };
    }

    async paginationRoleGroup(id: number): Promise<ResponseDTO> {
        const results = await this.userRoleRepository
            .createQueryBuilder('user_role')
            .andWhere('user_role.roleId = :roleId', {
                roleId: id,
            })
            .orderBy('user_role.id', 'ASC')
            .getMany();

        const roles = results.filter((value, index, self) => index === self.findIndex((t) => t.role === value.role));

        const listRole = roles.map((currElement, index) => {
            return {
                id: index,
                name: currElement.role,
            };
        });

        const groupByScreen = results.reduce(function (r, a) {
            r[a.screen] = r[a.screen] || [];
            r[a.screen].push(a);
            return r;
        }, Object.create(null));

        return {
            data: { listRole, groupByScreen },
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Get user success',
            },
        };
    }

    async paginationRoleUser(id): Promise<ResponseDTO> {
        const results = await this.findRoleUserSingle(id);

        return {
            data: results,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Get user success',
            },
        };
    }

    async listRole(): Promise<ResponseDTO> {
        const qb = this.roleRepository.createQueryBuilder('role').orderBy('role.id', 'ASC');

        const results = await qb.getMany();

        return {
            data: results,
            msgSts: {
                code: ERROR_CODE.SUCCESS,
                message: 'Get user success',
            },
        };
    }
}
