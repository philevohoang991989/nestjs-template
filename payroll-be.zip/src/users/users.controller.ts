import {
    Body,
    Controller,
    Delete,
    Get,
    Inject,
    Logger,
    Param,
    Post,
    Put,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { UserRole } from 'src/shared/constants/common.constant';
import { ResponseDTO } from 'src/shared/dto/base.dto';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { Roles } from 'src/shared/guards/roles.decorator';
import { RolesGuard } from 'src/shared/guards/roles.guard';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { NormalizeFilterPipe } from './pipes/normalize-filter.pipe';
import { ActiveUserDTO } from './dto/active-user.dto';
import { CreateUserRoleDTO } from './dto/create-user-role.dto';
import { CreateUserDTO } from './dto/create-user.dto';
import { UpdateUserManegementDTO } from './dto/update-user-manegement.dto';
import { UpdateUserDTO } from './dto/update-user.dto';
import { FilterUserDTO } from './dto/user-filter.dto';
import { User } from './interface/user.interface';
import { UserService } from './user.service';

@ApiTags('users')
@Controller('users')
// TODO: un-comment below line to enable authentication for user controller
@UseGuards(new JwtAuthGuard())
// @UseGuards(CheckChangePassword)
@ApiBearerAuth()
export class UsersController {
    constructor(
        private userService: UserService,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    ) {}

    @Post('pagination')
    async pagination(
        @Body(NormalizeFilterPipe) filters: FilterUserDTO,
        @Query(NormalizeFindQueryPipe) query: FindQueryDto,
    ) {
        return this.userService.pagination(filters, query);
    }

    @Post('register')
    @UseGuards(RolesGuard)
    @Roles(UserRole.Admin)
    async create(@Body() createUserDTO: CreateUserDTO): Promise<ResponseDTO> {
        return this.userService.register(createUserDTO);
    }


    @Put('reset/:id')
    @ApiParam({ name: 'id' })
    async reset(
        @Param('id') id: number,
    ): Promise<User> {
        return this.userService.reset(id);
    }

    @Put(':id')
    @ApiParam({ name: 'id' })
    async update(
        @Param('id') id: number,
        @Body() updateUserDTO: UpdateUserDTO,
    ): Promise<User> {
        return this.userService.update(id, updateUserDTO);
    }

    @Get()
    async find(): Promise<User[]> {
        // TODO: remove log debug message
        this.logger.debug(
            'This log message should be write to console and file app.log as well.',
        );
        return this.userService.find();
    }

    @Get(':id')
    @ApiParam({ name: 'id' })
    async findById(@Param('id') id: number): Promise<User> {
        return this.userService.findById(id);
    }

    @Delete(':id')
    @ApiParam({ name: 'id' })
    async delete(@Param('id') id: number): Promise<ResponseDTO> {
        return this.userService.delete(id);
    }

    @Put('active/:id')
    @ApiParam({ name: 'id' })
    async activeUser(@Param('id') id: number, @Body() dto: ActiveUserDTO) {
        return this.userService.activeUser(id, dto);
    }

    @Put('update-user-manegement/:id')
    @ApiParam({ name: 'id' })
    async updateUserManegement(
        @Param('id') id: number,
        @Body() dto: UpdateUserManegementDTO,
    ) {
        return this.userService.updateUserManegement(id, dto);
    }

    @Post('pagination-role')
    async paginationRole(
        @Query(NormalizeFindQueryPipe) query: FindQueryDto,
        @Req() req,
    ) {
        return this.userService.paginationRole(query);
    }

    @Post('pagination-role-group/:id')
    @ApiParam({ name: 'id' })
    async paginationRoleGroup(@Param('id') id: number) {
        return this.userService.paginationRoleGroup(id);
    }

    @Post('list-role')
    async listRole() {
        return this.userService.listRole();
    }

    @Post('create-role')
    async createRole(@Body() dto: CreateUserRoleDTO[]): Promise<ResponseDTO> {
        return this.userService.createRole(dto);
    }

    @Get('pagination-role-user/:id')
    @ApiParam({ name: 'id' })
    async paginationRoleUser(@Param('id') id: number): Promise<ResponseDTO> {
        return this.userService.paginationRoleUser(id);
    }

    @Post('create-role-single/:id')
    @ApiParam({ name: 'id' })
    async createRoleSingle(
        @Param('id') id: number,
        @Body() dto: CreateUserRoleDTO[],
    ): Promise<ResponseDTO> {
        return this.userService.createRoleSingle(id, dto);
    }
}
