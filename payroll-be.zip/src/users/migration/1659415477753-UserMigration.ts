import {MigrationInterface, QueryRunner} from "typeorm";

export class UserMigration1659415477753 implements MigrationInterface {
    name = 'UserMigration1659415477753'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "public"."locations" (
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                "id" SERIAL NOT NULL,
                "name" character varying NOT NULL,
                CONSTRAINT "PK_5634d37d612cece501cd77dd6ad" PRIMARY KEY ("id")
            )
        `);
        await queryRunner.query(`
            CREATE TABLE "public"."users" (
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                "id" SERIAL NOT NULL,
                "username" character varying NOT NULL,
                "password" character varying NOT NULL,
                "name" character varying NOT NULL,
                "location_id" integer NOT NULL,
                "role" integer NOT NULL DEFAULT '2',
                "reset_token" character varying,
                CONSTRAINT "PK_4dd86dbf2877821730f7ebb11d9" PRIMARY KEY ("id")
            )
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282421" FOREIGN KEY ("location_id") REFERENCES "public"."locations"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."users" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282421"
        `);
        await queryRunner.query(`
            DROP TABLE "public"."users"
        `);
        await queryRunner.query(`
            DROP TABLE "public"."locations"
        `);
    }

}
