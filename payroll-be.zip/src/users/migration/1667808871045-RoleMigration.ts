import {MigrationInterface, QueryRunner} from "typeorm";

export class RoleMigration1667808871045 implements MigrationInterface {
    name = 'RoleMigration1667808871045'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "public"."role" (
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            "id" SERIAL NOT NULL,
            "name" character varying NOT NULL,
            CONSTRAINT "FK_17d331d2b6a7de5394dfa4ccb17" PRIMARY KEY ("id")
        )`);

        await queryRunner.query(`ALTER TABLE "public"."user_role" ADD "role_id" integer NOT NULL DEFAULT '2'`);

        await queryRunner.query(`ALTER TABLE "public"."user_role_single" ADD "role_id" integer NOT NULL DEFAULT '2'`);
       
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        DROP TABLE "public"."role"
        `);
    }

}
