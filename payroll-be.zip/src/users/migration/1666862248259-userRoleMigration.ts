import {MigrationInterface, QueryRunner} from "typeorm";

export class userRoleMigration1666862248259 implements MigrationInterface {
    name = 'userRoleMigration1666862248259'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "public"."user_role" (
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            "id" SERIAL NOT NULL,
            "screen" character varying NOT NULL,
            "manipulation" character varying NOT NULL,
            "role" character varying NOT NULL,
            "is_active" boolean NOT NULL DEFAULT false,
            CONSTRAINT "FK_6b26873392c3d96957c00436584" PRIMARY KEY ("id")
        )`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "public"."user_role"`);
    }

}
