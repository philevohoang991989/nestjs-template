import {MigrationInterface, QueryRunner} from "typeorm";

export class UserRoleSingleMigration1667448789833 implements MigrationInterface {
    name = 'UserRoleSingleMigration1667448789833'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "public"."user_role_single" (
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                "id" SERIAL NOT NULL,
                "screen" character varying NOT NULL,
                "manipulation" character varying NOT NULL,
                "role" character varying NOT NULL,
                "is_active" boolean NOT NULL DEFAULT false,
                "user_id" integer NOT NULL,
                CONSTRAINT "PK_fb1a50c98dc40fda04f98ab1869" PRIMARY KEY ("id")
            )
        `);
       
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."user_role_single"
        `);
    }

}
