import {MigrationInterface, QueryRunner} from "typeorm";

export class UserMigration1660800346804 implements MigrationInterface {
    name = 'UserMigration1660800346804'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ADD "is_active" boolean NOT NULL DEFAULT true
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ADD "is_first_login" boolean NOT NULL DEFAULT false
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ADD "expired_in" TIMESTAMP WITH TIME ZONE
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ADD "retry_number" integer
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users"
            ADD "block_at" TIMESTAMP WITH TIME ZONE
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."users" DROP COLUMN "block_at"
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users" DROP COLUMN "retry_number"
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users" DROP COLUMN "expired_in"
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users" DROP COLUMN "is_first_login"
        `);
        await queryRunner.query(`
            ALTER TABLE "public"."users" DROP COLUMN "is_active"
        `);
    }

}
