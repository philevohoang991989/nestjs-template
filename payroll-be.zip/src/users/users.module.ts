import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UsersController } from './users.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entity/user.entity';
import { JwtModule } from '@nestjs/jwt';
import { MailModule } from 'src/mail/mail.module';
import { UserRoles } from './entity/userRole.entity';
import { UserRoleSingle } from './entity/userRoleSingle.entity';
import { Role } from './entity/role.entity';
import * as dotenv from 'dotenv';
dotenv.config();

@Module({
    imports: [
        TypeOrmModule.forFeature([User,UserRoles,UserRoleSingle,Role]),
        JwtModule.register({
            secret: process.env.JWT_SECRET,
            signOptions: { expiresIn: '10m' }, // Temporary for testing. Revert to 48h for production
            // signOptions: { expiresIn: '48h' },
        }),
        MailModule,
    ],
    providers: [UserService],
    exports: [UserService],
    controllers: [UsersController],
})
export class UsersModule {}
