import { BaseAudit } from 'src/audit/subscribers/base-audit';
import { EventSubscriber } from 'typeorm';
import { User } from 'src/users/entity/user.entity';

@EventSubscriber()
export class UsersSubscriber extends BaseAudit {
    protected includeFields: string[] = [
        'id',
        'username',
        'name',
        'locationId',
        'role',
    ];
    listenTo(): any {
        return User;
    }
}
