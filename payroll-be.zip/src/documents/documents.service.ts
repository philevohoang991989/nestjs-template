import { Injectable, Inject, BadRequestException, Logger } from '@nestjs/common';
import { ClientKafka } from '@nestjs/microservices';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Repository } from 'typeorm';
import { DocumentFile } from './entity/documentFile.entity';
import { Document } from './entity/document.entity';
import { EnumDocumentStatus } from './entity/documentStatus.entity';
import { DocumentImage } from './entity/documentImage.entity';
import { DocumentToken } from './entity/documentToken.entity';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { FilterTokenDto } from './dto/filter-token.dto';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import * as ftp from 'ftp';

@Injectable()
export class DocumentsService {
    constructor(
        @InjectRepository(DocumentFile)
        private documentFileRepository: Repository<DocumentFile>,

        @InjectRepository(Document)
        private documentRepository: Repository<Document>,

        @InjectRepository(DocumentSet)
        private documentSetRepository: Repository<DocumentSet>,

        @InjectRepository(DocumentToken)
        private documentTokenRepository: Repository<DocumentToken>,
        @Inject('PDF_CONVERT_KAFKA') private client: ClientKafka,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    ) { }

    async downloadImage(filename: string): Promise<ftp.DataSocket> {
        return await new Promise((resolve, reject) => {
            const client = new ftp();

            client.connect({
                host: `${process.env.FTP_HOST}`,
                user: `${process.env.FTP_USER}`,
                password: `${process.env.FTP_PASSWORD}`,
                port: `${process.env.FTP_PORT}`,
            });

            client.on('ready', () => {
                client.get(filename, (error, stream) => {
                    if (error) {
                        client.end();
                        reject(error);
                    } else {
                        resolve(stream);
                    }
                });
                client.end();
            });
        });
    }

    async sendPdfConvert(documentSetId: number) {
        this.logger.log('Starting process sendPdfConvert to Convert Service', 'PROFILING');
        const documentFiles = await this.documentFileRepository
            .createQueryBuilder('document_files')
            .andWhere('document_files.documentSetId = :documentSetId', {
                documentSetId,
            })
            .getMany();

        if (documentFiles.length == 0) {
            throw new BadRequestException('No pdf to convert');
        }

        const params: any = {
            id: documentSetId,
            files: [],
        };

        for (const documentFile of documentFiles) {
            params.files.push({
                filePath: documentFile.path,
                originalName: documentFile.originalName,
                documentFileId: documentFile.id,
            });
        }

        this.client.emit(process.env.TOPIC_KAFKA_REQUEST_CONVERT, params);
        this.logger.log('End sendPdfConvert to Convert Service', 'PROFILING');
        return params;
    }

    async createDocumentByImages(dto) {
        this.logger.log('Starting createDocumentByImages receive from Convert Service', 'PROFILING');
        const documentSet = await this.documentSetRepository
            .createQueryBuilder('document_sets')
            .andWhere('document_sets.id = :id', { id: dto.id })
            .getOne();

        if (documentSet && documentSet.documentSetStatusId == EnumDocumentStatus.OPEN) {
            const documents = await this.documentRepository
                .createQueryBuilder('documents')
                .andWhere('documents.documentSetId = :documentSetId', {
                    documentSetId: dto.id,
                })
                .getMany();

            if (documents && documents.length != 0) {

                this.logger.error('Skip, Documentset already created documents: ' + documentSet.id, 'PROFILING');
                return "Already created documents.";
            }

            return await this.documentRepository.manager.transaction(async (transactionalEntityManager) => {
                if (dto.imageFiles.length != 0) {
                    for (const i in dto.imageFiles) {
                        const images = dto.imageFiles[i].images;

                        for (const j in images) {
                            // create document
                            const documentData = new Document();
                            documentData.documentSetId = dto.id;
                            documentData.documentStatusId = EnumDocumentStatus.OPEN;

                            this.logger.log('Start save Document Data', 'PROFILING');
                            const document = await transactionalEntityManager.save(documentData);
                            this.logger.log('End save Document Data', 'PROFILING');

                            const documentImageData = new DocumentImage();
                            documentImageData.documentId = document.id;
                            documentImageData.documentFileId = dto.imageFiles[i].documentFileId;
                            documentImageData.originalName = images[j].originalName;
                            documentImageData.path = images[j].path;

                            this.logger.log('Start save Document Image', 'PROFILING');
                            await transactionalEntityManager.save(documentImageData);
                            this.logger.log('End save Document Image', 'PROFILING');
                        }
                    }
                    this.logger.log('End createDocumentByImages receive from Convert Service', 'PROFILING');
                }
            });
        }
    }

    async findOne(id: number, relations: string[] = []): Promise<any> {
        const document = await this.documentRepository.findOne({
            where: { id },
            relations: relations,
        });

        if (!document) {
            throw new BadRequestException('Document dose not exist');
        }

        return document;
    }

    async paginationTokens(documentId: number, dto: FilterTokenDto): Promise<any> {
        const qb = this.documentTokenRepository
            .createQueryBuilder('document_tokens')
            .leftJoin('document_tokens.documentValidations', 'documentValidations')
            .andWhere('document_tokens.documentId = :documentId', {
                documentId: documentId,
            });

        if (dto.isFail && dto.isFail.toString() == 'true') {
            qb.andWhere(
                new Brackets((sqb) => {
                    sqb.where('documentValidations.is_validation = :isValidate', {
                        isValidate: 0,
                    }).orWhere('documentValidations.is_validation IS NULL');
                }),
            );
        }

        let results = await qb.getManyAndCount();

        const validations = await this.documentTokenRepository
            .createQueryBuilder('document_tokens')
            .leftJoinAndSelect('document_tokens.documentValidations', 'documentValidations')
            .andWhere('document_tokens.documentId = :documentId', {
                documentId: documentId,
            })
            .getManyAndCount();

        const checkDocumentValidations = validations[0].filter((x) => x.documentValidations.length > 0);

        if (
            checkDocumentValidations.length == 0 &&
            dto.isFail &&
            dto.isFail.toString() == 'true' &&
            results[1] == 0
            // || checkDocumentValidations.length == results[1]
        ) {
            results = validations;
        }

        return new Pagination(results);
    }
}
