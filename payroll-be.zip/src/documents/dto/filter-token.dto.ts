import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsBoolean } from 'class-validator';

export class FilterTokenDto {
    @ApiPropertyOptional()
    @IsBoolean()
    @Type(() => Boolean)
    isFail?: boolean;
}
