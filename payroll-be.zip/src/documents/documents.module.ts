import { Module } from '@nestjs/common';
import { DocumentsService } from './documents.service';
import { DocumentsController } from './documents.controller';
import { ConfigService } from '@nestjs/config';
import { ClientProxyFactory, KafkaOptions } from '@nestjs/microservices';
import { DocumentFile } from './entity/documentFile.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Document } from './entity/document.entity';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { DocumentToken } from './entity/documentToken.entity';
import { DocumentImage } from './entity/documentImage.entity';

@Module({
    imports: [
        TypeOrmModule.forFeature([DocumentFile, Document, DocumentSet, DocumentToken, DocumentImage]),
    ],
    providers: [
        {
            provide: 'PDF_CONVERT_KAFKA',
            useFactory: (configService: ConfigService) => {
                const kafkaOptions: KafkaOptions = configService.get('kafka.options');
                return ClientProxyFactory.create(kafkaOptions);
            },
            inject: [ConfigService],
        },
        DocumentsService,
    ],
    controllers: [DocumentsController],
    exports: [DocumentsService],
})
export class DocumentsModule {}
