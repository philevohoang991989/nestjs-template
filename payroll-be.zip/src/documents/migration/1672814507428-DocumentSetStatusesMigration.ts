import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentSetStatusMigration1672814507428
    implements MigrationInterface {
    name = 'DocumentSetStatusMigration1672814507428';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_set_statuses" (

            "id" SERIAL NOT NULL,
            "name" character varying ,
            CONSTRAINT "PK_05dec3a41999dafac736105eb28" PRIMARY KEY ("id")
        )
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_set_statuses"
        `);
    }
}
