import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentValidationsMigration1672814507431
    implements MigrationInterface {
    name = 'DocumentValidationsMigration1672814507431';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_validations" (

            "id" SERIAL NOT NULL,
            "excel_id" integer NOT NULL,
            "document_token_id" integer NOT NULL,
            "is_validation" integer ,
            "key_errors" jsonb ,
            "data" jsonb,
            CONSTRAINT "PK_05dec3a41999dafac736105eb31" PRIMARY KEY ("id")
    )
    `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_validations"
        `);
    }
}
