import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentSetsMigration1672814507424 implements MigrationInterface {
    name = 'DocumentSetsMigration1672814507424';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_sets" (

            "id" SERIAL NOT NULL,
            "created_by" integer NOT NULL,
            "updated_by" integer NOT NULL,
            "document_set_status_id" integer ,
            "name" character varying ,
            "type" integer ,
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            CONSTRAINT "PK_05dec3a41999dafac736105eb24" PRIMARY KEY ("id")
        )
    `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_sets"
        `);
    }
}
