import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentStatusMigration1672814507426
    implements MigrationInterface {
    name = 'DocumentStatusMigration1672814507426';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_statuses" (

            "id" SERIAL NOT NULL,
            "name" character varying ,
            CONSTRAINT "PK_05dec3a41999dafac736105eb26" PRIMARY KEY ("id")
        )
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_statuses"
        `);
    }
}
