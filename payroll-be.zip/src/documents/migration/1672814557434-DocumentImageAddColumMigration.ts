import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentImageAddColumMigration1672814557434
    implements MigrationInterface
{
    name = 'DocumentImageAddColumMigration1672814557434';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."document_images"
            ADD "width" integer NOT NULL DEFAULT '0',
            ADD "height" integer NOT NULL DEFAULT '0'
           
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_images"
        `);
    }
}
