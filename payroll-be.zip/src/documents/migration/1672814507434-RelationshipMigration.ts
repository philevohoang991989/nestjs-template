import { MigrationInterface, QueryRunner } from 'typeorm';

export class RelationshipMigration1672814507434 implements MigrationInterface {
    name = 'RelationshipMigration1672814507434';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        ALTER TABLE "public"."documents"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282422" FOREIGN KEY ("document_set_id") REFERENCES "public"."document_sets"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_images"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282424" FOREIGN KEY ("document_id") REFERENCES "public"."documents"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
        await queryRunner.query(`
        ALTER TABLE "public"."document_images"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282425" FOREIGN KEY ("document_file_id") REFERENCES "public"."document_files"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_files"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282426" FOREIGN KEY ("document_set_id") REFERENCES "public"."document_sets"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
        await queryRunner.query(`
        ALTER TABLE "public"."excels"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282427" FOREIGN KEY ("document_set_id") REFERENCES "public"."document_sets"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_tokens"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282429" FOREIGN KEY ("document_id") REFERENCES "public"."documents"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_validations"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282430" FOREIGN KEY ("document_token_id") REFERENCES "public"."document_tokens"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
        await queryRunner.query(`
        ALTER TABLE "public"."document_validations"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282431" FOREIGN KEY ("excel_id") REFERENCES "public"."excels"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_set_validations"
        ADD CONSTRAINT "FK_51003c7ed8e902ba4b9a4282432" FOREIGN KEY ("document_set_id") REFERENCES "public"."document_sets"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        ALTER TABLE "public"."documents" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282422"
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_images" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282424"
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_images" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282425"
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_files" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282426"
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."excels" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282427"
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_tokens" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282429"
    `);
        await queryRunner.query(`
        ALTER TABLE "public"."document_validations" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282430"
    `);
        await queryRunner.query(`
        ALTER TABLE "public"."document_validations" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282431"
    `);

        await queryRunner.query(`
        ALTER TABLE "public"."document_set_validations" DROP CONSTRAINT "FK_51003c7ed8e902ba4b9a4282432"
    `);
    }
}
