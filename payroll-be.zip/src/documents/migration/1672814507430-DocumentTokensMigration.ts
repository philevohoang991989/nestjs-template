import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentTokensMigration1672814507430
    implements MigrationInterface {
    name = 'DocumentTokensMigration1672814507430';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_tokens" (

            "id" SERIAL NOT NULL,
            "document_id" integer NOT NULL,
            "data" jsonb,
            "coordinate" jsonb,
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            CONSTRAINT "PK_05dec3a41999dafac736105eb30" PRIMARY KEY ("id")
    )
    `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_tokens"
        `);
    }
}
