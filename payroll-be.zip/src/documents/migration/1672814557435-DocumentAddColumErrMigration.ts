import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentImageAddColumMigration1672814557434 implements MigrationInterface {
    name = 'DocumentAddColumErrMigration1672814557435';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "public"."documents"
            ADD "error_type" character varying 
           
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."documents"
        `);
    }
}
