import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentTypesMigration1672814507425 implements MigrationInterface {
    name = 'DocumentTypesMigration1672814507425';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_types" (

            "id" SERIAL NOT NULL,
            "code" character varying ,
            "name" character varying ,
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            CONSTRAINT "PK_05dec3a41999dafac736105eb25" PRIMARY KEY ("id")
    )
    `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_types"
        `);
    }
}
