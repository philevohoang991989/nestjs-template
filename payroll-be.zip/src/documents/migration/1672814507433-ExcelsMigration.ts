import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExcelsMigration1672814507433 implements MigrationInterface {
    name = 'ExcelsMigration1672814507433';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "public"."excels" (
                "id" SERIAL NOT NULL,
                "document_set_id" integer NOT NULL,
                "data" jsonb,
                CONSTRAINT "PK_05dec3a41999dafac736105eb33" PRIMARY KEY ("id")
            )
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."excels"
        `);
    }
}
