import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentImagesMigration1672814507429
    implements MigrationInterface {
    name = 'DocumentImagesMigration1672814507429';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_images" (

            "id" SERIAL NOT NULL,
            "document_id" integer NOT NULL,
            "document_file_id" integer NOT NULL,
            "original_name" character varying ,
            "path" character varying ,
            "qualify" boolean NOT NULL DEFAULT true,  
            "rotation" integer NOT NULL DEFAULT '0',
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            CONSTRAINT "PK_05dec3a41999dafac736105eb29" PRIMARY KEY ("id")
    )
    `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_images"
        `);
    }
}
