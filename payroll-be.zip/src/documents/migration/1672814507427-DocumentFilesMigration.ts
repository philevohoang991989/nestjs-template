import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentFilesMigration1672814507427 implements MigrationInterface {
    name = 'DocumentFilesMigration1672814507427';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        CREATE TABLE "public"."document_files" (

            "id" SERIAL NOT NULL,
            "document_set_id" integer NOT NULL,
            "original_name" character varying ,
            "path" character varying ,
            "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            "deleted_at" TIMESTAMP WITH TIME ZONE,
            CONSTRAINT "PK_05dec3a41999dafac736105eb27" PRIMARY KEY ("id")
    )
    `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."document_files"
        `);
    }
}
