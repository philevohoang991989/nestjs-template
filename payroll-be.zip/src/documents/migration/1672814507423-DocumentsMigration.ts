import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentsMigration1672814507423 implements MigrationInterface {
    name = 'DocumentsMigration1672814507423';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "public"."documents" (

                "id" SERIAL NOT NULL,
                "document_set_id" integer NOT NULL,
                "document_type_id" integer,
                "document_status_id" integer NOT NULL,
                "re_train" boolean NOT NULL DEFAULT false,  
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP WITH TIME ZONE,
                CONSTRAINT "PK_05dec3a41999dafac736105eb23" PRIMARY KEY ("id")
            )
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."documents"
        `);
    }
}
