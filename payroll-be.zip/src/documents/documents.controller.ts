import {
    ClassSerializerInterceptor,
    Controller,
    Get,
    NotFoundException,
    Param,
    ParseIntPipe,
    Query,
    Res,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common';
import { DocumentsService } from './documents.service';
import { Document } from './entity/document.entity';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { FilterTokenDto } from './dto/filter-token.dto';

@UseGuards(JwtAuthGuard)
@ApiTags('documents')
@Controller('documents')
@ApiBearerAuth()
export class DocumentsController {
    constructor(private documentService: DocumentsService) {}

    @Get(':id')
    @UseInterceptors(ClassSerializerInterceptor)
    async findOne(@Param('id', ParseIntPipe) id: number): Promise<Document> {
        return this.documentService.findOne(id, ['documentImage']);
    }

    @Get('/:id/token')
    @UseInterceptors(ClassSerializerInterceptor)
    async paginationTokens(@Param('id', ParseIntPipe) id: number, @Query() dto: FilterTokenDto): Promise<any> {
        return this.documentService.paginationTokens(id, dto);
    }

    @Get('/:id/image')
    async readImage(@Param('id', ParseIntPipe) id: number, @Res() res) {
        const document = await this.documentService.findOne(id, ['documentImage']);

        if (!document.documentImage) {
            throw new NotFoundException();
        }
        
        // const filename = 'test-image.png';
        // const remoteFileStream = await this.ftpService.downloadImage(filename);

        const remoteFileStream = await this.documentService.downloadImage(document.documentImage.path);
        return remoteFileStream.pipe(res);

        // return res.sendFile(document.documentImage.path);
    }
}
