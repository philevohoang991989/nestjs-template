import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { BaseEntity } from 'src/shared/entity/base.entity';
import {
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    OneToMany,
    PrimaryGeneratedColumn,
} from 'typeorm';
import { DocumentImage } from './documentImage.entity';

@Entity({
    name: 'document_files',
})
export class DocumentFile extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column({
        name: 'document_set_id',
    })
    documentSetId: number;

    @ManyToOne(() => DocumentSet, (set) => set.documentFile)
    @JoinColumn({ name: 'document_set_id' })
    documentSet: DocumentSet;

    @Column({
        name: 'original_name',
    })
    originalName: string;

    @Column({
        name: 'path',
    })
    path: string;

    @OneToMany(() => DocumentImage, (doc) => doc.DocumentFiles)
    documentImage: DocumentImage[];
}
