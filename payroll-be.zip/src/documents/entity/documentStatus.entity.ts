import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Document } from './document.entity';

@Entity({
    name: 'document_statuses',
})
export class DocumentStatus {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({
        name: 'name',
    })
    name: string;

    @OneToMany(() => Document, (doc) => doc.documentStatuses)
    documents: Document[];
}

export enum EnumDocumentStatus {
    OPEN = 1,
    REQUESTED_CLASSIFY = 2,
    CLASSIFIED = 3,
    CANCEL = 4,
    DELETE = 5,
    EDIT = 6,
}
