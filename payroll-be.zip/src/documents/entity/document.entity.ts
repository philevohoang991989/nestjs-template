import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { Retrain } from 'src/retrains/entity/retrain.entity';
import { BaseEntity } from 'src/shared/entity/base.entity';
import {
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    OneToMany,
    OneToOne,
    PrimaryGeneratedColumn,
} from 'typeorm';
import { DocumentImage } from './documentImage.entity';
import { DocumentStatus } from './documentStatus.entity';
import { DocumentToken } from './documentToken.entity';
import { DocumentType } from './documentType.entity';

@Entity({
    name: 'documents',
})
export class Document extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column({
        name: 'document_set_id',
    })
    documentSetId: number;

    @ManyToOne(() => DocumentSet, (set) => set.documents)
    @JoinColumn({ name: 'document_set_id' })
    documentSet: DocumentSet;

    @OneToMany(() => DocumentToken, (doc) => doc.document)
    documentToken: DocumentToken[];

    @OneToMany(() => Retrain, (doc) => doc.documents)
    reTrains: Retrain[];

    @OneToOne(() => DocumentImage, (doc) => doc.document)
    documentImage: DocumentImage;

    @OneToMany(() => Document, (doc) => doc.documentSet)
    documents: Document[];

    @Column({
        name: 'document_type_id',
    })
    documentTypeId: number;

    @ManyToOne(() => DocumentType, (set) => set.documents)
    @JoinColumn({ name: 'document_type_id' })
    documentType: DocumentType;

    @Column({
        name: 'document_status_id',
    })
    documentStatusId: number;

    @ManyToOne(() => DocumentStatus, (set) => set.documents)
    @JoinColumn({ name: 'document_status_id' })
    documentStatuses: DocumentStatus;

    @Column({
        name: 're_train',
        default: false,
    })
    reTrain: boolean;

    @Column({
        name: 'error_type',
    })
    errorType: string;
}
