import { BaseEntity } from 'src/shared/entity/base.entity';
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Document } from './document.entity';

@Entity({
    name: 'document_types',
})
export class DocumentType extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({
        name: 'code',
        unique: true,
    })
    code: string;

    @Column({
        name: 'name',
    })
    name: string;

    @OneToMany(() => Document, (doc) => doc.documentType)
    documents: Document[];
}

export enum EnumTypes {
    INTERNAL = 1,
    EXTERNAL = 2,
}
