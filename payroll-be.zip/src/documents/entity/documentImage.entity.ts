import { BaseEntity } from 'src/shared/entity/base.entity';
import {
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    OneToMany,
    OneToOne,
    PrimaryGeneratedColumn,
} from 'typeorm';
import { DocumentFile } from './documentFile.entity';
import { Document } from './document.entity';
import { Retrain } from 'src/retrains/entity/retrain.entity';

@Entity({
    name: 'document_images',
})
export class DocumentImage extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column({
        name: 'document_id',
    })
    documentId: number;

    @OneToOne(() => Document, (set) => set.documentImage)
    @JoinColumn({ name: 'document_id' })
    document: Document;

    @Index()
    @Column({
        name: 'document_file_id',
    })
    documentFileId: number;

    @ManyToOne(() => DocumentFile, (set) => set.documentImage)
    @JoinColumn({ name: 'document_file_id' })
    DocumentFiles: DocumentFile;

    @Column({
        name: 'original_name',
    })
    originalName: string;

    @Column({
        name: 'path',
    })
    path: string;

    @Column({
        name: 'qualify',
        default: true,
    })
    qualify: boolean;

    @Column({
        name: 'rotation',
        default: 0,
    })
    rotation: number;

    @Column({
        name: 'width',
        default: 0,
    })
    width: number;

    @Column({
        name: 'height',
        default: 0,
    })
    height: number;

    @OneToMany(() => Retrain, (doc) => doc.images)
    reTrains: Retrain[];
}
