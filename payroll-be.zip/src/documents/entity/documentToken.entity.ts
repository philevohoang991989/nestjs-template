import { BaseEntity } from 'src/shared/entity/base.entity';
import {
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    OneToMany,
    PrimaryGeneratedColumn,
} from 'typeorm';
import { Document } from './document.entity';
import { DocumentValidation } from './documentValidation.entity';

@Entity({
    name: 'document_tokens',
})
export class DocumentToken extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column({
        name: 'document_id',
    })
    documentId: number;

    @ManyToOne(() => Document, (document) => document.documentToken)
    @JoinColumn({ name: 'document_id' })
    document: Document;

    @OneToMany(
        () => DocumentValidation,
        (documentValidation) => documentValidation.documentToken,
    )
    documentValidations: DocumentValidation[];

    @Column({
        name: 'data',
        type: 'jsonb',
        nullable: true,
    })
    data?: object;

    @Column({
        name: 'coordinate',
        type: 'jsonb',
        nullable: true,
    })
    coordinate?: object;
}

export enum EnumKeyOcrs {
    PAGE_NO = 'page_no',
    STT = 'number',
    NAME = 'name',
    ACC_NUM = 'account',
    CCY = 'ccy',
    DR_CR = 'drCr',
    AMOUNT = 'amount',
    BANK_NAME = 'bank',
    REMARK = 'remark',
    TOTAL_AMOUNT = 'total_amount',
}

export enum EnumCheckDocumentOcrs {
    CHI_LUONG = 'chi-luong',
    UY_NHIEM_CHI = 'uy-nhiem-chi',
    PHIEU_DE_NGHI = 'phieu-de-nghi',
    PHIEU_HACH_TOAN = 'phieu-hach-toan',
    RESULT = 'result',
}

export enum EnumDocumentSetValidationDatas {
    DR_ACCOUNT = 'dr_account',
    CR_ACCOUNT = 'cr_account',
    AMOUNT = 'amount',
    FILE_NAME = 'file_name',
    NUM_ROW = 'num_row',
    NUM_PAGE = 'num_page',
}
