import {
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
} from 'typeorm';
import { DocumentToken } from './documentToken.entity';
import { Excel } from '../../excel/entity/excel.entity';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';

@Entity({
    name: 'document_validations',
})
export class DocumentValidation {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column({
        name: 'document_set_id'
    })
    documentSetId: number;

    @ManyToOne(() => Excel, (documentSet) => documentSet.documentValidation)
    @JoinColumn({ name: 'document_set_id' })
    documentSet: DocumentSet;

    @Index()
    @Column({
        name: 'excel_id',
    })
    excelId: number;

    @ManyToOne(() => Excel, (excel) => excel.documentValidation)
    @JoinColumn({ name: 'excel_id' })
    excel: Excel;

    @Index()
    @Column({
        name: 'document_token_id',
    })
    documentTokenId: number;

    @ManyToOne(() => DocumentToken, (set) => set.documentValidations)
    @JoinColumn({ name: 'document_token_id' })
    documentToken: DocumentToken;

    @Index()
    @Column({
        name: 'is_validation',
    })
    isValidation: number;

    @Column({
        name: 'key_errors',
        type: 'jsonb',
        nullable: true,
    })
    keyErrors: any[];

    @Column({
        name: 'data',
        type: 'jsonb',
        nullable: true,
    })
    data?: object;
}
