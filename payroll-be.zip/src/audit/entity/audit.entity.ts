import { User } from 'src/users/entity/user.entity';
import {
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
} from 'typeorm';

@Entity({
    name: 'audits',
})
@Index(['entityClass', 'entityId'])
export class Audit {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({
        name: 'entity_class',
        nullable: false,
    })
    @Index()
    entityClass: string;

    @Column({
        name: 'entity_id',
        nullable: false,
    })
    entityId: string;

    @Column({
        name: 'action',
        nullable: false,
    })
    action: AuditAction;

    @Column({
        name: 'author_id',
        nullable: false,
    })
    authorId: number;

    @ManyToOne(() => User)
    @JoinColumn({
        name: 'author_id',
    })
    author: User;

    @Column({
        name: 'old_values',
        nullable: true,
    })
    oldValues: string;

    @Column({
        name: 'new_values',
        nullable: true,
    })
    newValues: string;

    @Column({
        name: 'created_at',
        type: 'timestamptz',
    })
    createdAt: Date;
}

export enum AuditAction {
    CREATE = 'Create',
    REQUESTED_CLASSIFY = 'Requested Classify',
    CLASSIFIED = 'Classified',
    UPDATE = 'Update',
    DELETE = 'Delete',
    CHANGE_PASSWORD = 'change-password',
    RUN_RULES = 'Run Rules',
    UPDATE_KEY = 'Update Key',
    UPDATE_VALUE = 'Update Value',
    DELETE_KEY = 'Delete Key',
    UPDATE_DOCUMENT_TYPE = 'Update Document Type',
    UPDATE_STATUS = 'Update Status',
    UPDATE_RESUT = 'Update Resut',
    CANCEL = 'Cancel',
    EDIT_RECORDS = 'Edit records',
}
