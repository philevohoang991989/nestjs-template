import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, DataSource, Repository } from 'typeorm';
import { Audit, AuditAction } from './entity/audit.entity';
import moment = require('moment-timezone');
import { DEFAULT_TIMEZONE } from 'src/shared/constants';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { FilterDocumentSetDTO } from 'src/document-sets/dto/filte-document-set.dto';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { Document } from 'src/documents/entity/document.entity';
import { EnumDocumentStatus } from 'src/documents/entity/documentStatus.entity';
@Injectable()
export class AuditService {
    constructor(
        @InjectRepository(DocumentSet)
        private documentSetRepository: Repository<DocumentSet>,
        @InjectRepository(Audit) private auditRepository: Repository<Audit>,
        private dataSource: DataSource,
        @InjectRepository(Document)
        private documentRepository: Repository<Document>,
    ) {
        moment.tz.setDefault(DEFAULT_TIMEZONE);
    }

    async saveAudit(oldValues: any, newValues: any, action: any, userId: number, setId: number): Promise<any> {
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        const audit = new Audit();
        audit.entityClass = newValues.constructor.name;
        if (newValues.id) {
            audit.entityId = newValues.id.toString();
        } else {
            audit.entityId = setId.toString();
            audit.entityClass = 'DocumentSet';
        }

        audit.action = action;
        audit.authorId = userId;
        audit.oldValues = JSON.stringify(oldValues);
        audit.newValues = JSON.stringify(newValues);
        await queryRunner.manager.save(audit);
        await queryRunner.commitTransaction();
    }

    async createEntity(oldValues: any, newValues: any, action: any, userId: number) {
        const audit = new Audit();
        audit.entityClass = newValues.constructor.name;
        audit.entityId = newValues.id.toString();
        audit.action = action;
        audit.authorId = userId;
        audit.oldValues = oldValues;
        audit.newValues = newValues;

        return audit;
    }

    async paginationSet(filters: FilterDocumentSetDTO, query?: FindQueryDto): Promise<any> {
        const qb = this.documentSetRepository
            .createQueryBuilder('document_sets')
            .leftJoinAndSelect('document_sets.authorCreated', 'authorCreated')
            .leftJoinAndSelect('document_sets.authorUpdated', 'authorUpdated')
            .leftJoinAndSelect('document_sets.documents', 'documents');

        if (filters.keyword) {
            qb.andWhere(
                new Brackets((sqb) => {
                    sqb.where('authorCreated.name ILIKE :keyword', {
                        keyword: `%${filters.keyword}%`,
                    })
                        .orWhere('authorUpdated.name ILIKE :keyword')
                        .orWhere('document_sets.name ILIKE :keyword')
                        .orWhere('document_sets.id::varchar(20) ILIKE :keyword');
                }),
            );
        }

		if ((!query.from && process.env.START_DATE_AUDIT_LOG && process.env.START_DATE_AUDIT_LOG != '')
            || (query.from && process.env.START_DATE_AUDIT_LOG && process.env.START_DATE_AUDIT_LOG != ''
            && (moment(query.from).diff(moment(process.env.START_DATE_AUDIT_LOG), 'day') < 0) )) {
            const startOfDay = new Date(process.env.START_DATE_AUDIT_LOG);
            startOfDay.setHours(0, 0, 0, 0);
            qb.andWhere('document_sets.createdAt >= :from', {
                from: startOfDay,
            });
        } else {
            if(query.from){
                const startOfDay = new Date(query.from);
                startOfDay.setHours(0, 0, 0, 0);
                qb.andWhere('document_sets.createdAt >= :from', {
                    from: startOfDay,
                });
            }
        }

        if (query.to) {
            const endOfDay = new Date(query.to);
            endOfDay.setHours(23, 59, 59, 999);
            qb.andWhere('document_sets.createdAt <= :to', { to: endOfDay });
        }

        if (filters.type) {
            qb.andWhere('document_sets.type = :type', {
                type: filters.type,
            });
        }

        if (query.status) {
            if (query.status == EnumDocumentStatus.EDIT) {
                qb.andWhere('document_sets.document_set_status_id = :status', {
                    status: EnumDocumentStatus.CLASSIFIED,
                }).andWhere('documents.reTrain = :reTrain', {
                    reTrain: true,
                });
            } else {
                qb.andWhere('document_sets.document_set_status_id = :status', {
                    status: query.status,
                });
            }
        } else {
            qb.andWhere('document_sets.documentSetStatusId >= :statusId', {
                statusId: 3,
            });
        }

        if (query.sort) {
            qb.orderBy(getOrderByClause(query.sort));
        } else {
            qb.orderBy('document_sets.id', 'DESC');
        }
        qb.withDeleted();

        const results = await qb
            .skip(+query.limit * (+query.page - 1))
            .take(+query.limit)
            .getManyAndCount();

        for (const iterator of results[0]) {
            if (iterator.documentSetStatusId == 3) {
                const mapReTrain = iterator.documents.map((x) => x.reTrain);
                if (mapReTrain.includes(true)) {
                    iterator.documentSetStatusId = EnumDocumentStatus.EDIT;
                }
            }
        }

        return new Pagination(results);
    }
    async findAudit(id: number): Promise<any> {
        const results = await this.auditRepository
            .createQueryBuilder('audits')
            .leftJoinAndSelect('audits.author', 'author')
            .where('audits.entityId =:entityId', { entityId: `${id}` })
            .andWhere('audits.entityClass =:entityClass', {
                entityClass: 'DocumentSet',
            })
            .orderBy('audits.id', 'ASC')
            .getManyAndCount();

        const mapDocument = await this.getMapDocuments(id);

        for (let i = 0; i < results[0].length; i++) {
            const element = results[0][i];
            if (element.action == AuditAction.EDIT_RECORDS) {
                const document = JSON.parse(element.newValues)[0];

                results[0][i]['documentTypeId'] = document.documentTypeId;
                results[0][i]['documentId'] = document.id;
                if (document.documentTypeId == 1) {
                    results[0][i]['pageEdit'] = mapDocument[document.id];
                    results[0][i]['totalPage'] = Object.keys(mapDocument).length;
                }
            }
        }
        return new Pagination(results);
    }

    async getMapDocuments(documentSetId: number): Promise<any> {
        const documents = await this.documentRepository
            .createQueryBuilder('documents')
            .andWhere('documents.documentSetId = :documentSetId', {
                documentSetId: documentSetId,
            })
            .andWhere('documents.documentTypeId = :documentTypeId', {
                documentTypeId: '1',
            })
            .orderBy('documents.id', 'ASC')
            .getMany();
        const mapDocument = {};
        for (let i = 0; i < documents.length; i++) {
            const element = documents[i];
            mapDocument[element.id] = i + 1;
        }

        return mapDocument;
    }
}
