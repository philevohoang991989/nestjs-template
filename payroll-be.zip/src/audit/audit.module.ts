import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuditService } from './audit.service';
import { Audit } from './entity/audit.entity';
import { AuditController } from './audit.controller';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { Document } from 'src/documents/entity/document.entity';

@Module({
    imports: [TypeOrmModule.forFeature([Audit, DocumentSet, Document])],
    providers: [AuditService],
    exports: [AuditService],
    controllers: [AuditController],
})
export class AuditModule {}
