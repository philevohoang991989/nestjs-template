import { RequestContext } from '@medibloc/nestjs-request-context';
import { AppRequestContext } from 'src/shared/app-request-context';
import { getManager, InsertEvent, UpdateEvent } from 'typeorm';
import { Audit, AuditAction } from '../entity/audit.entity';

export class BaseAudit {
    protected includeFields: string[] = [];
    protected excludeFields: string[] = ['createdAt', 'updatedAt', 'deletedAt'];

    listenTo(): any {
        return Audit;
    }

    afterInsert(event: InsertEvent<any>) {
        try {
            if (!event.entity) {
                return;
            }

            const authorId = this.getAuthor(event);
            if (!authorId) {
                return;
            }

            const audit = new Audit();
            audit.entityClass = this.listenTo().name;
            audit.entityId = event.entity.id.toString();
            audit.action = AuditAction.CREATE;
            audit.authorId = authorId;
            const newValues = {};
            for (const key in event.entity) {
                if (Object.prototype.hasOwnProperty.call(event.entity, key)) {
                    const value = event.entity[key];
                    if (
                        (this.includeFields.length === 0 ||
                            this.includeFields.includes(key)) &&
                        !this.excludeFields.includes(key)
                    ) {
                        newValues[key] = value;
                    }
                }
            }
            audit.newValues = JSON.stringify(newValues);

            getManager().save(audit);
        } catch (error) {
            console.log('Audit insert failed.', error);
        }
    }

    afterUpdate(event: UpdateEvent<any>) {
        try {
            if (!event.entity) {
                return;
            }

            const authorId = this.getAuthor(event);
            if (!authorId) {
                return;
            }

            const audit = new Audit();
            audit.entityClass = this.listenTo().name;
            audit.entityId = event.entity.id.toString();
            audit.action = AuditAction.UPDATE;
            audit.authorId = authorId;
            const oldValues = {};
            for (const key in event.databaseEntity) {
                if (
                    Object.prototype.hasOwnProperty.call(
                        event.databaseEntity,
                        key,
                    )
                ) {
                    const value = event.databaseEntity[key];
                    if (
                        (this.includeFields.length === 0 ||
                            this.includeFields.includes(key)) &&
                        !this.excludeFields.includes(key)
                    ) {
                        oldValues[key] = value;
                    }
                }
            }
            audit.oldValues = JSON.stringify(oldValues);

            const newValues = {};
            for (const key in event.entity) {
                if (Object.prototype.hasOwnProperty.call(event.entity, key)) {
                    const value = event.entity[key];
                    if (
                        (this.includeFields.length === 0 ||
                            this.includeFields.includes(key)) &&
                        !this.excludeFields.includes(key)
                    ) {
                        newValues[key] = value;
                    }
                }
            }
            audit.newValues = JSON.stringify(newValues);

            getManager().save(audit);
        } catch (error) {
            console.log('Audit update failed.', error);
        }
    }

    getAuthor(event?): number {
        const context: AppRequestContext = RequestContext.get();
        return context ? (context.user ? context.user.id : null) : null;
    }
}
