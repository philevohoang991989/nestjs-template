export class FindAuditDTO {
    entityClasses: string[];
    userIds: number[];
}
