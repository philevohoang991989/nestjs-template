import { MigrationInterface, QueryRunner } from 'typeorm';

export class AuditMigration1661915435399 implements MigrationInterface {
    name = 'AuditMigration1661915435399';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "public"."audits" (
                "id" SERIAL NOT NULL,
                "entity_class" character varying , 
                "entity_id" character varying , 
                "action" character varying ,    
                "author_id" integer NOT NULL,
                "old_values" character varying , 
                "new_values" character varying , 
                "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
                CONSTRAINT "PK_3ea4abf18f8ded3534a6887906d" PRIMARY KEY ("id")
            )
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "public"."audits"
        `);
    }
}
