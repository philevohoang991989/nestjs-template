import {
    Controller,
    Get,
    Inject,
    Logger,
    Param,
    ParseIntPipe,
    Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { AuditService } from './audit.service';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { FilterDocumentSetDTO } from 'src/document-sets/dto/filte-document-set.dto';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';

@ApiTags('audit')
@Controller('audit')
export class AuditController {
    constructor(
        private auditService: AuditService,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    ) {}

    @Get()
    async pagination(
        @Query(NormalizeFindQueryPipe) filters: FilterDocumentSetDTO,
        @Query(NormalizeFindQueryPipe) query: FindQueryDto,
    ) {
        return await this.auditService.paginationSet(filters, query);
    }

    @Get(':id')
    async detail(@Param('id', ParseIntPipe) id: number): Promise<any> {
        return this.auditService.findAudit(id);
    }
}
