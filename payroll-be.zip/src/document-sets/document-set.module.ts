import { StorageModule } from '@imtuanle/nest-storage';
import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientProxyFactory, KafkaOptions } from '@nestjs/microservices';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DocumentFile } from 'src/documents/entity/documentFile.entity';
import { DocumentSet } from 'src/document-sets/entity/documentSet.entity';
import { UsersModule } from 'src/users/users.module';
import { DocumentSetController } from './document-set.controller';
import { DocumentSetService } from './document-set.service';
import { AuditModule } from 'src/audit/audit.module';
import { ExcelModule } from 'src/excel/excel.module';
import { DocumentType } from 'src/documents/entity/documentType.entity';
import { Document } from 'src/documents/entity/document.entity';
import { KafkaController } from './kafka.controller';
import { DocumentsModule } from 'src/documents/documents.module';
import { DocumentValidation } from 'src/documents/entity/documentValidation.entity';
import { DocumentToken } from 'src/documents/entity/documentToken.entity';
import { Excel } from 'src/excel/entity/excel.entity';
import { DocumentSetValidation } from './entity/documentSetValidation.entity';
import { FtpsModule } from 'src/ftps/ftps.module';

@Module({
    imports: [
        TypeOrmModule.forFeature([
            DocumentSet,
            DocumentFile,
            DocumentType,
            Document,
            DocumentValidation,
            DocumentSetValidation,
            DocumentToken,
            Excel,
        ]),
        UsersModule,
        AuditModule,
        ExcelModule,
        FtpsModule,
        DocumentsModule,
        StorageModule.registerAsync({
            imports: [ConfigService],
            useFactory: (config: ConfigService) => {
                return config.get('filesystem');
            },
            inject: [ConfigService],
        }),
    ],
    controllers: [DocumentSetController, KafkaController],
    exports: [DocumentSetService],
    providers: [
        DocumentSetService,
        {
            provide: 'OCR_CORE_KAFKA',
            useFactory: (configService: ConfigService) => {
                const kafkaOptions: KafkaOptions =
                    configService.get('kafka.options');
                return ClientProxyFactory.create(kafkaOptions);
            },
            inject: [ConfigService],
        },
    ],
})
export class DocumentSetModule {}
