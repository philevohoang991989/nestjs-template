import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddIndexToDatabase1680078048471
    implements MigrationInterface
{
    name = 'AddIndexTo1680078048471';

    public async up(queryRunner: QueryRunner): Promise<void> {

        // Add the index to the "documents" table
        await queryRunner.query('CREATE INDEX idx_document_document_set_id ON "documents" (document_set_id)');

        // Add the index to the "document_set_validations" table
        await queryRunner.query('CREATE INDEX idx_document_set_validations ON "document_set_validations" ("excel_id", "document_set_id")');

        // Add the index to the "document_files" table
        await queryRunner.query('CREATE INDEX idx_document_files ON "document_files" (document_set_id)');

        // Add the index to the "document_images" table
        await queryRunner.query('CREATE INDEX idx_document_images ON "document_images" ("document_id", "document_file_id")');

        // Add the index to the "document_tokens" table
        await queryRunner.query('CREATE INDEX idx_document_tokens ON "document_tokens" (document_id)');

        // Add the index to the "document_validations" table
        await queryRunner.query('CREATE INDEX idx_document_validations ON "document_validations" ("document_set_id", "excel_id", "document_token_id", "is_validation")');
        
        // Add the index to the "excels" table
        await queryRunner.query('CREATE INDEX idx_excels ON "excels" (document_set_id)');
    }

    public async down(queryRunner: QueryRunner): Promise<void> {

        // Drop the index from the "documents" table if needed
        await queryRunner.query('DROP INDEX idx_document_document_set_id');

        // Drop the index from the "document_set_validations" table if needed
        await queryRunner.query('DROP INDEX idx_document_set_validations');

        // Drop the index from the "document_files" table if needed
        await queryRunner.query('DROP INDEX idx_document_files');

        // Drop the index from the "document_images" table if needed
        await queryRunner.query('DROP INDEX idx_document_images');

        // Drop the index from the "document_tokens" table if needed
        await queryRunner.query('DROP INDEX idx_document_tokens');

        // Drop the index from the "document_validations" table if needed
        await queryRunner.query('DROP INDEX idx_document_validations');

        // Drop the index from the "excels" table if needed
        await queryRunner.query('DROP INDEX idx_excels');
    }
}
