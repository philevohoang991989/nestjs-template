import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddExtendedDataDocumentSet1680078048472
    implements MigrationInterface {
    name = 'AddExtendedDataDocumentSet1680078048472';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_sets" ADD COLUMN "extended_data" jsonb`,
        );
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_sets" DROP COLUMN "extended_data"`,
        );
    }
}
