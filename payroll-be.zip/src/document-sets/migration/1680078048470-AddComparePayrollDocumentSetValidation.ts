import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddComparePayrollDocumentSetValidation1680078048470
    implements MigrationInterface
{
    name = 'AddComparePayrollDocumentSetValidation1680078048470';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_set_validations" ADD "compare_payroll" jsonb`,
        );

        await queryRunner.query(
            `ALTER TABLE "document_set_validations" ADD "coordinates" jsonb`,
        );
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_set_validations" DROP COLUMN "compare_payroll"`,
        );

        await queryRunner.query(
            `ALTER TABLE "document_set_validations" DROP COLUMN "coordinates"`,
        );
    }
}
