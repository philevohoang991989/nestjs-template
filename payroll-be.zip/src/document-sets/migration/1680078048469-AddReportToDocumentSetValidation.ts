import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddReportToDocumentSetValidation1680078048469
    implements MigrationInterface
{
    name = 'AddReportToDocumentSetValidation1680078048469';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_set_validations" ADD "report" jsonb`,
        );
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_set_validations" DROP COLUMN "report"`,
        );
    }
}
