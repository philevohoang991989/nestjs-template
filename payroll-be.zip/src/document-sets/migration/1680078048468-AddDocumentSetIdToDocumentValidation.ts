import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddDocumentSetIdToDocumentValidation1680078048468
    implements MigrationInterface
{
    name = 'AddDocumentSetIdToDocumentValidation1680078048468';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_validations" ADD "document_set_id" integer NULL`,
        );
        await queryRunner.query(
            `ALTER TABLE "document_validations" ADD CONSTRAINT "FK_af0fddaa53d0a9bfc00bd7d44a7" FOREIGN KEY ("document_set_id") REFERENCES "document_sets"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
        );
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "document_validations" DROP CONSTRAINT "FK_af0fddaa53d0a9bfc00bd7d44a7"`,
        );
        await queryRunner.query(
            `ALTER TABLE "document_validations" DROP COLUMN "document_set_id"`,
        );
    }
}
