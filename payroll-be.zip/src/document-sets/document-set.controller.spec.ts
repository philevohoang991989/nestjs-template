import { Test, TestingModule } from '@nestjs/testing';
import { DocumentSetController } from './document-set.controller';

describe('DocumentSetController', () => {
    let controller: DocumentSetController;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [DocumentSetController],
        }).compile();

        controller = module.get<DocumentSetController>(DocumentSetController);
    });

    it('should be defined', () => {
        expect(controller).toBeDefined();
    });
});
