import { Controller, HttpException, HttpStatus, Inject, Logger } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { Ctx, EventPattern, KafkaContext, Payload, RpcException } from '@nestjs/microservices';
import { DocumentsService } from 'src/documents/documents.service';
import { DocumentSetService } from './document-set.service';
import { ExcelService } from 'src/excel/excel.service';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { FtpsService } from 'src/ftps/ftps.service';

ConfigModule.forRoot({
    isGlobal: true,
});

@Controller('kafka')
export class KafkaController {
    constructor(
        private documentSetService: DocumentSetService,
        private documentService: DocumentsService,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
    ) {}

    @EventPattern(process.env.TOPIC_KAFKA_RESPONSE_CONVERT)
    async handleResponseConvert(@Payload() data) {
        try {
            this.logger.log('Starting receive response pdf convert - ' + (data?.id ?? ''), 'PROFILING');
            await this.documentService.createDocumentByImages(data);
            await this.documentSetService.requestOcrClassify(data.id);
            this.logger.log('End receive response pdf convert - ' + (data?.id ?? ''), 'PROFILING');
        } catch (error) {
            this.logger.error('Error(handleResponseConvert): ' + (data?.id ?? '') + ' - ' + error.message, 'PROFILING');
            this.logger.error(error);
            throw error;
        }
    }
}
