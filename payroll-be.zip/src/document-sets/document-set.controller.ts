import {
    BadRequestException,
    Body,
    ClassSerializerInterceptor,
    Controller,
    Delete,
    Get,
    Header,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Req,
    Res,
    UploadedFiles,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { DocumentsService } from 'src/documents/documents.service';
import { ExcelService } from 'src/excel/excel.service';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { NormalizeFindQueryPipe } from 'src/shared/pipes/normalize-find-query.pipe';
import { DocumentSetService } from './document-set.service';
import { CreateDocumentSetDto } from './dto/create-document-set.dto';
import { FilterDocumentSetDTO } from './dto/filte-document-set.dto';
import { DocumentSet } from './entity/documentSet.entity';

@ApiTags('document-sets')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
@Controller('document-sets')
export class DocumentSetController {
    constructor(
        private documentSetService: DocumentSetService,
        private documentService: DocumentsService,
        private excelSetService: ExcelService,
    ) {}

    @ApiBody({ type: CreateDocumentSetDto })
    @ApiConsumes('multipart/form-data')
    @Post()
    @UseInterceptors(FileFieldsInterceptor([{ name: 'files' }, { name: 'fileExcel', maxCount: 1 }]))
    async create(
        @Body() dto: CreateDocumentSetDto,
        @Req() req,
        @UploadedFiles()
        importFliles: {
            files?: Express.Multer.File[];
            fileExcel?: Express.Multer.File;
        },
    ): Promise<any> {
        try {
            dto.files = importFliles.files;
            dto.fileExcel = importFliles.fileExcel;
            const result = await this.documentSetService.create(dto, req.user.userId);

            //     await this.documentService.sendPdfConvert(result.id);

            return result;
        } catch (error) {
            throw new BadRequestException(error.message);
        }
    }

    @Get()
    @UseInterceptors(ClassSerializerInterceptor)
    async pagination(
        @Query(NormalizeFindQueryPipe) filters: FilterDocumentSetDTO,
        @Query(NormalizeFindQueryPipe) query: FindQueryDto,
    ) {
        return await this.documentSetService.paginationSet(filters, query);
    }

    @Get('export-set')
    @Header('Content-disposition', 'attachment; filename=report.xlsx')
    async exportSetExcel(
        @Query(NormalizeFindQueryPipe) filters: FilterDocumentSetDTO,
        @Query(NormalizeFindQueryPipe) query: FindQueryDto,
        @Res() response,
    ): Promise<any> {
        try {
            const file = await this.excelSetService.exportSetExcel(filters, query, response);
            response.contentType('application/vnd.ms-excel');
            response.send(file);
        } catch (e) {
            throw new BadRequestException(e.message);
        }
    }

    @Put(':id/cancel')
    @UseInterceptors(ClassSerializerInterceptor)
    async cancel(@Param('id', ParseIntPipe) id: number, @Req() req): Promise<any> {
        return await this.documentSetService.cancel(id, req.user.userId);
    }

    @Get(':id')
    @UseInterceptors(ClassSerializerInterceptor)
    async detail(@Param('id', ParseIntPipe) id: number): Promise<DocumentSet> {
        return this.documentSetService.findOne(id, [
            'documents',
            'documents.documentImage',
            'documents.documentType',
            'authorCreated',
            'authorUpdated',
        ]);
    }

    @Delete('/:id')
    async deleteDocumentSet(@Param('id') id: number, @Req() req) {
        return await this.documentSetService.deleteDocumentSet(+id, req.user.userId);
    }

    @Delete('/:id/remove')
    async removeDocumentSet(@Param('id') id: number): Promise<DocumentSet> {
        return await this.documentSetService.remove(id);
    }

    @Get(':id/ocr-result')
    @UseInterceptors(ClassSerializerInterceptor)
    async ocrResult(@Param('id', ParseIntPipe) id: number) {
        return await this.documentSetService.getOcrResult(id);
    }

    @Get(':id/export-excel')
    @Header('Content-disposition', 'attachment; filename=chiluong.xlsx')
    async exportExcel(@Param('id') id: number, @Res() response): Promise<any> {
        try {
            const file = await this.excelSetService.exportExcel(id, response);
            response.contentType('application/vnd.ms-excel');
            response.send(file);
        } catch (e) {
            throw new BadRequestException(e.message);
        }
    }
}
