import { Excel } from 'src/excel/entity/excel.entity';
import {
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
} from 'typeorm';
import { DocumentSet } from './documentSet.entity';

@Entity({
    name: 'document_set_validations',
})
export class DocumentSetValidation {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column({
        name: 'excel_id',
    })
    excelId: number;

    @ManyToOne(() => Excel, (set) => set.documentSetValidation)
    @JoinColumn({ name: 'excel_id' })
    excel: Excel;

    @Index()
    @Column({
        name: 'document_set_id',
    })
    documentSetId: number;

    @ManyToOne(() => DocumentSet, (set) => set.documentSetValidation)
    @JoinColumn({ name: 'document_set_id' })
    documentSet: DocumentSet;

    @Column({
        name: 'is_validation',
    })
    isValidation: number;

    @Column({
        name: 'key_errors',
        type: 'jsonb',
        nullable: true,
    })
    keyErrors: object;

    @Column({
        name: 'data',
        type: 'jsonb',
        nullable: true,
    })
    data?: object;

    @Column({
        name: 'report',
        type: 'jsonb',
        nullable: true,
    })
    report?: object;

    @Column({
        name: 'compare_payroll',
        type: 'jsonb',
        nullable: true,
    })
    comparePayroll?: object;

    @Column({
        name: 'coordinates',
        type: 'jsonb',
        nullable: true,
    })
    coordinates?: object;
}
