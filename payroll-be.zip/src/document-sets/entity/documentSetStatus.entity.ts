import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
    name: 'document_set_statuses',
})
export class DocumentSetStatus {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({
        name: 'name',
    })
    name: string;
}

export enum EnumDocumentSetStatus {
    OPEN = 1,
    REQUESTED_CLASSIFY = 2,
    CLASSIFIED = 3,
    CANCEL = 4,
    DELETED = 5,
}

export enum EnumDocumentSetStatusText {
    OPEN = 'Khởi tạo',
    REQUESTED_CLASSIFY = 'Gửi yêu cầu',
    CLASSIFIED = 'Hoàn thành',
    CANCEL = 'Đã huỷ',
    DELETED = 'Đã xóa',
}
