import { BaseEntity } from 'src/shared/entity/base.entity';
import {
    Column,
    Entity,
    JoinColumn,
    ManyToOne,
    OneToMany,
    PrimaryGeneratedColumn,
} from 'typeorm';
import { Document } from '../../documents/entity/document.entity';
import { Exclude, Expose } from 'class-transformer';
import { Excel } from '../../excel/entity/excel.entity';
import { DocumentFile } from '../../documents/entity/documentFile.entity';
import { DocumentSetStatus } from './documentSetStatus.entity';
import { DocumentSetValidation } from './documentSetValidation.entity';
import { User } from 'src/users/entity/user.entity';
import { filter } from 'lodash';
import { EnumDocumentStatus } from 'src/documents/entity/documentStatus.entity';
import { DocumentValidation } from 'src/documents/entity/documentValidation.entity';

@Entity({
    name: 'document_sets',
})
export class DocumentSet extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({
        name: 'document_set_status_id',
    })
    documentSetStatusId: number;

    @ManyToOne(() => DocumentSetStatus)
    @JoinColumn({ name: 'document_set_status_id' })
    documentSetStatus: DocumentSetStatus;

    @OneToMany(() => Document, (doc) => doc.documentSet)
    documents: Document[];

    @OneToMany(() => Excel, (doc) => doc.documentSet)
    excels: Excel[];

    @OneToMany(() => DocumentFile, (doc) => doc.documentSet)
    documentFile: DocumentFile[];

    @OneToMany(() => DocumentSetValidation, (set) => set.documentSet)
    documentSetValidation: DocumentSetValidation[];

    @OneToMany(() => DocumentSetValidation, (set) => set.documentSet)
    documentValidation: DocumentValidation[];

    @Exclude()
    documentCount?: number;
    @Expose({ name: 'documentCount' })
    getDocumentCount() {
        return this.documentCount ?? this.documents?.length;
    }

    @Exclude()
    documentClassyfied: number;
    @Expose({ name: 'documentClassyfied' })
    getDocumentClassyfied() {
        if (this.documentClassyfied) {
            return this.documentClassyfied;
        }

        return filter(this.documents, (item) => {
            return item.documentStatusId == EnumDocumentStatus.CLASSIFIED;
        }).length;
    }

    @Column({
        name: 'name',
    })
    name: string;

    @Column({
        name: 'type',
    })
    type: number;

    @Column({
        name: 'created_by',
    })
    createdBy: number;

    @ManyToOne(() => User)
    @JoinColumn({ name: 'created_by' })
    authorCreated: User;

    @Column({
        name: 'updated_by',
    })
    updatedBy: number;

    @ManyToOne(() => User)
    @JoinColumn({ name: 'updated_by' })
    authorUpdated: User;

    @Column({
        name: 'extended_data',
        type: 'jsonb',
        nullable: true,
    })
    extendedData?: object;
}

export enum EnumDocumentSetType {
    TYPE_INTERNAL = 0,
    TYPE_EXTERNAL = 1,
}
