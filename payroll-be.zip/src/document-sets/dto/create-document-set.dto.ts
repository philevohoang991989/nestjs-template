import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsOptional } from 'class-validator';
import { ApiFile } from 'src/shared/decorator/api-file.decorator';

export class CreateDocumentSetDto {
    @ApiPropertyOptional()
    @IsOptional()
    @IsNumber()
    name?: string;

    @ApiPropertyOptional()
    @IsOptional()
    @IsNumber()
    type?: number;

    @ApiFile({ isArray: true })
    files: Express.Multer.File[];

    @ApiFile()
    fileExcel: Express.Multer.File;
}
