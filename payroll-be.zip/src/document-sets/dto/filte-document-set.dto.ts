import { ApiPropertyOptional } from '@nestjs/swagger';

export class FilterDocumentSetDTO {
    @ApiPropertyOptional()
    keyword: string;

    @ApiPropertyOptional()
    type: number;
}
