import { Test, TestingModule } from '@nestjs/testing';
import { DocumentSetService } from './document-set.service';

describe('DocumentSetService', () => {
    let service: DocumentSetService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [DocumentSetService],
        }).compile();

        service = module.get<DocumentSetService>(DocumentSetService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });
});
