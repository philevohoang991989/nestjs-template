import { BadRequestException, Logger, Inject, Injectable } from '@nestjs/common';
import { Storage } from '@imtuanle/nest-storage';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Repository, DataSource, Not, IsNull } from 'typeorm';
import { DocumentFile } from 'src/documents/entity/documentFile.entity';
import { CreateDocumentSetDto } from 'src/document-sets/dto/create-document-set.dto';
import { EnumDocumentSetStatus } from 'src/document-sets/entity/documentSetStatus.entity';
import { ClientKafka, Ctx, KafkaContext } from '@nestjs/microservices';
import { DocumentSet, EnumDocumentSetType } from './entity/documentSet.entity';
import { AuditAction } from 'src/audit/entity/audit.entity';
import { AuditService } from 'src/audit/audit.service';
import { FilterDocumentSetDTO } from './dto/filte-document-set.dto';
import { FindQueryDto } from 'src/shared/dto/find-query.dto';
import { getOrderByClause } from 'src/shared/helpers/query-sort.helper';
import { Pagination } from 'src/shared/dto/pagination.dto';
import { ExcelService } from 'src/excel/excel.service';
import { Document } from 'src/documents/entity/document.entity';
import { EnumDocumentStatus } from 'src/documents/entity/documentStatus.entity';
import { DocumentType } from 'src/documents/entity/documentType.entity';
import { find, keyBy } from 'lodash';
import { DocumentToken, EnumCheckDocumentOcrs, EnumKeyOcrs } from 'src/documents/entity/documentToken.entity';
import { DocumentValidation } from 'src/documents/entity/documentValidation.entity';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { DocumentSetValidation } from './entity/documentSetValidation.entity';
import { convertStrToNumber } from 'src/shared/helpers/number';
import { accentsTidy } from 'src/shared/helpers/accents-tidy';
import { ERROR_CODE } from 'src/shared/constants/common.constant';
import { Excel } from 'src/excel/entity/excel.entity';
import { EnumTypes } from 'src/documents/entity/documentType.entity';
import { log } from 'console';
import { of } from 'rxjs';
import { DocumentImage } from 'src/documents/entity/documentImage.entity';
import { FtpsService } from 'src/ftps/ftps.service';

@Injectable()
export class DocumentSetService {
    constructor(
        @InjectRepository(DocumentSet)
        private documentSetRepository: Repository<DocumentSet>,
        @InjectRepository(Excel)
        private excelRepository: Repository<Excel>,
        @InjectRepository(Document)
        private documentRepository: Repository<Document>,
        @InjectRepository(DocumentType)
        private documentTypeRepository: Repository<DocumentType>,
        @InjectRepository(DocumentFile)
        private documentFileRepository: Repository<DocumentFile>,

        @InjectRepository(DocumentValidation)
        private documentValidationRepository: Repository<DocumentValidation>,
        @InjectRepository(DocumentSetValidation)
        private documentSetValidationRepository: Repository<DocumentSetValidation>,
        @InjectRepository(DocumentToken)
        private documentTokenRepository: Repository<DocumentToken>,
        @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: Logger,
        @Inject('OCR_CORE_KAFKA') private client: ClientKafka,
        private dataSource: DataSource,
        private excelService: ExcelService,
        private auditService: AuditService,
        private ftpService: FtpsService,
    ) {}

    async create(dto: CreateDocumentSetDto, userId: number): Promise<any> {
        let documentSetCreate = null;
        this.logger.log('Starting to create document set', 'PROFILING');

        const queryRunner = this.dataSource.createQueryRunner();

        this.logger.log('Starting queryRunner.connect', 'PROFILING');
        await queryRunner.connect();
        this.logger.log('queryRunner.connect Success', 'PROFILING');

        this.logger.log('Starting startTransaction', 'PROFILING');
        await queryRunner.startTransaction();
        this.logger.log('startTransaction Success', 'PROFILING');

        try {
            const documentSet = new DocumentSet();
            documentSet.name = dto.name;
            documentSet.type = dto.type;
            documentSet.createdBy = userId;
            documentSet.updatedBy = userId;
            documentSet.documentSetStatusId = EnumDocumentSetStatus.OPEN;
            documentSet.extendedData = { "fileExcel": dto.fileExcel[0] ? dto.fileExcel[0].originalname ? dto.fileExcel[0].originalname : '' : '' };

            this.logger.log('Start save documentSet', 'PROFILING');
            documentSetCreate = await queryRunner.manager.save(documentSet);
            this.logger.log('End save documentSet', 'PROFILING');

            if (!dto.files || dto.files.length == 0) {
                throw new BadRequestException('File not found');
            }

            this.logger.log('Start file upload & create document file', 'PROFILING');

            const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');

            const folder = '/' + date + `/${documentSet.id}/`;

            const folderNameFiles = folder + `files/`;
            const object = ['excels', 'images', 'OCR_result'];

            await this.ftpService.createFolder(folder + 'files');

            const myTimeout = setTimeout(() => {
                callPause(folder, object, dto, folderNameFiles, documentSetCreate);
            }, 5000);

            const callPause = async (folder, object, dto, folderNameFiles, documentSetCreate) => {
                await this.createSubFolderAndFile(folder, object, dto, folderNameFiles, documentSetCreate);
                clearTimeout(myTimeout);
            };

            this.logger.log('End file upload & create document file', 'PROFILING');

            // Create excel
            this.logger.log('Starting to Validate excel - readPayrollExcel', 'PROFILING');

            const excels = await this.excelService.readPayrollExcel(
                dto.fileExcel[0],
                documentSetCreate.id,
                documentSetCreate.type,
            );
            this.logger.log('End process validate excel - readPayrollExcel', 'PROFILING');

            if (excels.length == 0) {
                throw new BadRequestException('Invalid excel file');
            }

            this.logger.log('Start save Excel data', 'PROFILING');
            queryRunner.manager.insert(Excel, excels);
            this.logger.log('End save Excel data', 'PROFILING');

            // Create audit
            this.logger.log('Start save Audit log', 'PROFILING');
            const audit = await this.auditService.createEntity([], documentSetCreate, AuditAction.CREATE, userId);
            queryRunner.manager.save(audit);
            this.logger.log('End save Audit Log', 'PROFILING');

            await queryRunner.commitTransaction();
            this.logger.log('End created document set', 'PROFILING');

            return documentSetCreate;
        } catch (err) {
            this.logger.error('Error create DocumentSet: ' + err.message, 'PROFILING');
            this.logger.error(err);
            // since we have errors let's rollback changes we made
            await queryRunner.rollbackTransaction();
            throw err;
        } finally {
            await queryRunner.release();
        }
    }

    async delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    async createSubFolderAndFile(folder, object, dto, folderNameFiles, documentSetCreate) {
        const documentSet = await this.documentSetRepository.findOne({
            where: { id: documentSetCreate.id },
        });

        if (documentSet && documentSet.id) {
            for (let i = 0; i < object.length; i++) {
                const iterator = object[i];

                await this.ftpService.createSubfolder(folder, iterator);
            }

            for (let j = 0; j < dto.files.length; j++) {
                const file = dto.files[j];
                if (j == dto.files.length - 1) {
                    await this.ftpService.uploadPdfToFolderEnd(
                        file.buffer,
                        folderNameFiles,
                        file.originalname,
                        documentSetCreate,
                    );
                } else {
                    await this.ftpService.uploadPdfToFolder(
                        file.buffer,
                        folderNameFiles,
                        file.originalname,
                        documentSetCreate,
                    );
                }
                const documentFile = new DocumentFile();

                documentFile.documentSetId = documentSetCreate.id;

                documentFile.originalName = file.originalname;

                documentFile.path = folderNameFiles + file.originalname;

                this.logger.log('Start save documentFile', 'PROFILING');

                await this.documentFileRepository.save(documentFile);

                this.logger.log('End save documentFile', 'PROFILING');

                await this.delay(3000);
            }

            if (dto.fileExcel[0]) {
                const folderNameExcel = folder + `excels/`;

                const myTimeout = setTimeout(() => {
                    callPause(dto);
                }, 5000);

                const callPause = async (dto) => {
                    await this.ftpService.uploadExcelToFolder(
                        dto.fileExcel[0].buffer,

                        folderNameExcel,

                        dto.fileExcel[0].originalname,
                    );

                    clearTimeout(myTimeout);
                };
            }
        }
    }

    async requestOcrClassify(documentSetId: number) {
        this.logger.log('Start process to send requestOcrClassify', 'PROFILING');

        const documentSet = await this.documentSetRepository.findOne({
            where: { id: documentSetId },
            relations: ['documents', 'documents.documentImage'],
        });

        if (!documentSet) {
            return 'Wrong document set';
            //throw new BadRequestException('No document to classify');
        }

        if (documentSet.documentSetStatusId !== EnumDocumentSetStatus.OPEN) {
            return 'NOTOPEN';
            //throw new BadRequestException('Document set is not open: ' + documentSet.id + '/' +documentSet.documentSetStatusId);
        }

        if (documentSet.documents.length == 0) {
            throw new BadRequestException('Document set does not have document to classify');
        }

        const payload: any = {
            id: documentSetId,
            type: documentSet.type,
            files: [],
        };

        for (const i in documentSet.documents) {
            documentSet.documents[i].documentStatusId = EnumDocumentSetStatus.REQUESTED_CLASSIFY;
            const image = documentSet.documents[i].documentImage;

            if (image) {
                payload.files.push({
                    documentId: documentSet.documents[i].id,
                    filePath: image.path,
                });
            }
        }

        if (!payload.files.length) {
            throw new BadRequestException('Document set does not have image file to classify');
        }

        const queryRunner = this.dataSource.createQueryRunner();

        this.logger.log('Starting queryRunner.connect', 'PROFILING');
        await queryRunner.connect();
        this.logger.log('queryRunner.connect Success', 'PROFILING');

        this.logger.log('Starting startTransaction', 'PROFILING');
        await queryRunner.startTransaction();
        this.logger.log('startTransaction Success', 'PROFILING');

        try {
            this.logger.log('Start save Document', 'PROFILING');
            await queryRunner.manager.save(documentSet.documents);
            this.logger.log('End save Document', 'PROFILING');

            documentSet.documentSetStatusId = EnumDocumentSetStatus.REQUESTED_CLASSIFY;

            this.logger.log('Start save update documentSet', 'PROFILING');
            const data = await queryRunner.manager.save(documentSet);
            this.logger.log('End save update documentSet', 'PROFILING');

            await queryRunner.commitTransaction();

            delete documentSet.documentValidation;
            delete documentSet.documentSetValidation;
            delete documentSet.excels;
            delete documentSet.documentFile;
            delete documentSet.documents;

            this.logger.log('Send requestOcrClassify to AI', 'PROFILING');
            this.client.emit(process.env.TOPIC_KAFKA_PAYROLL_REQUEST, payload);

            this.logger.log('Start Save Audit Log', 'PROFILING');
            this.auditService.saveAudit(
                documentSet,
                documentSet,
                AuditAction.REQUESTED_CLASSIFY,
                documentSet.updatedBy,
                documentSet.id,
            );
            this.logger.log('End Save Audit Log', 'PROFILING');
            return data;
        } catch (err) {
            this.logger.error('Error requestOcrClassify: ' + err.message, 'PROFILING');
            this.logger.error(err);
            await queryRunner.rollbackTransaction();
            throw err;
        } finally {
            await queryRunner.release();
        }
    }

    async paginationSet(filters: FilterDocumentSetDTO, query?: FindQueryDto): Promise<any> {
        const qb = this.documentSetRepository
            .createQueryBuilder('document_sets')
            .leftJoinAndSelect('document_sets.authorCreated', 'authorCreated')
            .leftJoinAndSelect('document_sets.authorUpdated', 'authorUpdated')
            .leftJoinAndSelect('document_sets.documents', 'documents')
            .leftJoinAndSelect('documents.documentImage', 'documentImage');

        if (filters.keyword) {
            qb.andWhere(
                new Brackets((sqb) => {
                    sqb.where('authorCreated.name ILIKE :keyword', {
                        keyword: `%${filters.keyword}%`,
                    })
                        .orWhere('authorUpdated.name ILIKE :keyword')
                        .orWhere('document_sets.name ILIKE :keyword')
                        .orWhere('document_sets.id::varchar(20) ILIKE :keyword');
                }),
            );
        }

        if (query.from) {
            const startOfDay = new Date(query.from);
            startOfDay.setHours(0, 0, 0, 0);

            qb.andWhere('document_sets.createdAt >= :from', {
                from: startOfDay,
            });
        }

        if (query.to) {
            const endOfDay = new Date(query.to);
            endOfDay.setHours(23, 59, 59, 999);
            qb.andWhere('document_sets.createdAt <= :to', { to: endOfDay });
        }

        if (filters.type) {
            qb.andWhere('document_sets.type = :type', {
                type: filters.type,
            });
        }

        if (query.status) {
            qb.andWhere('document_sets.document_set_status_id = :status', {
                status: query.status,
            });
        }

        if (query.sort) {
            qb.orderBy(getOrderByClause(query.sort));
        } else {
            qb.orderBy('document_sets.id', 'DESC');
        }

        const results = await qb
            .skip(+query.limit * (+query.page - 1))
            .take(+query.limit)
            .getManyAndCount();

        return new Pagination(results);
    }

    async findOne(id: number, relations: string[] = ['documents', 'documents.documentFile']): Promise<DocumentSet> {
        const documentSetRepository = this.dataSource.getRepository(DocumentSet);

        const documentSet = await documentSetRepository.findOne({
            where: { id },
            relations,
        });

        if (!documentSet) {
            throw new BadRequestException('Document set does not exist');
        }

        return documentSet;
    }

    async deleteDocumentSet(id: number, userId: number): Promise<any> {
        this.logger.log('Start deleteDocumentSet: ' + id, 'PROFILING');
        const documentSet = await this.documentSetRepository
            .createQueryBuilder('document_sets')
            .andWhere('document_sets.id = :id', { id: id })
            .getOne();

        if (!documentSet) {
            throw new BadRequestException('Document set does not exist');
        }
        documentSet.documentSetStatusId = EnumDocumentSetStatus.DELETED;
        await this.documentSetRepository.save(documentSet);
        const payload = await this.documentSetRepository.softDelete(documentSet.id);

        const documentSetDelete = await this.documentSetRepository.findOne({
            where: {
                id: documentSet.id,
            },
            withDeleted: true,
        });

        delete documentSet.documentValidation;
        delete documentSet.documentSetValidation;
        delete documentSet.excels;
        delete documentSet.documentFile;
        delete documentSet.documents;

        delete documentSetDelete.documentValidation;
        delete documentSetDelete.documentSetValidation;
        delete documentSetDelete.excels;
        delete documentSetDelete.documentFile;
        delete documentSetDelete.documents;

        this.auditService.saveAudit(documentSet, documentSetDelete, AuditAction.DELETE, userId, documentSet.id);
        this.logger.log('End deleteDocumentSet: ' + documentSet.id, 'PROFILING');

        return documentSetDelete;
    }

    async remove(id: number): Promise<any> {
        const set = await this.documentSetRepository.findOne({
            where: {
                id: id,
                deletedAt: Not(IsNull()),
            },
            withDeleted: true
        });

        if (set) {
            const queryRunner = this.dataSource.createQueryRunner();
            await queryRunner.connect();
            await queryRunner.startTransaction();

            try {
                await queryRunner.query(
                `DELETE FROM document_validations WHERE document_set_id='${set.id}';
                DELETE FROM document_set_validations WHERE document_set_id='${set.id}';
                DELETE FROM excels  WHERE document_set_id='${set.id}';
                DELETE FROM document_tokens WHERE document_id IN (SELECT id FROM documents where documents.document_set_id = '${set.id}');
                DELETE FROM document_images  WHERE document_id IN (SELECT id FROM documents where documents.document_set_id = '${set.id}');
                DELETE FROM documents  WHERE document_set_id='${set.id}';
                DELETE FROM document_files  WHERE document_set_id='${set.id}';
                DELETE FROM document_sets WHERE id='${set.id}';`,
                );
                await queryRunner.commitTransaction();
                return "Success";

            } catch (err) {
        
                this.logger.error(err);
                await queryRunner.rollbackTransaction();
                throw err;
            } finally {
                await queryRunner.release();
            }
        }
        return "Documentset invalid status";
    }
    
    async handleUpdateDocumentErr(dto) {
        const ids = dto.files.map((file) => file.documentId);

        const documents = await this.documentRepository
            .createQueryBuilder('documents')
            .where('documents.id IN (:...ids)', { ids: ids })
            .getMany();

        for (const iterator of dto.files) {
            for (let i = 0; i < documents.length; i++) {
                const document = documents[i];
                if (document.id == iterator.documentId) {
                    document.errorType = iterator.error_type;
                }
            }
        }
        this.documentRepository.save(documents);
    }

    async handleDocumentClassifyProcess(dto) {
        console.log(dto);

        if (dto.status == 'DONE DU') {
            this.logger.log('Start query document', 'PROFILING');
            const document = await this.documentRepository.findOne({
                where: { id: dto.doneDocumentId },
            });
            console.log(document);
            this.logger.log('End query document', 'PROFILING');

            if (document && document.documentStatusId && document.documentStatusId != null) {
                document.documentStatusId = EnumDocumentStatus.CLASSIFIED;
                this.logger.log('Start save Status Document to Classified', 'PROFILING');
                this.documentRepository.save(document);
                this.logger.log('End save Status Document to Classified', 'PROFILING');
            }
        }

        this.logger.log('End receive response OCR Process from AI', 'PROFILING');
    }

    compareExcelvsToken(excelData: object = {}, tokenData: object = {}): Array<string | number> {
        this.logger.debug('Start compareExcelvsToken');
        const keyErrors: Array<string | number> = [];

        for (const key in excelData) {
            switch (key) {
                case EnumKeyOcrs.STT:
                    continue;
                case EnumKeyOcrs.CCY:
                    if (
                        !!excelData[key] &&
                        !!tokenData[key] &&
                        accentsTidy(excelData[key]?.toString()) != accentsTidy(tokenData[key]?.toString())
                    ) {
                        keyErrors.push(key);
                    }
                    continue;
                default:
                    if (!excelData[key] || !tokenData[key]) {
                        keyErrors.push(key);
                        continue;
                    }
                    let valueExcel: any = accentsTidy(excelData[key]?.toString());
                    let valuetoken: any = accentsTidy(tokenData[key]?.toString());
                    if (key == EnumKeyOcrs.AMOUNT) {
                        valueExcel = convertStrToNumber(valueExcel);
                        valuetoken = convertStrToNumber(valuetoken);
                    }
                    if (valueExcel != valuetoken) {
                        keyErrors.push(key);
                    }
            }
        }
        this.logger.debug('End compareExcelvsToken');

        return keyErrors;
    }

    transformDocumentToken(
        processedData: { string: object },
        documentId: number,
        documentType: string,
    ): [DocumentToken[], number] {
        this.logger.debug('Start transformDocumentToken', `Document ${documentId}`);
        let documentTokens: DocumentToken[] = [];
        let formatedData = {};
        let itemCount = 0; // number items of documentTokens
        let drAmount: any;
        //sanitize and format data
        for (const [key, value] of Object.entries(processedData)) {
            formatedData[key] = []; // [{data:"",coordinate:[]}]
            if (!value || !(value as any)?.words || !Array.isArray((value as any)?.words)) {
                this.logger.log('Empty or undefined Words', 'PROFILING');
                continue;
            }
            const convertedValue = value as any;
            // array `words` and  `boxes` have the same length
            for (const i in convertedValue?.words) {
                let data = convertedValue?.words[i] ?? '';
                let coordinate = convertedValue?.boxes[i] ?? '';
                switch (key) {
                    case EnumKeyOcrs.TOTAL_AMOUNT:
                        drAmount = data;
                        continue;
                    case EnumKeyOcrs.AMOUNT:
                        data = data.replace(/\,/g, '').replace(/\./g, '');
                        break;
                    default:
                        break;
                }
                // DocumentToken format if != chi-luong
                if (documentType != EnumCheckDocumentOcrs.CHI_LUONG) {
                    const documentToken: any = {};
                    documentToken.documentId = documentId;
                    documentToken.data = {};
                    documentToken.coordinate = {};
                    documentToken.data[key] = data;
                    documentToken.coordinate[key] = coordinate;
                    documentTokens.push(documentToken);
                    continue;
                }

                formatedData[key].push({ data, coordinate });
            }

            itemCount = itemCount < formatedData[key].length ? formatedData[key].length : itemCount;
        }

        // transform to DocumentToken (for chi-luong only)
        for (let i = 0; i < itemCount; i++) {
            const documentToken = new DocumentToken();
            documentToken.documentId = documentId;
            documentToken.data = {};
            documentToken.coordinate = {};

            for (const [key, value] of Object.entries(formatedData)) {
                documentToken.data[key] = value[i]?.data ?? '';
                documentToken.coordinate[key] = value[i]?.coordinate ?? [];
            }
            documentTokens.push(documentToken);
        }
        this.logger.debug('End transformDocumentToken', `Document ${documentId}`);

        return [documentTokens, drAmount];
    }

    // Transforms a list of document tokens into a list of document validation objects. This is the inverse of transformDocument
    async transformDocumentValidation(excels: Excel[], documentTokens: DocumentToken[], documentSetId: number) {
        this.logger.debug('Start transformDocumentValidation', `DocumentSet ${documentSetId ?? 0}`);
        const documentValidations: DocumentValidation[] = [];
        const checkAccoutFails = [];

        const listAccountInExcels = excels
            .filter((v) => {
                return !!(v?.data as any)?.account;
            })
            .map((v) => {
                return accentsTidy((v as any).data.account.toString());
            });

        for (const excel of excels) {
            const excelData: any = excel?.data ?? {};
            const documentToken = find(documentTokens, (item) => {
                const documentTokenData: any = item.data ?? {};
                const tokenAccount = accentsTidy((documentTokenData?.account ?? '').toString());
                const tokenName = accentsTidy((documentTokenData?.name ?? '').toString());
                const tokenAmount = convertStrToNumber(accentsTidy((documentTokenData?.amount ?? '').toString()));

                const excelName = accentsTidy((excelData?.name ?? '').toString());
                const excelAmount = convertStrToNumber(accentsTidy((excelData?.amount ?? '').toString()));
                return (
                    accentsTidy((excelData?.account ?? '').toString()) == tokenAccount ||
                    (!listAccountInExcels.includes(tokenAccount) &&
                        !!tokenName &&
                        !!tokenAmount &&
                        !!excelName &&
                        !!excelAmount &&
                        tokenName == excelName)
                        // remove check amount
                        // && tokenAmount == excelAmount)
                );
            });
            if (!documentToken) {
                checkAccoutFails.push(excel);
                continue;
            }

            documentTokens = documentTokens.filter((item) => item !== documentToken);

            const keyErrors = this.compareExcelvsToken(excelData, documentToken?.data);
            if (documentToken && documentToken.id && documentToken.id != null) {
                const documentValidation = new DocumentValidation();
                documentValidation.documentSetId = documentSetId;
                documentValidation.excelId = excel.id;
                documentValidation.documentTokenId = documentToken.id;
                documentValidation.isValidation = !keyErrors.length ? 1 : 0;
                documentValidation.keyErrors = keyErrors;

                documentValidation.data = {
                    excel: excelData,
                    ocrData: documentToken?.data,
                };

                documentValidations.push(documentValidation);
            }
        }
        this.logger.debug('End transformDocumentValidation', `DocumentSet ${documentSetId ?? 0}`);

        return documentValidations;
    }

    async handleDocumentClassifyResult(dto, @Ctx() context: KafkaContext) {
        this.logger.log('Starting handleDocumentClassifyResult', 'PROFILING');
        const heartbeat = context.getHeartbeat();

        const documentSet = await this.documentSetRepository.findOne({
            where: { id: dto.id },
            relations: ['documents', 'documents.documentImage'],
        });
        this.logger.log('Done get documentSet', 'PROFILING');
        await heartbeat();

        if (!documentSet || !documentSet.documents || !documentSet.documents.length) {
            this.logger.error(
                'Invalid DocumentSet or DocumentSet does not have document to classify',
                `dto.id: ${dto?.id ?? 0}`,
            );
            return 'Invalid DocumentSet or DocumentSet does not have document to classify';
        }

        if (documentSet.documentSetStatusId !== EnumDocumentSetStatus.REQUESTED_CLASSIFY) {
            this.logger.error('DocumentSet Classified', `DocumentSetId: ${documentSet.id ?? 0}`);
            return 'DocumentSet Classified';
        }

        const documentSetExcels = await this.excelRepository.find({
            where: {
                documentSetId: documentSet.id,
            },
        });
        this.logger.log('Done get documentSetExcels', 'PROFILING');

        const documentTypes = keyBy(await this.documentTypeRepository.find(), 'code');

        let toUpsertDocumentImages: DocumentImage[] = [];
        let batchUpdateDocumentStatuses = {};
        let toInsertDocumentTokens: { any: DocumentToken[] } = {} as {
            any: DocumentToken[];
        }; /* {documentType: DocumentToken[] } */

        let drAmount: any;
        let documentTokens: DocumentToken[] = [];
        let documentSetValidationData: any = {
            dr_account: {
                'chi-luong': [],
                'uy-nhiem-chi': [],
                'phieu-de-nghi': [],
                'phieu-hach-toan': [],
            },
            cr_account: {
                'phieu-de-nghi': [],
                'phieu-hach-toan': [],
            },
            amount: {
                'chi-luong': [],
                'uy-nhiem-chi': [],
                'phieu-de-nghi': [],
                'phieu-hach-toan': [],
            },
            file_name: {
                'uy-nhiem-chi': [],
                'phieu-de-nghi': [],
            },
            num_row: {
                'chi-luong': 0,
                'phieu-de-nghi': [],
            },
            num_page: {
                'chi-luong': 0,
                'phieu-de-nghi': [],
            },
        };

        this.auditService.saveAudit(
            documentSet,
            documentSet,
            AuditAction.CLASSIFIED,
            documentSet.updatedBy,
            documentSet.id,
        );

        // ─── Handle Data ─────────────────────────────────────────────
        // ─────────────────────────────────────────────────────────────
        for (const i in dto.files ?? []) {
            this.logger.debug(`DocumentSet ${documentSet?.id ?? 0}. i: ${i}`, `DocumentSet ${documentSet?.id ?? 0}`);
            await heartbeat();

            const processedData = dto.files[i]?.processedData ?? {};
            const documentType = dto.files[i].documentType;
            const documentId = parseInt(dto.files[i].documentId);

            // ─── Handle Documenttype ─────────────────────────────
            const documentTypeId = documentTypes[documentType].id;
            if (!batchUpdateDocumentStatuses[documentTypeId]) {
                batchUpdateDocumentStatuses[documentTypeId] = [];
            }
            batchUpdateDocumentStatuses[documentTypeId].push(documentId);

            // ─── Handle Documentimage ────────────────────────────
            const documentImage = {
                documentId,
                rotation: parseInt(dto.files[i].rotate),
                width: parseInt(dto.files[i].width),
                height: parseInt(dto.files[i].height),
            } as DocumentImage;
            toUpsertDocumentImages.push(documentImage);

            // ─── Handle Documenttokens ───────────────────────────
            if (!processedData || !Object.keys(processedData).length) {
                continue;
            }

            [documentTokens, drAmount] = this.transformDocumentToken(processedData, documentId, documentType);
            if (!documentTokens.length) {
                continue;
            }
            toInsertDocumentTokens[documentType] = !toInsertDocumentTokens[documentType]
                ? documentTokens
                : toInsertDocumentTokens[documentType].concat(documentTokens);

            // ─── Handle Validations ──────────────────────────────
            switch (documentType) {
                case EnumCheckDocumentOcrs.CHI_LUONG:
                    // Update Set validation
                    documentSetValidationData.num_row[EnumCheckDocumentOcrs.CHI_LUONG] += documentTokens.length;
                    documentSetValidationData.num_page[EnumCheckDocumentOcrs.CHI_LUONG] += 1;

                    break;
                case EnumCheckDocumentOcrs.PHIEU_HACH_TOAN:
                    if (
                        processedData?.dr_account?.words !== undefined &&
                        processedData?.cr_account?.words !== undefined &&
                        processedData?.cr_amount?.words !== undefined
                    ) {
                        documentSetValidationData.dr_account[documentType] = documentSetValidationData.dr_account[
                            documentType
                        ].concat(processedData.dr_account.words);
                        documentSetValidationData.cr_account[documentType] = documentSetValidationData.cr_account[
                            documentType
                        ].concat(processedData.cr_account.words);
                        documentSetValidationData.amount[documentType] = documentSetValidationData.amount[
                            documentType
                        ].concat(processedData.cr_amount.words);
                    }
                    break;
                case EnumCheckDocumentOcrs.UY_NHIEM_CHI:
                    if (
                        processedData?.dr_account?.words !== undefined &&
                        processedData?.file_name?.words !== undefined
                    ) {
                        documentSetValidationData.dr_account[documentType] = documentSetValidationData.dr_account[
                            documentType
                        ].concat(processedData.dr_account.words);
                        documentSetValidationData.file_name[documentType] = documentSetValidationData.file_name[
                            documentType
                        ].concat(processedData.file_name.words);
                        documentSetValidationData.amount[documentType] = documentSetValidationData.amount[
                            documentType
                        ].concat(processedData.dr_amount.words);
                    }
                    break;
                case EnumCheckDocumentOcrs.PHIEU_DE_NGHI:
                    documentSetValidationData.dr_account[documentType] = documentSetValidationData.dr_account[
                        documentType
                    ].concat(processedData.dr_account?.words);
                    documentSetValidationData.cr_account[documentType] = documentSetValidationData.cr_account[
                        documentType
                    ].concat(processedData.cr_account?.words);
                    documentSetValidationData.amount[documentType] = documentSetValidationData.amount[
                        documentType
                    ].concat(processedData.cr_amount?.words);
                    documentSetValidationData.file_name[documentType] = documentSetValidationData.file_name[
                        documentType
                    ].concat(processedData.file_name?.words);
                    documentSetValidationData.num_row[documentType] = documentSetValidationData.num_row[
                        documentType
                    ].concat(processedData.num_row?.words);
                    documentSetValidationData.num_page[documentType] = documentSetValidationData.num_page[
                        documentType
                    ].concat(processedData.num_page?.words);
                    break;
            }
        }

        // ─── Start Transaction ───────────────────────────────────────
        // ─────────────────────────────────────────────────────────────
        const queryRunner = this.dataSource.createQueryRunner();

        await queryRunner.connect();
        await queryRunner.startTransaction();
        this.logger.log('startTransaction Success', 'PROFILING');
        try {
            // ─── Update Documents Types ────────────────────────────
            for (const [documentTypeId, ids] of Object.entries(batchUpdateDocumentStatuses)) {
                await queryRunner.manager
                    .createQueryBuilder()
                    .update(Document)
                    .set({ documentTypeId })
                    .whereInIds(ids)
                    .execute();
            }
            batchUpdateDocumentStatuses = undefined;
            await heartbeat();
            this.logger.log('End save update document type', 'PROFILING');

            // ─── Update Document Images ───────────────────────────
            this.logger.log('Start save document Image', 'PROFILING');
            // await queryRunner.manager.upsert(DocumentImage, toUpsertDocumentImages, ['documentId']);
            for (const i in toUpsertDocumentImages) {
                const img = toUpsertDocumentImages[i];
                await queryRunner.manager.update(DocumentImage, { documentId: img.documentId }, img);
            }
            toUpsertDocumentImages = undefined;
            await heartbeat();
            this.logger.log('End save document Image', 'PROFILING');

            // ─── Insert Documenttokens And Validations ───────────
            for (const [documentType, documentTokens] of Object.entries(toInsertDocumentTokens)) {
                this.logger.log('Start save Token OCR data', 'PROFILING');
                await queryRunner.manager.save(DocumentToken, documentTokens, {
                    chunk: 1000,
                });
                this.logger.log('End save Token OCR data', 'PROFILING');
                await heartbeat();

                this.logger.log('Start save documentValidations', 'PROFILING');
                if (documentType == EnumCheckDocumentOcrs.CHI_LUONG) {
                    const documentValidations: DocumentValidation[] = await this.transformDocumentValidation(
                        documentSetExcels,
                        documentTokens,
                        documentSet.id,
                    );
                    await queryRunner.manager.save(DocumentValidation, documentValidations, {
                        chunk: 1000,
                    });
                }
                this.logger.log('End save documentValidations', 'PROFILING');
            }

            // ─── Save Document Set Validation ────────────────────
            if (dto.dr_row && dto.dr_row.dr_amount && dto.dr_row.dr_amount != '') {
                documentSetValidationData.amount[EnumCheckDocumentOcrs.CHI_LUONG] = dto.dr_row.dr_amount;
            } else {
                documentSetValidationData.amount[EnumCheckDocumentOcrs.CHI_LUONG] = drAmount;
            }

            if (dto.dr_row && dto.dr_row.is_debit && dto.dr_row.is_debit == true) {
                documentSetValidationData.num_row[EnumCheckDocumentOcrs.CHI_LUONG] -= 1;
            }

            const documentSetValidation = new DocumentSetValidation();
            documentSetValidation.documentSetId = documentSet.id;
            documentSetValidation.excelId = 0;
            const report: any = {
                total: 0,
                totalFail: 0,
            };
            documentSetValidation.report = report;

            documentSetValidation.data = documentSetValidationData;

            this.logger.log('Start save documentSetValidation', 'PROFILING');
            await queryRunner.manager.save(documentSetValidation);
            this.logger.log('End save documentSetValidation', 'PROFILING');

            // ─── Update Documentset Status ───────────────────────
            this.logger.log('Start save update documentSet status', 'PROFILING');
            await queryRunner.manager.update(
                DocumentSet,
                { id: documentSet.id },
                { documentSetStatusId: EnumDocumentStatus.CLASSIFIED },
            );
            this.logger.log('End save update documentSet status', 'PROFILING');

            await queryRunner.commitTransaction();
            this.logger.log('End handleDocumentClassifyResult', 'PROFILING');
        } catch (err) {
            this.logger.error('Error requestOcrClassify ' + err.message, 'PROFILING');
            await queryRunner.rollbackTransaction();
            throw err;
        } finally {
            await queryRunner.release();
        }
    }

    async getOcrResult(id: number) {
        const documentSetValidation = await this.documentSetValidationRepository
            .createQueryBuilder('document_set_validations')
            .andWhere('document_set_validations.documentSetId = :documentSetId', {
                documentSetId: id,
            })
            .orderBy('document_set_validations.id', 'ASC')
            .getOne();
        return documentSetValidation.report;
    }

    async reportOcrResult(id: number) {
        let total = 0;
        let totalFail = 0;

        this.logger.log('Start query DocumentSet ' + id, 'PROFILING');

        const documentSet = await this.documentSetRepository.findOne({
            where: { id },
        });

        this.logger.log('End query DocumentSet', 'PROFILING');

        this.logger.log('Start query excels data', 'PROFILING');
        const excels = await this.excelRepository
            .createQueryBuilder('excels')
            .andWhere('excels.documentSetId = :documentSetId', {
                documentSetId: id,
            })
            .orderBy('excels.id', 'ASC')
            .getMany();
        this.logger.log('End query excels data', 'PROFILING');

        // Get total cell
        this.logger.log('Start query token data', 'PROFILING');
        const documentTokens = await this.documentTokenRepository
            .createQueryBuilder('documentToken')
            .leftJoinAndSelect('documentToken.document', 'document')
            .andWhere('document.documentSetId = :id', { id })
            .andWhere('document.documentTypeId = :documentTypeId', {
                documentTypeId: '1',
            })
            .getMany();
        this.logger.log('End query token data', 'PROFILING');

        let cellFail = 4;

        this.logger.log('DocumentSet Type: ' + documentSet.type, 'PROFILING');
        if (documentSet.type == EnumTypes.EXTERNAL) {
            cellFail = 5;
        }

        total = documentTokens.length * cellFail;

        // Get token error
        this.logger.log('Start query documentValidation', 'PROFILING');
        const documentValidationFails = await this.documentValidationRepository
            .createQueryBuilder('documentValidation')
            .where('documentValidation.document_set_id = :id', { id })
            .andWhere('documentValidation.is_validation = :isValidation', {
                isValidation: 0,
            })
            .getMany();
        this.logger.log('End query documentValidation', 'PROFILING');

        const mapkeyErrors = documentValidationFails.map((x) => x.keyErrors);
        const acFails = [];
        for (const keyErrors of mapkeyErrors) {
            for (const iterator of keyErrors) {
                if (iterator == EnumKeyOcrs.ACC_NUM) {
                    acFails.push(iterator);
                }
            }
        }

        this.logger.log('Start query documentValidation', 'PROFILING');
        const documentValidation = await this.documentValidationRepository
            .createQueryBuilder('documentValidation')
            .where('documentValidation.document_set_id = :id', { id })
            .getMany();
        this.logger.log('End query documentValidation', 'PROFILING');

        if (
            (documentValidationFails.length == 0 && documentValidation.length > excels.length) ||
            (documentValidation.length == documentValidationFails.length && acFails.length != 0) ||
            documentValidation.length == 0
        ) {
            totalFail = total;
        } else {
            const excelAccounts = excels.map((x) => x.data['account']);
            const tokenAccounts = documentValidation.map((x) => x.data['excel'].account);
            const dataNoOcr = [];
            for (const excelAccount of excelAccounts) {
                const account = tokenAccounts.find(
                    (element) => accentsTidy(element.toString()) == accentsTidy(excelAccount.toString()),
                );

                if (!account) {
                    dataNoOcr.push(excelAccount);
                }
            }

            for (let i in documentValidation) {
                totalFail += documentValidation[i].keyErrors?.length;
            }

            const totalNoOcr = dataNoOcr.length * cellFail;

            totalFail = totalNoOcr + totalFail;
        }
        this.logger.log('End process reportOcrResult', 'PROFILING');

        return { total, totalFail };
    }

    async cancel(id: number, userId: number): Promise<any> {
        const documentSet = await this.documentSetRepository.findOne({
            where: { id },
        });

        if (
            documentSet.documentSetStatusId != EnumDocumentSetStatus.OPEN &&
            documentSet.documentSetStatusId != EnumDocumentSetStatus.CLASSIFIED
        ) {
            throw new BadRequestException('Document set is not open or classyfied');
        }

        documentSet.documentSetStatusId = EnumDocumentSetStatus.CANCEL;

        await this.documentSetRepository.save(documentSet);

        delete documentSet.documentValidation;
        delete documentSet.documentSetValidation;
        delete documentSet.excels;
        delete documentSet.documentFile;
        delete documentSet.documents;

        this.auditService.saveAudit(documentSet, documentSet, AuditAction.CANCEL, userId, documentSet.id);

        return documentSet;
    }

    async reportOcr(id) {
        if (id == null || id === 'undefined') {
            return 'undefined';
        }

        this.logger.log('Start process report OCR setID: ' + id, 'PROFILING');
        this.logger.log('Start query documentSetValidation', 'PROFILING');
        const documentSetValidation = await this.documentSetValidationRepository
            .createQueryBuilder('document_set_validations')
            .andWhere('document_set_validations.documentSetId = :documentSetId', {
                documentSetId: id,
            })
            .orderBy('document_set_validations.id', 'ASC')
            .getOne();
        this.logger.log('End query documentSetValidation', 'PROFILING');

        this.logger.log('Start process reportOcrResult', 'PROFILING');
        const report: any = await this.reportOcrResult(id);
        this.logger.log('End process reportOcrResult', 'PROFILING');

        documentSetValidation.report = report;
        this.logger.log('End process report OCR', 'PROFILING');
        return await this.documentSetValidationRepository.save(documentSetValidation);
    }
}
