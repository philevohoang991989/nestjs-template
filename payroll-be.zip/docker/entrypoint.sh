#!/bin/sh

npm run typeorm migration:run
node dist/main
